// Code-side validation of the model's reply. The model only writes wording; this decides whether
// that wording may be shown. Any failure → the engine answer is used.
import { asText } from '../engine/knowledge.ts';
import type { ClinicData, Lang } from '../engine/types.ts';

export interface AiReply { answerable: boolean; answer: string; sources: string[] }
export type Verdict = { ok: true; reply: AiReply } | { ok: false; reasons: string[] };

const BANNED: Array<[RegExp, string]> = [
  [/diagnos/i, 'diagnos*'], [/\byou have\b/i, '"you have"'], [/\bmg\b/i, '"mg"'], [/%\s*off/i, '"% off"'],
  [/guarantee/i, '"guarantee"'], [/confirmed/i, '"confirmed"'],
];
const NATIVE_DIGITS = /[\u0966-\u096F\u0C66-\u0C6F]/g;
const toLatinDigits = (s: string) => s.replace(NATIVE_DIGITS, (c) => String((c.codePointAt(0)! - (c >= '\u0C66' ? 0x0c66 : 0x0966))));

/** every number in a text, normalised: "Rs 6,500" / "₹6500" / "6500/-" → "6500"; "9:00" → "9:00" */
export function numbersIn(text: string): string[] {
  const t = toLatinDigits(text).replace(/₹|rs\.?|inr|rupees?/gi, ' ');
  const out: string[] = [];
  for (const m of t.matchAll(/\d{1,2}:\d{2}|\d[\d,]*(?:\.\d+)?/g)) {
    const v = m[0].includes(':') ? m[0].replace(/^0(\d):/, '$1:') : m[0].replace(/,/g, '').replace(/\.0+$/, '');
    out.push(v);
    if (m[0].includes(':')) out.push(String(Number(m[0].split(':')[0]))); // "9:00" also covers a bare "9"
  }
  return out;
}

const DOCTOR_NAME = /\b(?:Dr\.?|Doctor)\s+([A-Z][a-zA-Z]+)(?:\s+([A-Z][a-zA-Z]+))?/g;

/** strings the engine answer contains that the AI wording must keep EXACTLY (times, prices, doctor names, key words) */
export function mustKeep(engineReply: string, lang: Lang): string[] {
  const keep = new Set<string>();
  for (const m of engineReply.matchAll(/\b\d{1,2}:\d{2}\s?(?:am|pm)\b/gi)) keep.add(m[0]);
  for (const m of engineReply.matchAll(/Rs\s?[\d,]+(?:\s+per tooth)?/g)) keep.add(m[0].replace(/\s+per tooth$/, ''));
  for (const m of engineReply.matchAll(/\bDr\.\s[A-Z][a-z]+\s[A-Z][a-z]+/g)) keep.add(m[0].replace(/^Dr\.\s/, ''));
  for (const m of engineReply.matchAll(/\b\d{2,3}\s?\d{3,4}\s?\d{4,5}\b/g)) keep.add(m[0]); // phone numbers
  if (/\bcashless\b/.test(engineReply) && lang === 'en') keep.add('cashless');
  if (lang === 'en') for (const d of ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']) if (new RegExp(`\\b${d}\\b`).test(engineReply)) keep.add(d);
  return [...keep];
}

function scriptShare(s: string, re: RegExp) {
  const letters = (s.match(/[\p{L}\p{M}]/gu) || []).length;
  return letters ? (s.match(re) || []).length / letters : 0;
}
function languageMatches(answer: string, lang: Lang): boolean {
  const hi = scriptShare(answer, /[\u0900-\u097F]/g);
  const te = scriptShare(answer, /[\u0C00-\u0C7F]/g);
  if (lang === 'hi') return hi >= 0.2 && te === 0; // names/prices stay Latin, so allow a lower share
  if (lang === 'te') return te >= 0.2 && hi === 0;
  return hi === 0 && te === 0;
}

/** "services > Root canal treatment" must point at something that exists in the clinic file */
export function sourceExists(src: string, clinic: ClinicData): boolean {
  const [secRaw, ...rest] = String(src).split('>').map((x) => x.trim());
  const norm = (x: string) => x.toLowerCase().replace(/[_\s]+/g, ' ').trim();
  const sec = norm(secRaw || '');
  const item = norm(rest.join(' > '));
  const data = clinic as Record<string, unknown>;
  const key = Object.keys(data).find((k) => norm(k) === sec || (sec === 'clinic' && k === 'clinic') || (sec === 'emergency' && k === 'emergency_rules'));
  if (!key) return false;
  const val = data[key];
  if (!item) return true;
  if (Array.isArray(val)) return val.some((v) => norm(asText((v as Record<string, unknown>)?.name ?? (v as Record<string, unknown>)?.q ?? v)) === item || norm(asText((v as Record<string, unknown>)?.name ?? '')).startsWith(item));
  if (val && typeof val === 'object') return Object.keys(val).some((k) => norm(k) === item);
  return false;
}

export function validateAiReply(raw: string, ctx: { clinic: ClinicData; message: string; lang: Lang; engineReply?: string; engineAnswered: boolean }): Verdict {
  const reasons: string[] = [];
  let j: unknown;
  try { j = JSON.parse(raw); } catch { return { ok: false, reasons: ['invalid JSON'] }; }
  if (!j || typeof j !== 'object' || Array.isArray(j)) return { ok: false, reasons: ['not a JSON object'] };
  const o = j as Record<string, unknown>;
  if (typeof o.answerable !== 'boolean') return { ok: false, reasons: ['answerable is not a boolean'] };
  const answer = typeof o.answer === 'string' ? o.answer.trim() : '';
  const sources = Array.isArray(o.sources) ? o.sources.filter((s): s is string => typeof s === 'string').slice(0, 6) : [];
  if (!o.answerable) return { ok: true, reply: { answerable: false, answer, sources } };

  if (!answer) reasons.push('empty answer');
  if (answer.length > 600) reasons.push('answer longer than 600 characters');
  for (const [re, label] of BANNED) if (re.test(answer)) reasons.push(`banned word ${label}`);
  if (!languageMatches(answer, ctx.lang)) reasons.push(`language is not ${ctx.lang}`);
  if (NATIVE_DIGITS.test(answer)) reasons.push('non-Latin digits');

  // every number / price / time must exist in the clinic file or the patient's own message
  const allowed = new Set([...numbersIn(JSON.stringify(ctx.clinic)), ...numbersIn(ctx.message)]);
  for (const n of numbersIn(answer)) if (!allowed.has(n)) reasons.push(`number "${n}" is not in the clinic file`);
  // every doctor name must exist in the clinic file or the patient's message
  const docText = `${(ctx.clinic.doctors || []).map((d) => d.name).join(' ')} ${ctx.message}`;
  for (const m of answer.matchAll(DOCTOR_NAME)) for (const w of [m[1], m[2]].filter(Boolean)) if (!new RegExp(`\\b${w}\\b`).test(docText)) reasons.push(`doctor name "${w}" is not in the clinic file`);
  // grounding: at least one source that really exists in the file
  if (!sources.some((s) => sourceExists(s, ctx.clinic))) reasons.push('no source that exists in the clinic file');
  // the engine's exact facts must survive the rewording (times, prices, names exactly as in the file)
  if (ctx.engineAnswered && ctx.engineReply) for (const k of mustKeep(ctx.engineReply, ctx.lang)) if (!answer.includes(k)) reasons.push(`missing exact fact "${k}"`);

  return reasons.length ? { ok: false, reasons } : { ok: true, reply: { answerable: true, answer, sources } };
}
