// One HTTPS call to the key's provider (DeepSeek, OpenAI-compatible chat completions).
// temperature 0, max 300 output tokens, 6 s timeout, NO retries, NO tools / function calling.
export const AI_TIMEOUT_MS = 6000;
export const AI_MAX_TOKENS = 300;
export const DEFAULT_BASE_URL = 'https://api.deepseek.com';
export const DEFAULT_MODEL = 'deepseek-chat';

export type ProviderResult =
  | { ok: true; content: string }
  | { ok: false; error: 'no_key' | 'timeout' | 'network' | 'http' | 'bad_response' };

export interface AiEnv { apiKey?: string; model?: string; baseUrl?: string }

/** Reads ONLY AI_API_KEY / AI_MODEL (and the optional AI_BASE_URL) at call time. */
export function readAiEnv(env: Record<string, string | undefined> = (globalThis as { process?: { env: Record<string, string | undefined> } }).process?.env || {}): AiEnv {
  return { apiKey: (env.AI_API_KEY || '').trim() || undefined, model: (env.AI_MODEL || '').trim() || undefined, baseUrl: (env.AI_BASE_URL || '').trim() || undefined };
}

export async function callModel(env: AiEnv, messages: Array<{ role: 'system' | 'user'; content: string }>, fetchImpl: typeof fetch = fetch): Promise<ProviderResult> {
  if (!env.apiKey) return { ok: false, error: 'no_key' };
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), AI_TIMEOUT_MS);
  try {
    const res = await fetchImpl(`${(env.baseUrl || DEFAULT_BASE_URL).replace(/\/+$/, '')}/chat/completions`, {
      method: 'POST',
      signal: ctl.signal,
      headers: { 'content-type': 'application/json', authorization: `Bearer ${env.apiKey}` },
      body: JSON.stringify({
        model: env.model || DEFAULT_MODEL,
        messages,
        temperature: 0,
        max_tokens: AI_MAX_TOKENS,
        response_format: { type: 'json_object' },
        stream: false,
      }),
    });
    if (!res.ok) return { ok: false, error: 'http' }; // body is never forwarded (could echo request details)
    const data = (await res.json().catch(() => null)) as { choices?: Array<{ message?: { content?: unknown } }> } | null;
    const content = data?.choices?.[0]?.message?.content;
    return typeof content === 'string' ? { ok: true, content } : { ok: false, error: 'bad_response' };
  } catch (e) {
    return { ok: false, error: (e as Error).name === 'AbortError' ? 'timeout' : 'network' };
  } finally { clearTimeout(timer); }
}
