// Decides IF the model may word an answer, makes the ONE call, validates in code.
// Everything else (safety, booking, tickets, statuses) is decided by code before/after.
import type { ClinicData, EngineResult, Lang } from '../engine/types.ts';
import { buildMessages, MAX_CLINIC_BYTES } from './prompt.ts';
import { callModel, type AiEnv } from './provider.ts';
import { validateAiReply, type AiReply } from './validate.ts';

const FACT_INTENTS = new Set(['hours', 'doctor', 'service', 'price-list', 'insurance', 'policy', 'contact', 'location', 'clinic-info']);
const GENERIC_TOPICS = new Set(['your question']);

/**
 * The model is NEVER used for: emergency, injection/discount refusals, medical advice, booking,
 * greeting/thanks, talk-to-a-human, contact capture, Staff FAQ answers, follow-ups, quick-reply chips,
 * or a question naming something the file does not list (e.g. "Invisalign" — never inferred).
 */
export function aiEligible(r: EngineResult, via?: string): 'fact' | 'unknown' | null {
  if (via === 'quick') return null;
  if (r.emergency || r.followUp || r.faqUsed || r.booking) return null;
  const blocked = ['emergency', 'refusal', 'medical', 'booking', 'greeting', 'thanks', 'human', 'contact', 'faq', 'unsupported-service', 'unsupported-availability', 'unsupported-doctor', 'unsupported-price'];
  if (r.intents.some((i) => blocked.includes(i))) return null;
  if (r.status === 'answered' && r.intents.length > 0 && r.intents.every((i) => FACT_INTENTS.has(i))) return 'fact';
  if (r.status === 'needs human' && r.ticketType === 'unsupported' && r.unsupportedTopics.every((t) => GENERIC_TOPICS.has(t))
    && r.parts.every((p) => p.kind === 'unsupported')) return 'unknown';
  return null;
}

export type AiOutcome =
  | { kind: 'answer'; reply: AiReply }
  | { kind: 'unanswerable' }
  | { kind: 'fallback'; reason: string };

export async function askModel(env: AiEnv, input: { message: string; lang: Lang; clinic: ClinicData; facts: string[]; engineReply?: string; engineAnswered: boolean }, fetchImpl?: typeof fetch): Promise<AiOutcome> {
  if (!env.apiKey) return { kind: 'fallback', reason: 'no_key' };
  if (JSON.stringify(input.clinic).length > MAX_CLINIC_BYTES) return { kind: 'fallback', reason: 'clinic_too_large' };
  const res = await callModel(env, buildMessages(input), fetchImpl);
  if (!res.ok) return { kind: 'fallback', reason: res.error };
  const v = validateAiReply(res.content, { clinic: input.clinic, message: input.message, lang: input.lang, engineReply: input.engineReply, engineAnswered: input.engineAnswered });
  if (!v.ok) return { kind: 'fallback', reason: `validation: ${v.reasons.join('; ')}` };
  return v.reply.answerable ? { kind: 'answer', reply: v.reply } : { kind: 'unanswerable' };
}
