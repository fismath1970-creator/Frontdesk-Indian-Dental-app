// Basic per-IP fixed-window limit (30 model calls / 10 min). In-memory per function instance —
// a cost/abuse brake, not a security boundary. Over the limit → /api/ask 429, /api/chat silently uses the engine.
const WINDOW_MS = 10 * 60 * 1000;
export const RATE_LIMIT = 30;
const hits = new Map<string, { start: number; n: number }>();
export function allow(ip: string, now = Date.now()): boolean {
  const k = ip || 'unknown';
  const h = hits.get(k);
  if (!h || now - h.start >= WINDOW_MS) { hits.set(k, { start: now, n: 1 }); if (hits.size > 5000) hits.clear(); return true; }
  if (h.n >= RATE_LIMIT) return false;
  h.n++; return true;
}
export function resetRateLimit() { hits.clear(); }
export function clientIp(req: Request): string {
  return req.headers.get('x-nf-client-connection-ip') || (req.headers.get('x-forwarded-for') || '').split(',')[0].trim() || req.headers.get('x-real-ip') || 'unknown';
}
