import { useState } from 'react';
import { clock12, formatHm, formatYmd } from '../engine/datetime.ts';
import { requestedLabel } from '../engine/i18n.ts';
import type { BookingState } from '../engine/types.ts';
import type { Ticket } from '../tickets/types.ts';

export const BOOKING_STATE_LABEL: Record<BookingState, string> = {
  requested: 'Appointment requested',
  'awaiting confirmation': 'Awaiting staff confirmation',
  confirmed: 'Confirmed by staff',
  rejected: 'Rejected — rescheduling required',
};
const MISSING_LABEL: Record<string, string> = { date: 'day', time: 'exact time', name: 'name', phone: 'phone', treatment: 'treatment' };

interface Props {
  ticket: Ticket;
  onDecide: (input: { decision: 'confirm' | 'reject'; date?: string; time?: string; note?: string }) => Promise<unknown>;
}

export function BookingPanel({ ticket: t, onDecide }: Props) {
  const b = t.booking!;
  const state: BookingState = b.state || 'requested';
  const [date, setDate] = useState(b.confirmedDate || b.requestedDate || '');
  const [time, setTime] = useState(b.confirmedTime || b.requestedTime || '');
  const [note, setNote] = useState('');
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);

  const decide = async (decision: 'confirm' | 'reject') => {
    if (decision === 'confirm' && (!date || !time)) { setMsg({ ok: false, text: 'Set the confirmed date and time first.' }); return; }
    setBusy(true); setMsg(null);
    try {
      await onDecide({ decision, date: decision === 'confirm' ? date : undefined, time: decision === 'confirm' ? time : undefined, note: note.trim() || undefined });
      setNote('');
      setMsg({ ok: true, text: decision === 'confirm' ? 'Confirmed — the patient has been told in their chat ✓' : 'Rejected — the patient has been asked for another time ✓' });
    } catch (e) { setMsg({ ok: false, text: e instanceof Error ? e.message : 'Action failed — please retry.' }); } finally { setBusy(false); }
  };

  const reqDate = b.requestedDate ? formatYmd(b.requestedDate) : b.dateText ? `“${b.dateText}” (unclear)` : '—';
  const reqTime = b.requestedTime ? formatHm(b.requestedTime) : b.requestedWindow ? `${b.requestedWindow.part} (${clock12(b.requestedWindow.from)} – ${clock12(b.requestedWindow.to)})` : b.timeText ? `“${b.timeText}” (unclear)` : '—';

  return (
    <section className={`booking-box booking-${state.replace(' ', '-')}`} data-booking-state={state} aria-label="Appointment request">
      <div className="booking-head">
        <strong>{BOOKING_STATE_LABEL[state]}</strong>
        {state !== 'confirmed' && <span className="booking-flag">NOT confirmed</span>}
        {b.outsideHours && <span className="booking-flag flag-outside">Outside clinic hours</span>}
      </div>
      <p className="booking-requested" data-testid="requested">Requested: {requestedLabel(b, 'en') || 'day and time not given yet'}</p>
      <dl className="booking-grid">
        <div><dt>Requested day</dt><dd>{reqDate}</dd></div>
        <div><dt>Requested time</dt><dd>{reqTime}</dd></div>
        <div><dt>Treatment</dt><dd>{b.service || <span className="muted">Not given</span>}</dd></div>
        <div><dt>Preferred dentist</dt><dd>{b.doctor || <span className="muted">No preference given</span>}</dd></div>
        <div><dt>Patient</dt><dd>{b.patientName || t.patientName || <span className="muted">Not given</span>}</dd></div>
        <div><dt>Phone</dt><dd>{b.phone || t.phone || <span className="muted">Not given</span>}</dd></div>
      </dl>
      {!!b.notes?.length && <p className="booking-notes"><strong>Additional information:</strong> {b.notes.join(' · ')}</p>}
      {!!b.missing?.filter((m) => m !== 'treatment').length && state !== 'confirmed' && (
        <p className="booking-missing">Still missing: {b.missing.map((m) => MISSING_LABEL[m]).join(', ')}</p>
      )}
      {!!b.warnings?.length && <ul className="booking-warnings">{b.warnings.map((w) => <li key={w}>⚠️ {w}</li>)}</ul>}
      {state === 'confirmed' && b.confirmedDate && (
        <p className="booking-confirmed">✅ Confirmed for {formatYmd(b.confirmedDate)}{b.confirmedTime ? ` at ${formatHm(b.confirmedTime)}` : ''} by {b.decidedBy}</p>
      )}
      {state === 'rejected' && <p className="booking-rejected">Rejected by {b.decidedBy}. Waiting for the patient to suggest another time.</p>}

      <div className="booking-decide">
        <p className="small muted">Staff only: check the diary before confirming. FrontDesk AI never confirms appointments.</p>
        <div className="booking-inputs">
          <label className="field"><span>Confirmed date</span><input type="date" value={date} onChange={(e) => setDate(e.target.value)} /></label>
          <label className="field"><span>Confirmed time</span><input type="time" value={time} onChange={(e) => setTime(e.target.value)} /></label>
        </div>
        <label className="field"><span>Message to patient (optional)</span>
          <input type="text" className="booking-note" value={note} maxLength={500} onChange={(e) => setNote(e.target.value)} placeholder="e.g. Please arrive 10 minutes early" />
        </label>
        <div className="ticket-actions">
          <button type="button" className="btn-confirm" data-action="confirm-booking" disabled={busy} onClick={() => void decide('confirm')}>
            {state === 'confirmed' ? 'Update confirmation' : 'Confirm appointment'}
          </button>
          <button type="button" className="btn-reject" data-action="reject-booking" disabled={busy} onClick={() => void decide('reject')}>
            Reject / ask to reschedule
          </button>
        </div>
        {msg && <p className={`feedback ${msg.ok ? 'fb-ok' : 'fb-err'}`} role="status">{msg.text}</p>}
      </div>
    </section>
  );
}
