import { useEffect, useState } from 'react';
import { getPref, setPref } from '../lib/storage.ts';

export type Theme = 'light' | 'dark';
export function currentTheme(): Theme { return document.documentElement.dataset.theme === 'dark' ? 'dark' : 'light'; }
export function applyTheme(t: Theme) { document.documentElement.dataset.theme = t; document.documentElement.style.colorScheme = t; }

/** Light/dark switch — persisted in localStorage ("frontdesk.theme"); first visit follows the device setting. */
export function ThemeToggle() {
  const [theme, setTheme] = useState<Theme>(currentTheme);
  useEffect(() => { applyTheme(theme); setPref('frontdesk.theme', theme); }, [theme]);
  const next = theme === 'dark' ? 'light' : 'dark';
  return (
    <button type="button" className="theme-toggle" data-theme-toggle aria-label={`Switch to ${next} theme`} title={`Switch to ${next} theme`} onClick={() => setTheme(next)}>
      {theme === 'dark'
        ? <svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true"><circle cx="12" cy="12" r="4.5" fill="currentColor" /><g stroke="currentColor" strokeWidth="2" strokeLinecap="round">{[0, 45, 90, 135, 180, 225, 270, 315].map((a) => <line key={a} x1="12" y1="2.5" x2="12" y2="5" transform={`rotate(${a} 12 12)`} />)}</g></svg>
        : <svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true"><path d="M20 14.5A8.5 8.5 0 0 1 9.5 4a8.5 8.5 0 1 0 10.5 10.5z" fill="currentColor" /></svg>}
    </button>
  );
}
export function initTheme() { const saved = getPref('frontdesk.theme'); applyTheme(saved === 'dark' || saved === 'light' ? saved : (window.matchMedia?.('(prefers-color-scheme: dark)').matches ? 'dark' : 'light')); }
