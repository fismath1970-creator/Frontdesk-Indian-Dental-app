import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import clinicFile from '../data/clinic-data.json';
import type { ClinicRecord } from '../clinic/store.ts';
import { buildIndex } from '../engine/knowledge.ts';
import { buildCalendar, openStatus } from '../engine/schedule.ts';
import { ClinicEditor } from './ClinicEditor.tsx';
import { ThemeToggle } from './ThemeToggle.tsx';
import type { ClinicData, Priority, TicketStatus } from '../engine/types.ts';
import { getBackend, type Backend } from '../lib/backend.ts';
import { getPref, setPref } from '../lib/storage.ts';
import { sortQueue, type SortMode } from '../tickets/sla.ts';
import type { Ticket } from '../tickets/types.ts';
import { TicketCard } from './TicketCard.tsx';

export const STAFF_POLL_MS = 5000;
type StatusFilter = 'all' | 'new' | TicketStatus;
const isNew = (t: Ticket) => t.status !== 'closed' && !t.messages.some((m) => m.sender === 'staff');
const digits = (s: string) => s.replace(/\D/g, '');

export function StaffDashboard() {
  const [clinicRec, setClinicRec] = useState<ClinicRecord>({ data: clinicFile as ClinicData, version: 0 });
  const clinic = clinicRec.data.clinic;
  const [tab, setTab] = useState<'queue' | 'clinic'>(() => (/[?&#]tab=clinic/.test(window.location.href) ? 'clinic' : 'queue'));
  const [backend, setBackend] = useState<Backend | null>(null);
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [loaded, setLoaded] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [query, setQuery] = useState('');
  const [status, setStatus] = useState<StatusFilter>('all');
  const [priority, setPriority] = useState<'all' | Priority>('all');
  const [sort, setSort] = useState<SortMode>('priority');
  const [kind, setKind] = useState<'all' | 'booking'>('all');
  const [band, setBand] = useState<'all' | 'overdue' | 'delayed' | 'waiting' | 'new'>('all');
  const [staffName, setStaffName] = useState(() => getPref('frontdesk.staffName') || 'Front desk');
  const [lastSync, setLastSync] = useState<Date | null>(null);
  const drafts = useRef<Map<string, string>>(new Map());
  const busyOps = useRef(0);

  const refresh = useCallback(async (b?: Backend | null) => {
    const be = b || backend;
    if (!be || busyOps.current > 0) return;
    try {
      be.clinic().then((c) => setClinicRec((cur) => (c.version !== cur.version || c.updatedAt !== cur.updatedAt ? c : cur))).catch(() => {});
      const list = await be.tickets();
      if (busyOps.current === 0) setTickets(list);
      setError(null); setLastSync(new Date());
    } catch { setError('Could not refresh tickets. Retrying…'); } finally { setLoaded(true); }
  }, [backend]);

  useEffect(() => { void getBackend().then((b) => { setBackend(b); void refresh(b); }); }, []); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    if (!backend) return;
    const iv = setInterval(() => void refresh(), STAFF_POLL_MS);
    return () => clearInterval(iv);
  }, [backend, refresh]);
  useEffect(() => { setPref('frontdesk.staffName', staffName); }, [staffName]);

  const upsert = (t: Ticket) => setTickets((ts) => [...ts.filter((x) => x.id !== t.id), t]);
  const op = async (fn: () => Promise<Ticket>) => {
    busyOps.current++;
    try { const t = await fn(); upsert(t); return t; } finally { busyOps.current--; }
  };

  const counts = useMemo(() => ({
    total: tickets.length,
    new: tickets.filter(isNew).length,
    'needs human': tickets.filter((t) => t.status === 'needs human').length,
    urgent: tickets.filter((t) => t.status === 'urgent').length,
    answered: tickets.filter((t) => t.status === 'answered').length,
    closed: tickets.filter((t) => t.status === 'closed').length,
    bookings: tickets.filter((t) => t.type === 'booking' && t.status !== 'closed' && t.booking?.state !== 'confirmed' && t.booking?.state !== 'rejected').length,
    overdue: tickets.filter((t) => t.ageing?.band === 'overdue').length,
  }), [tickets]);

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    const qd = digits(q);
    return sortQueue(tickets, sort).filter((t) => {
      if (status === 'new' ? !isNew(t) : status !== 'all' && t.status !== status) return false;
      if (priority !== 'all' && t.priority !== priority) return false;
      if (kind === 'booking' && t.type !== 'booking') return false;
      if (band !== 'all' && t.ageing?.band !== band) return false;
      if (!q) return true;
      if ((t.patientName || '').toLowerCase().includes(q)) return true;
      if (qd.length >= 3 && digits(t.phone || '').includes(qd)) return true;
      return t.id.toLowerCase().includes(q) || t.question.toLowerCase().includes(q);
    });
  }, [tickets, query, status, priority, sort, kind, band]);

  const stat = (key: StatusFilter, label: string, value: number, tone: string) => (
    <button type="button" className={`stat stat-${tone}${status === key ? ' is-active' : ''}`} aria-pressed={status === key}
      onClick={() => setStatus(status === key ? 'all' : key)}>
      <span className="stat-value">{value}</span><span className="stat-label">{label}</span>
    </button>
  );

  return (
    <div className="staff">
      <header className="staff-top">
        <div className="staff-brand">
          <span className="brand-mark" aria-hidden="true">🦷</span>
          <div><div className="brand-name">{clinic.name}</div><div className="brand-sub">FrontDesk AI · Staff dashboard</div></div>
        </div>
        <span className={`open-badge ob-${openStatus(buildCalendar(buildIndex(clinicRec.data)), new Date()).state}`}>{openStatus(buildCalendar(buildIndex(clinicRec.data)), new Date()).label}</span>
        <ThemeToggle />
        <a className="staff-link" href={window.location.hash.startsWith('#/') ? '#/' : '/'}>Patient chat →</a>
      </header>

      <div className="demo-banner" role="note">
        <strong>Demonstration access.</strong> This dashboard is open without a login for the competition demo. Fictional clinic data only — do not enter real patient records.
        {backend && <span className={`mode-badge mode-${backend.mode}`}>{backend.storageLabel}</span>}
      </div>

      <nav className="staff-tabs" role="tablist" aria-label="Staff sections">
        <button type="button" role="tab" aria-selected={tab === 'queue'} className={tab === 'queue' ? 'is-active' : ''} data-tab="queue" onClick={() => setTab('queue')}>Ticket queue <span className="tab-count">{counts.total}</span></button>
        <button type="button" role="tab" aria-selected={tab === 'clinic'} className={tab === 'clinic' ? 'is-active' : ''} data-tab="clinic" onClick={() => setTab('clinic')}>Clinic file <span className="tab-count">v{clinicRec.version || 1}</span></button>
      </nav>

      {tab === 'clinic' && backend && (
        <main className="staff-main">
          <ClinicEditor
            record={clinicRec.version ? clinicRec : { ...clinicRec, version: 1 }}
            onSave={async (data, baseVersion) => { const r = await backend.saveClinic(data, baseVersion, staffName || 'Clinic staff'); setClinicRec(r); return r; }}
            onReset={async () => { const r = await backend.resetClinic(staffName || 'Clinic staff'); setClinicRec(r); return r; }}
          />
        </main>
      )}

      <main className="staff-main" hidden={tab !== 'queue'}>
        <section className="stats" aria-label="Ticket summary">
          {stat('all', 'Total enquiries', counts.total, 'total')}
          {stat('new', 'New tickets', counts.new, 'new')}
          {stat('urgent', 'Urgent', counts.urgent, 'urgent')}
          {stat('needs human', 'Needs human', counts['needs human'], 'human')}
          {stat('answered', 'Answered', counts.answered, 'answered')}
          {stat('closed', 'Closed', counts.closed, 'closed')}
          <button type="button" className={`stat stat-booking${kind === 'booking' ? ' is-active' : ''}`} aria-pressed={kind === 'booking'} onClick={() => setKind(kind === 'booking' ? 'all' : 'booking')}>
            <span className="stat-value">{counts.bookings}</span><span className="stat-label">Bookings awaiting decision</span>
          </button>
          <button type="button" className={`stat stat-overdue${band === 'overdue' ? ' is-active' : ''}`} aria-pressed={band === 'overdue'} onClick={() => setBand(band === 'overdue' ? 'all' : 'overdue')}>
            <span className="stat-value">{counts.overdue}</span><span className="stat-label">Overdue callbacks</span>
          </button>
        </section>

        {counts.urgent > 0 && (
          <div className="urgent-alert" role="alert">🚨 {counts.urgent} urgent {counts.urgent === 1 ? 'ticket needs' : 'tickets need'} attention now. Emergency line: {clinic.emergency_phone}</div>
        )}

        <section className="filters" aria-label="Search and filters">
          <label className="field field-search">
            <span>Search name or phone</span>
            <input type="search" value={query} onChange={(e) => setQuery(e.target.value)} placeholder="e.g. Ravi or 98765" />
          </label>
          <label className="field">
            <span>Status</span>
            <select value={status} onChange={(e) => setStatus(e.target.value as StatusFilter)}>
              <option value="all">All statuses</option>
              <option value="new">New (no staff reply)</option>
              <option value="urgent">Urgent</option>
              <option value="needs human">Needs human</option>
              <option value="answered">Answered</option>
              <option value="closed">Closed</option>
            </select>
          </label>
          <label className="field">
            <span>Priority</span>
            <select value={priority} onChange={(e) => setPriority(e.target.value as 'all' | Priority)}>
              <option value="all">All priorities</option>
              <option value="critical">Critical</option>
              <option value="high">High</option>
              <option value="normal">Normal</option>
              <option value="low">Low</option>
            </select>
          </label>
          <label className="field">
            <span>Type</span>
            <select value={kind} onChange={(e) => setKind(e.target.value as 'all' | 'booking')} data-filter="type">
              <option value="all">All tickets</option>
              <option value="booking">Booking requests</option>
            </select>
          </label>
          <label className="field">
            <span>Ageing</span>
            <select value={band} onChange={(e) => setBand(e.target.value as typeof band)} data-filter="ageing">
              <option value="all">Any age</option>
              <option value="overdue">Overdue (over 2 working hours)</option>
              <option value="delayed">Delayed (1–2 h)</option>
              <option value="waiting">Waiting (15–60 min)</option>
              <option value="new">New (under 15 min)</option>
            </select>
          </label>
          <label className="field">
            <span>Sort</span>
            <select value={sort} onChange={(e) => setSort(e.target.value as SortMode)} data-filter="sort">
              <option value="priority">Highest priority first</option>
              <option value="oldest">Oldest first</option>
              <option value="newest">Newest first</option>
            </select>
          </label>
          <label className="field">
            <span>Your name (shown to patients)</span>
            <input type="text" value={staffName} maxLength={60} onChange={(e) => setStaffName(e.target.value)} />
          </label>
        </section>

        <div className="queue-head">
          <h2>Ticket queue <span className="muted">({visible.length}{visible.length !== tickets.length ? ` of ${tickets.length}` : ''})</span></h2>
          <button type="button" className="btn-ghost" onClick={() => void refresh()}>↻ Refresh</button>
          {lastSync && <span className="muted small">Updated {lastSync.toLocaleTimeString('en-IN', { timeZone: 'Asia/Kolkata', hour: '2-digit', minute: '2-digit', second: '2-digit' })} IST</span>}
        </div>
        {error && <p className="error-line" role="status">{error}</p>}

        <div id="ticket-queue" aria-label="Ticket queue">
          {loaded && visible.length === 0 && (
            <p className="empty-queue">{tickets.length ? 'No tickets match these filters.' : 'No enquiries yet. Patient questions appear here automatically.'}</p>
          )}
          {visible.map((t) => (
            <TicketCard
              key={t.id}
              ticket={t}
              emergencyPhone={clinic.emergency_phone}
              draft={drafts.current.get(t.id) || ''}
              onDraft={(v) => { if (v) drafts.current.set(t.id, v); else drafts.current.delete(t.id); }}
              onReply={async (text, saveFaq) => {
                let res: (Ticket & { savedFaqVersion?: number }) | undefined;
                await op(async () => { res = await backend!.reply(t.id, text, staffName || 'Clinic staff', saveFaq); return res; });
                drafts.current.delete(t.id);
                if (res?.savedFaqVersion) void backend!.clinic().then(setClinicRec);
                return res;
              }}
              onClose={() => op(() => backend!.setStatus(t.id, 'closed', staffName || 'Clinic staff'))}
              onReopen={() => op(() => backend!.setStatus(t.id, 'open', staffName || 'Clinic staff'))}
              onAssign={() => op(() => backend!.assign(t.id, staffName || 'Clinic staff'))}
              onDecide={(input) => op(() => backend!.decideBooking(t.id, { ...input, staffName: staffName || 'Clinic staff' }))}
            />
          ))}
        </div>
      </main>
    </div>
  );
}
