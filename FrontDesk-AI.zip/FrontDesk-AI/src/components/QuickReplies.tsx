import { QUICK_LABELS } from '../engine/i18n.ts';
import type { Lang } from '../engine/types.ts';
import type { ChatMessage } from '../tickets/types.ts';

export type QuickKey = 'timings' | 'doctors' | 'prices' | 'insurance' | 'location' | 'book' | 'human';
const STANDARD: QuickKey[] = ['timings', 'doctors', 'prices', 'insurance', 'location', 'book', 'human'];

interface Props { lang: Lang; last?: ChatMessage; emergencyPhone?: string; onSend: (text: string) => void; disabled?: boolean }

/** Rendered directly BELOW the thread — never inside a .bot-msg. Clicking sends the label as a patient message. */
export function QuickReplies({ lang, last, emergencyPhone, onSend, disabled }: Props) {
  const L = QUICK_LABELS[lang] || QUICK_LABELS.en;
  const m = last?.sender === 'bot' ? last.meta : undefined;
  const ctx: Array<{ key: string; label: string; tel?: string }> = [];
  if (m?.emergency && emergencyPhone) ctx.push({ key: 'call', label: `${L.call} ${emergencyPhone}`, tel: emergencyPhone });
  else if (m?.ticketType === 'booking' && m.needsPhone) ctx.push({ key: 'add-phone', label: L.addPhone });
  else if (m?.unknown) { ctx.push({ key: 'phone', label: L.phone }); ctx.push({ key: 'book', label: L.book }); }
  const shown = new Set(ctx.map((c) => c.key));
  return (
    <div id="quick-replies" role="group" aria-label="Quick replies" data-lang={lang}>
      {ctx.map((c) => c.tel
        ? <a key={c.key} className="quick-reply qr-call" data-quick={c.key} href={`tel:${c.tel.replace(/[^\d+]/g, '')}`}>{c.label}</a>
        : <button key={c.key} type="button" className="quick-reply qr-context" data-quick={c.key} disabled={disabled} onClick={() => onSend(c.label)}>{c.label}</button>)}
      {STANDARD.filter((k) => !shown.has(k)).map((k) => (
        <button key={k} type="button" className="quick-reply" data-quick={k} disabled={disabled} onClick={() => onSend(L[k])}>{L[k]}</button>
      ))}
    </div>
  );
}
