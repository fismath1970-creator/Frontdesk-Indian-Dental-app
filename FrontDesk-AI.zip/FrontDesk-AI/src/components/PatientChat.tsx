import { useCallback, useEffect, useMemo, useRef, useState, type FormEvent } from 'react';
import clinicFile from '../data/clinic-data.json';
import { answerQuestion } from '../engine/engine.ts';
import { buildIndex } from '../engine/knowledge.ts';
import { buildCalendar, openStatus } from '../engine/schedule.ts';
import type { ClinicData } from '../engine/types.ts';
import type { ClinicRecord } from '../clinic/store.ts';
import { getBackend, type Backend } from '../lib/backend.ts';
import { getPref, setPref } from '../lib/storage.ts';
import { newId } from '../tickets/service.ts';
import type { ChatMessage } from '../tickets/types.ts';
import { BotText } from './BotText.tsx';
import { QuickReplies } from './QuickReplies.tsx';
import { ThemeToggle } from './ThemeToggle.tsx';
import { openNowText, SOURCE_LABEL } from '../engine/i18n.ts';
import type { Lang } from '../engine/types.ts';

const QUICK = [
  { label: 'Opening hours', icon: '🕘', q: 'What are your opening hours?' },
  { label: 'Our dentists', icon: '🦷', q: 'Who are your doctors?' },
  { label: 'Treatment prices', icon: '₹', q: 'What are your treatment prices?' },
  { label: 'Insurance', icon: '🛡️', q: 'Which insurance do you accept?' },
  { label: 'Location', icon: '📍', q: 'Where are you located?' },
  { label: 'Book appointment', icon: '📅', q: 'I want to book an appointment' },
];
const CONV_KEY = 'frontdesk.conversationId';
export const POLL_MS = 2000; // staff replies must reach an open chat within 3 s

type ViewMsg = ChatMessage & { pending?: boolean };

function mergeMessages(current: ViewMsg[], incoming: ViewMsg[]): ViewMsg[] {
  const byId = new Map<string, ViewMsg>();
  for (const m of current) byId.set(m.id, m);
  for (const m of incoming) byId.set(m.id, { ...m, pending: false });
  const all = [...byId.values()];
  const settled = all.filter((m) => !m.pending).sort((a, b) => a.createdAt.localeCompare(b.createdAt));
  return [...settled, ...all.filter((m) => m.pending)];
}

export function PatientChat() {
  // The header, badge and offline fallback use the CURRENT clinic file from the backend (re-polled),
  // shown first from the bundled file only until the first fetch returns.
  const [clinicRec, setClinicRec] = useState<ClinicRecord>({ data: clinicFile as ClinicData, version: 0 });
  const clinicRef = useRef(clinicRec);
  clinicRef.current = clinicRec;
  const clinicData = clinicRec.data;
  const clinic = clinicData.clinic;
  const [tick, setTick] = useState(0);
  const status = useMemo(() => openStatus(buildCalendar(buildIndex(clinicData)), new Date()), [clinicData, tick]); // eslint-disable-line react-hooks/exhaustive-deps
  const phones = [clinic.emergency_phone, clinic.phone, clinic.whatsapp].filter(Boolean) as string[];
  const telHref = (p?: string) => `tel:${String(p || '').replace(/[^\d+]/g, '')}`;

  const [messages, setMessages] = useState<ViewMsg[]>([]);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const [isReady, setIsReady] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const endRef = useRef<HTMLDivElement>(null);
  const backendRef = useRef<Backend | null>(null);
  const convId = useRef<string>('');
  const ready = useRef<Promise<void> | null>(null);
  const started = useRef(false);
  const seenStaff = useRef<Set<string>>(new Set());
  const inFlight = useRef(0);

  const ask = useCallback(async (raw: string, opts: { holdHistory?: ChatMessage[]; via?: 'quick' | 'typed' } = {}) => {
    const text = raw.trim();
    if (!text) return;
    const id = newId();
    const optimistic: ViewMsg = { id, conversationId: convId.current, sender: 'patient', text, createdAt: new Date().toISOString(), pending: true };
    if (!opts.holdHistory) setMessages((m) => [...m, optimistic]);
    setBusy(true);
    inFlight.current++;
    try {
      if (ready.current) await ready.current;
      const backend = backendRef.current!;
      // ?nokey=1 (owner testing switch) skips the model and forces the clinic-file answer; selectors unchanged
      const noAI = new URLSearchParams(window.location.search).get('nokey') === '1';
      const res = await backend.chat(convId.current, text, id, { noAI, via: opts.via || 'typed' });
      if (res.conversationId && res.conversationId !== convId.current) { convId.current = res.conversationId; setPref(CONV_KEY, res.conversationId); }
      setMessages((m) => mergeMessages(opts.holdHistory ? mergeMessages(m, opts.holdHistory) : m.filter((x) => x.id !== id), res.messages));
    } catch {
      // Server unreachable: still answer from the clinic file so the patient is never left without help.
      const r = answerQuestion(text, clinicRef.current.data);
      const extra = r.ticketRequired && !r.emergency ? `\nOur message system is busy right now — please call ${clinic.phone} so our team can help you.` : '';
      const bot: ChatMessage = { id: newId(), conversationId: convId.current, sender: 'bot', text: r.reply + extra, createdAt: new Date(Date.now() + 1).toISOString(), meta: { status: r.status, emergency: r.emergency, ticketType: r.ticketType, source: 'clinic-file', offline: true } };
      setMessages((m) => mergeMessages(opts.holdHistory ? mergeMessages(m, opts.holdHistory) : m, [{ ...optimistic, pending: false }, bot]));
    } finally {
      inFlight.current--;
      setBusy(inFlight.current > 0);
    }
  }, [clinic.phone]);

  // Start-up: choose backend, restore this browser's conversation, then handle /?q=
  useEffect(() => {
    if (started.current) return; // StrictMode double-invoke guard
    started.current = true;
    const q = new URLSearchParams(window.location.search).get('q');
    let history: ChatMessage[] = [];
    ready.current = (async () => {
      backendRef.current = await getBackend();
      try { setClinicRec(await backendRef.current.clinic()); } catch { /* keep the bundled copy */ }
      convId.current = getPref(CONV_KEY) || newId();
      setPref(CONV_KEY, convId.current);
      try { history = await backendRef.current.conversation(convId.current); } catch { history = []; }
      history.filter((m) => m.sender === 'staff').forEach((m) => seenStaff.current.add(m.id));
      if (!q) setMessages((m) => mergeMessages(m, history));
      setIsReady(true);
    })();
    if (q && q.trim()) {
      // History and the new answer are rendered together, so the last .bot-msg is always this answer.
      void ready.current.then(() => ask(q, { holdHistory: history })).then(() => {
        const u = new URL(window.location.href); u.searchParams.delete('q');
        window.history.replaceState({}, '', u.pathname + u.search + u.hash); // a refresh shows history instead of asking again
      });
    }
  }, [ask]);

  // Poll for staff replies (and anything sent from another tab).
  useEffect(() => {
    let stop = false;
    const poll = async () => {
      if (stop || !backendRef.current || !convId.current || inFlight.current > 0) return;
      try {
        // pick up clinic-file edits made in another tab / on the staff page
        backendRef.current.clinic().then((c) => { if (c.version !== clinicRef.current.version || c.updatedAt !== clinicRef.current.updatedAt) setClinicRec(c); }).catch(() => {});
        setTick((x) => x + 1);
        const incoming = await backendRef.current.conversation(convId.current);
        const fresh = incoming.filter((m) => m.sender === 'staff' && !seenStaff.current.has(m.id));
        fresh.forEach((m) => seenStaff.current.add(m.id));
        if (fresh.length) setNotice(`New reply from ${fresh[fresh.length - 1].staffName || 'our team'}`);
        if (inFlight.current === 0) setMessages((m) => (incoming.some((x) => !m.find((y) => y.id === x.id)) ? mergeMessages(m, incoming) : m));
      } catch { /* keep quiet; try again next tick */ }
    };
    const iv = setInterval(poll, POLL_MS);
    const onVis = () => { if (document.visibilityState === 'visible') void poll(); };
    document.addEventListener('visibilitychange', onVis);
    window.addEventListener('focus', onVis);
    return () => { stop = true; clearInterval(iv); document.removeEventListener('visibilitychange', onVis); window.removeEventListener('focus', onVis); };
  }, []);

  useEffect(() => { endRef.current?.scrollIntoView?.({ block: 'end' }); }, [messages, busy]);
  const lastMsg = messages.filter((m) => !m.pending).at(-1);
  const lastBotLang = [...messages].reverse().find((m) => m.sender === 'bot' && m.meta?.lang)?.meta?.lang;
  const lang: Lang = (lastBotLang as Lang) || 'en';
  useEffect(() => { if (!notice) return; const t = setTimeout(() => setNotice(null), 6000); return () => clearTimeout(t); }, [notice]);

  const onSubmit = (e: FormEvent) => {
    e.preventDefault();
    const el = inputRef.current; // read the DOM value so programmatic fills by test harnesses also work
    if (!el) return;
    const value = el.value;
    el.value = '';
    void ask(value);
    el.focus();
  };

  return (
    <div className="patient" data-ready={isReady ? 'true' : 'false'}>
      <header className="brand-bar">
        <div className="brand">
          <span className="brand-mark" aria-hidden="true">🦷</span>
          <div>
            <div className="brand-name">{clinic.name}</div>
            <div className="brand-sub">FrontDesk AI · {String(clinic.address || '').split(',').slice(-2).join(',').trim()}</div>
            <div className={`open-badge ob-${status.state}`} data-open-state={status.state}>{openNowText(status, lang)}</div>
          </div>
        </div>
        <div className="header-actions">
        <ThemeToggle />
        {clinic.emergency_phone && (
          <a className="emergency-pill" href={telHref(clinic.emergency_phone)} aria-label={`Emergency line ${clinic.emergency_phone}`}>
            🚨 <span>{clinic.emergency_phone}</span>
          </a>
        )}
        </div>
      </header>

      <main className="chat" aria-live="polite">
        <section className="welcome" aria-label="Welcome">
          <h1>Hello! How can we help you today?</h1>
          <p>Ask about timings, dentists, prices, insurance or appointments. You can type in English, Hindi or Telugu.</p>
          <div className="quick-grid">
            {QUICK.map((c) => (
              <button key={c.label} type="button" className="quick-card" onClick={() => void ask(c.q, { via: 'quick' })}>
                <span className="quick-icon" aria-hidden="true">{c.icon}</span>
                <span>{c.label}</span>
              </button>
            ))}
          </div>
        </section>

        <ol className="messages">
          {messages.map((m) => {
            if (m.sender === 'patient') return (
              <li key={m.id} className="row row-patient"><div className="patient-msg">{m.text}</div></li>
            );
            if (m.sender === 'staff') return (
              <li key={m.id} className="row row-bot row-staff">
                <div className="staff-label">💬 Reply from {m.staffName || 'our team'} · {clinic.name}
                  {m.meta?.bookingDecision === 'confirmed' && <span className="decision-tag d-confirmed">Confirmed by staff</span>}
                  {m.meta?.bookingDecision === 'rejected' && <span className="decision-tag d-rejected">Rescheduling required</span>}
                </div>
                <div className="bot-msg staff-msg" data-kind="staff-reply"><BotText text={m.text} phones={phones} /></div>
              </li>
            );
            const emergency = !!m.meta?.emergency;
            const ticket = m.meta?.status && m.meta.status !== 'answered';
            return (
              <li key={m.id} className={`row row-bot${emergency ? ' is-emergency' : ''}`}>
                <div className="bot-msg" data-kind={emergency ? 'emergency' : m.meta?.ticketType}>
                  <BotText text={m.text} phones={phones} />
                  {emergency && clinic.emergency_phone && <a className="call-now" href={telHref(clinic.emergency_phone)}>Call {clinic.emergency_phone} now</a>}
                </div>
                <div className="bot-meta">
                  {m.meta?.source === 'ai' ? (
                    <span className="source-line" data-source="ai">Source: {(m.meta.aiSources || []).join(' · ') || 'clinic file'}</span>
                  ) : (<span className={`source-tag${m.meta?.source === 'staff-faq' ? ' src-faq' : ''}`}>
                    {(() => { const SL = SOURCE_LABEL[(m.meta?.lang as Lang) || 'en'] || SOURCE_LABEL.en; return m.meta?.source === 'staff-faq' ? (m.meta.faqMixed ? SL.mixed : SL.faq) : SL.file; })()}
                  </span>)}
                  {ticket && (
                    <span className={`ticket-tag t-${String(m.meta?.status).replace(' ', '-')}`}>
                      {m.meta?.status === 'urgent' ? 'Urgent — team alerted'
                        : m.meta?.bookingState === 'awaiting confirmation' ? 'Appointment requested · awaiting staff confirmation'
                        : m.meta?.ticketType === 'booking' || m.meta?.bookingState ? 'Appointment requested · details needed'
                        : 'Passed to our team'}
                    </span>
                  )}
                </div>
              </li>
            );
          })}
          {busy && (
            <li className="row row-bot" aria-label="FrontDesk AI is typing"><div className="typing"><span /><span /><span /></div></li>
          )}
        </ol>
        <QuickReplies lang={lang} last={lastMsg} emergencyPhone={clinic.emergency_phone ? String(clinic.emergency_phone) : undefined} onSend={(text) => void ask(text, { via: 'quick' })} />
        <div ref={endRef} />
      </main>

      {notice && <div className="toast" role="status">{notice}</div>}

      <p className="staff-entry"><a href={window.location.hash.startsWith('#/') ? '#/staff' : '/staff'} data-link="staff">Clinic staff: open the staff portal (tickets &amp; history) →</a></p>

      <form className="composer" onSubmit={onSubmit}>
        <label htmlFor="chat-input" className="sr-only">Type your question</label>
        <input id="chat-input" ref={inputRef} type="text" name="question" autoComplete="off" enterKeyHint="send" placeholder="Type your question…" aria-label="Type your question" />
        <button id="chat-send" type="submit" aria-label="Send message">Send</button>
      </form>
    </div>
  );
}
