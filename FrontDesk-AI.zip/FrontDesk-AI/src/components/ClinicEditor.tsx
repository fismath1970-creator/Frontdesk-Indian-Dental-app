import { useEffect, useMemo, useState } from 'react';
import { formatHm, parseRange } from '../engine/datetime.ts';
import { parseDays, validateClinicData } from '../engine/knowledge.ts';
import { DAY_NAMES } from '../engine/lexicon.ts';
import type { ClinicData, Doctor, FaqEntry, Service } from '../engine/types.ts';
import type { ClinicRecord } from '../clinic/store.ts';

// ---------- helpers: convert between the clinic file's text format and form fields ----------
interface HoursRow { id: string; key: string; closed: boolean; open: string; close: string; note: string; raw: string; touched: boolean }
const rid = () => Math.random().toString(36).slice(2, 10);
const hhmm = (m: number) => `${String(Math.floor(m / 60)).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}`;
const toMin = (s: string) => { const [h, m] = s.split(':').map(Number); return h * 60 + m; };
const HHMM = /^([01]\d|2[0-3]):[0-5]\d$/;

function parseHoursText(key: string, text: string): HoursRow {
  const r = parseRange(text);
  if (r) {
    const rest = text.replace(/^[^,]*?(?:\d{1,2}(?:[:.]\d{2})?\s*(?:am|pm)?)\s*(?:to|-|–|until|till)\s*(?:\d{1,2}(?:[:.]\d{2})?\s*(?:am|pm)?)/i, '').replace(/^[\s,;.-]+/, '');
    return { id: rid(), key, closed: false, open: hhmm(r[0]), close: hhmm(r[1]), note: rest, raw: text, touched: false };
  }
  if (/^\s*closed\b/i.test(text)) return { id: rid(), key, closed: true, open: '', close: '', note: text.replace(/^\s*closed\b[\s,;.-]*/i, ''), raw: text, touched: false };
  return { id: rid(), key, closed: false, open: '', close: '', note: text, raw: text, touched: false };
}
function hoursText(r: HoursRow): string {
  if (!r.touched) return r.raw;
  if (r.closed) return r.note.trim() ? `Closed, ${r.note.trim()}` : 'Closed';
  const base = HHMM.test(r.open) && HHMM.test(r.close) ? `${formatHm(r.open)} to ${formatHm(r.close)}` : `${r.open || '?'} to ${r.close || '?'}`;
  return r.note.trim() ? `${base}, ${r.note.trim()}` : base;
}
function rowErrors(r: HoursRow): string[] {
  const e: string[] = [];
  if (!r.key.trim()) e.push('Name the days (e.g. monday_to_friday).');
  const special = /holiday|festival|lunch|break/i.test(r.key);
  if (!special && r.key.trim() && !parseDays(r.key.replace(/_/g, ' ')).length) e.push('Days not recognised — use e.g. "monday_to_friday", "saturday".');
  if (!r.closed && r.touched) {
    if (!HHMM.test(r.open) || !HHMM.test(r.close)) e.push('Times must be HH:MM.');
    else if (toMin(r.close) <= toMin(r.open)) e.push('Closing time must be later than opening time.');
  }
  return e;
}
const daysPreview = (key: string) => {
  if (/holiday|festival/i.test(key)) return 'Public holidays';
  if (/lunch|break/i.test(key)) return 'Daily break';
  const d = parseDays(key.replace(/_/g, ' '));
  return d.length ? d.map((x) => DAY_NAMES[x].slice(0, 3)).join(' ') : '—';
};
const joinAnd = (xs: string[]) => (xs.length <= 1 ? xs.join('') : `${xs.slice(0, -1).join(', ')} and ${xs[xs.length - 1]}`);
function parseInsurance(text: string): { list: string; note: string } {
  const m = text.match(/^\s*cashless (?:with|for)\s+([^.]*)\.\s*(.*)$/i);
  if (!m) return { list: '', note: text };
  return { list: m[1].split(/,|\band\b/).map((x) => x.trim()).filter(Boolean).join(', '), note: m[2] };
}
function insuranceText(list: string, note: string): string {
  const xs = list.split(',').map((x) => x.trim()).filter(Boolean);
  return [xs.length ? `Cashless with ${joinAnd(xs)}.` : '', note.trim()].filter(Boolean).join(' ');
}
const csv = (v: unknown) => (Array.isArray(v) ? v.join(', ') : typeof v === 'string' ? v : '');
const fromCsv = (s: string) => s.split(',').map((x) => x.trim()).filter(Boolean);
const istTime = (iso?: string) => (iso ? new Date(iso).toLocaleTimeString('en-IN', { timeZone: 'Asia/Kolkata', hour: '2-digit', minute: '2-digit', hour12: false }) : '');

interface Props {
  record: ClinicRecord;
  onSave: (data: ClinicData, baseVersion: number) => Promise<ClinicRecord>;
  onReset: () => Promise<ClinicRecord>;
}

export function ClinicEditor({ record, onSave, onReset }: Props) {
  const [base, setBase] = useState<ClinicRecord>(record);
  const [draft, setDraft] = useState<ClinicData>(() => structuredClone(record.data));
  const [hours, setHours] = useState<HoursRow[]>(() => rowsFrom(record.data));
  const [policyRows, setPolicyRows] = useState(() => policiesFrom(record.data));
  const [ins, setIns] = useState(() => parseInsurance(record.data.policies?.insurance || ''));
  const [insTouched, setInsTouched] = useState(false);
  const [jsonText, setJsonText] = useState('');
  const [jsonDirty, setJsonDirty] = useState(false);
  const [dirty, setDirty] = useState(false);
  const [errors, setErrors] = useState<string[]>([]);
  const [msg, setMsg] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [confirmReset, setConfirmReset] = useState(false);

  function rowsFrom(d: ClinicData): HoursRow[] {
    return d.hours && !Array.isArray(d.hours) ? Object.entries(d.hours).map(([k, v]) => parseHoursText(k, String(v))) : [];
  }
  function policiesFrom(d: ClinicData) {
    return Object.entries(d.policies || {}).filter(([k]) => !/^insurance$/i.test(k)).map(([k, v]) => ({ id: rid(), key: k, value: String(v) }));
  }
  const load = (r: ClinicRecord) => {
    setBase(r); setDraft(structuredClone(r.data)); setHours(rowsFrom(r.data)); setPolicyRows(policiesFrom(r.data));
    setIns(parseInsurance(r.data.policies?.insurance || '')); setInsTouched(false); setJsonDirty(false); setDirty(false); setErrors([]);
  };
  // follow edits made elsewhere (other tab, FAQ saved from a ticket) when there are no unsaved changes here
  useEffect(() => { if (!dirty && (record.version !== base.version || record.updatedAt !== base.updatedAt)) load(record); }, [record]); // eslint-disable-line react-hooks/exhaustive-deps

  /** the file as it would be saved from the forms (untouched values are kept byte-for-byte) */
  const assembled = useMemo<ClinicData>(() => {
    const d: ClinicData = structuredClone(draft);
    if (d.hours && !Array.isArray(d.hours)) d.hours = Object.fromEntries(hours.map((r) => [r.key.trim(), hoursText(r)]));
    const pol: Record<string, string> = {};
    let insPlaced = false;
    const origKeys = Object.keys(draft.policies || {});
    for (const k of origKeys) {
      if (/^insurance$/i.test(k)) { pol[k] = insTouched ? insuranceText(ins.list, ins.note) : String(draft.policies![k]); insPlaced = true; }
      const row = policyRows.find((r) => r.key === k);
      if (row) pol[row.key.trim()] = row.value;
    }
    for (const r of policyRows) if (!(r.key.trim() in pol)) pol[r.key.trim()] = r.value;
    if (!insPlaced && insTouched && (ins.list.trim() || ins.note.trim())) pol.insurance = insuranceText(ins.list, ins.note);
    if (draft.policies || Object.keys(pol).length) d.policies = pol;
    return d;
  }, [draft, hours, policyRows, ins, insTouched]);

  const shownJson = jsonDirty ? jsonText : JSON.stringify(assembled, null, 2);
  const touch = () => { setDirty(true); setMsg(null); };
  const setClinic = (field: string, value: string) => { touch(); setDraft((d) => ({ ...d, clinic: { ...d.clinic, [field]: field === 'languages' ? fromCsv(value) : value } })); };
  const editList = <T,>(field: 'doctors' | 'services' | 'faq', fn: (xs: T[]) => T[]) => { touch(); setDraft((d) => ({ ...d, [field]: fn([...(((d as Record<string, unknown>)[field] as T[]) || [])]) })); };
  const editHours = (id: string, patch: Partial<HoursRow>) => { touch(); setHours((rs) => rs.map((r) => (r.id === id ? { ...r, ...patch, touched: true } : r))); };

  const save = async () => {
    setMsg(null);
    let data: ClinicData;
    if (jsonDirty) {
      try { data = JSON.parse(jsonText); } catch (e) { setErrors([`Invalid JSON — nothing was saved. ${(e as Error).message}`]); return; }
    } else {
      const rowErrs = hours.flatMap((r) => rowErrors(r).map((x) => `Timing "${r.key || 'new row'}": ${x}`));
      if (rowErrs.length) { setErrors(rowErrs); return; }
      data = assembled;
    }
    const v = validateClinicData(data);
    if (!v.ok) { setErrors(v.errors); return; }
    setSaving(true);
    try {
      const rec = await onSave(data, base.version);
      load(rec);
      setMsg(`Clinic file v${rec.version} - saved ${istTime(rec.updatedAt)}`);
    } catch (e) {
      const err = e as Error & { details?: string[] };
      setErrors([err.message, ...(err.details || [])]);
    } finally { setSaving(false); }
  };
  const doReset = async () => {
    setSaving(true);
    try { const rec = await onReset(); load(rec); setConfirmReset(false); setMsg(`Clinic file v${rec.version} - reset to original ${istTime(rec.updatedAt)}`); }
    catch (e) { setErrors([(e as Error).message]); } finally { setSaving(false); }
  };

  const doctors = (draft.doctors || []) as Doctor[];
  const services = (draft.services || []) as Service[];
  const faq = (draft.faq || []) as FaqEntry[];
  const c = draft.clinic || ({ name: '' } as ClinicData['clinic']);
  const formsLocked = jsonDirty;

  return (
    <div className="clinic-editor" data-version={base.version}>
      <div className="ce-bar">
        <div>
          <strong className="ce-version" data-testid="clinic-version">Clinic file v{base.version}{base.updatedAt ? ` - saved ${istTime(base.updatedAt)}` : ' - original'}</strong>
          {base.updatedBy && <span className="muted small"> · by {base.updatedBy}{base.change ? ` · ${base.change}` : ''}</span>}
          {dirty && <span className="ce-unsaved">Unsaved changes</span>}
          {dirty && record.version !== base.version && <span className="ce-conflict">Changed elsewhere (now v{record.version}) — saving will be refused until you reload</span>}
        </div>
        <div className="ce-actions">
          <button id="clinic-save" type="button" className="btn-primary" onClick={() => void save()} disabled={saving}>Save clinic file</button>
          {dirty && <button type="button" className="btn-ghost" onClick={() => load(record)}>Discard changes</button>}
          {!confirmReset
            ? <button type="button" className="btn-secondary" data-action="reset-clinic" onClick={() => setConfirmReset(true)}>Reset to original</button>
            : <span className="ce-confirm" role="group" aria-label="Confirm reset">
                Replace the clinic file with the original sample? Tickets are kept.
                <button type="button" className="btn-reject" data-action="reset-confirm" onClick={() => void doReset()} disabled={saving}>Yes, reset</button>
                <button type="button" className="btn-ghost" onClick={() => setConfirmReset(false)}>Cancel</button>
              </span>}
        </div>
        {msg && <p className="feedback fb-ok" role="status" data-testid="clinic-saved">{msg}</p>}
        {errors.length > 0 && (
          <div className="ce-errors" role="alert" data-testid="clinic-errors">
            <strong>Not saved — please fix:</strong>
            <ul>{errors.map((e) => <li key={e}>{e}</li>)}</ul>
          </div>
        )}
      </div>

      <fieldset className="ce-section" disabled={formsLocked}>
        <legend>Clinic details</legend>
        <div className="ce-grid">
          {([['name', 'Clinic name *'], ['emergency_phone', 'Emergency phone *'], ['phone', 'Main phone'], ['whatsapp', 'WhatsApp'], ['address', 'Address'], ['landmark', 'Landmark'], ['parking', 'Parking']] as const).map(([k, label]) => (
            <label key={k} className="field"><span>{label}</span>
              <input type="text" data-field={`clinic.${k}`} value={String(c[k] ?? '')} onChange={(e) => setClinic(k, e.target.value)} /></label>
          ))}
          <label className="field"><span>Languages (comma separated)</span>
            <input type="text" data-field="clinic.languages" value={csv(c.languages)} onChange={(e) => setClinic('languages', e.target.value)} /></label>
        </div>
      </fieldset>

      <fieldset className="ce-section" disabled={formsLocked}>
        <legend>Timings &amp; closed days</legend>
        {Array.isArray(draft.hours) ? <p className="muted">This file uses a list format for hours — edit it under Advanced.</p> : (
          <>
            <p className="small muted">One row per group of days. Rows lower down override earlier ones for the same day (e.g. add a "saturday" row to give Saturday its own hours).</p>
            {hours.map((r) => {
              const errs = rowErrors(r);
              return (
                <div key={r.id} className={`ce-row${errs.length ? ' has-error' : ''}`} data-hours-row={r.key}>
                  <label className="field"><span>Days</span><input type="text" data-hours-field="key" value={r.key} onChange={(e) => editHours(r.id, { key: e.target.value })} /></label>
                  <span className="ce-days">{daysPreview(r.key)}</span>
                  <label className="ce-inline"><input type="checkbox" data-hours-field="closed" checked={r.closed} onChange={(e) => editHours(r.id, { closed: e.target.checked })} /> Closed</label>
                  {!r.closed && <>
                    <label className="field"><span>Opens</span><input type="time" data-hours-field="open" value={r.open} onChange={(e) => editHours(r.id, { open: e.target.value })} /></label>
                    <label className="field"><span>Closes</span><input type="time" data-hours-field="close" value={r.close} onChange={(e) => editHours(r.id, { close: e.target.value })} /></label>
                  </>}
                  <label className="field ce-wide"><span>Note</span><input type="text" data-hours-field="note" value={r.note} placeholder="e.g. emergencies only" onChange={(e) => editHours(r.id, { note: e.target.value })} /></label>
                  <button type="button" className="btn-ghost ce-del" aria-label={`Delete timing ${r.key}`} onClick={() => { touch(); setHours((rs) => rs.filter((x) => x.id !== r.id)); }}>Delete</button>
                  <span className="ce-preview small muted">Saved as: “{hoursText(r)}”</span>
                  {errs.map((e) => <span key={e} className="ce-err">{e}</span>)}
                </div>
              );
            })}
            <button type="button" className="btn-ghost" data-action="add-hours" onClick={() => { touch(); setHours((rs) => [...rs, { id: rid(), key: '', closed: false, open: '09:00', close: '17:00', note: '', raw: '', touched: true }]); }}>+ Add timing row</button>
          </>
        )}
      </fieldset>

      <fieldset className="ce-section" disabled={formsLocked}>
        <legend>Doctors</legend>
        {doctors.map((d, i) => (
          <div key={i} className="ce-row" data-doctor-row={d.name}>
            <label className="field"><span>Name *</span><input type="text" data-doctor-field="name" value={d.name || ''} onChange={(e) => editList<Doctor>('doctors', (xs) => { xs[i] = { ...xs[i], name: e.target.value }; return xs; })} /></label>
            <label className="field ce-wide"><span>Role / treatments</span><input type="text" data-doctor-field="role" value={String(d.role ?? '')} onChange={(e) => editList<Doctor>('doctors', (xs) => { xs[i] = { ...xs[i], role: e.target.value }; return xs; })} /></label>
            <label className="field"><span>Days</span><input type="text" data-doctor-field="days" value={csv(d.days)} onChange={(e) => editList<Doctor>('doctors', (xs) => { xs[i] = { ...xs[i], days: e.target.value }; return xs; })} /></label>
            <button type="button" className="btn-ghost ce-del" data-action="delete-doctor" aria-label={`Delete ${d.name}`} onClick={() => editList<Doctor>('doctors', (xs) => xs.filter((_, j) => j !== i))}>Delete</button>
          </div>
        ))}
        <button type="button" className="btn-ghost" data-action="add-doctor" onClick={() => editList<Doctor>('doctors', (xs) => [...xs, { name: '', role: '', days: '' }])}>+ Add doctor</button>
      </fieldset>

      <fieldset className="ce-section" disabled={formsLocked}>
        <legend>Services &amp; prices</legend>
        {services.map((s, i) => (
          <div key={i} className="ce-row" data-service-row={s.name}>
            <label className="field ce-wide"><span>Service name *</span><input type="text" data-service-field="name" value={s.name || ''} onChange={(e) => editList<Service>('services', (xs) => { xs[i] = { ...xs[i], name: e.target.value }; return xs; })} /></label>
            <label className="field"><span>Price</span><input type="text" data-service-field="price" value={String(s.price ?? '')} onChange={(e) => editList<Service>('services', (xs) => { xs[i] = { ...xs[i], price: e.target.value }; return xs; })} /></label>
            <label className="field"><span>Duration</span><input type="text" data-service-field="duration" value={String(s.duration ?? '')} onChange={(e) => editList<Service>('services', (xs) => { const n: Service = { ...xs[i], duration: e.target.value }; if (!e.target.value) delete n.duration; xs[i] = n; return xs; })} /></label>
            <label className="field ce-wide"><span>Note</span><input type="text" data-service-field="note" value={String(s.note ?? '')} onChange={(e) => editList<Service>('services', (xs) => { const n: Service = { ...xs[i], note: e.target.value }; if (!e.target.value) delete n.note; xs[i] = n; return xs; })} /></label>
            <label className="field ce-wide"><span>Other names patients use (comma separated)</span><input type="text" data-service-field="aliases" value={csv(s.aliases)} onChange={(e) => editList<Service>('services', (xs) => { const n = { ...xs[i], aliases: fromCsv(e.target.value) } as Service; if (!fromCsv(e.target.value).length) delete n.aliases; xs[i] = n; return xs; })} /></label>
            <button type="button" className="btn-ghost ce-del" aria-label={`Delete ${s.name}`} onClick={() => editList<Service>('services', (xs) => xs.filter((_, j) => j !== i))}>Delete</button>
          </div>
        ))}
        <button type="button" className="btn-ghost" data-action="add-service" onClick={() => editList<Service>('services', (xs) => [...xs, { name: '', price: '' }])}>+ Add service</button>
      </fieldset>

      <fieldset className="ce-section" disabled={formsLocked}>
        <legend>Insurance</legend>
        <label className="field"><span>Cashless insurers (comma separated)</span><input type="text" data-field="insurance.list" value={ins.list} onChange={(e) => { touch(); setInsTouched(true); setIns({ ...ins, list: e.target.value }); }} /></label>
        <label className="field"><span>Note for other insurers</span><input type="text" data-field="insurance.note" value={ins.note} onChange={(e) => { touch(); setInsTouched(true); setIns({ ...ins, note: e.target.value }); }} /></label>
        <p className="small muted">Saved as: “{insTouched ? insuranceText(ins.list, ins.note) : draft.policies?.insurance || ''}”</p>
      </fieldset>

      <fieldset className="ce-section" disabled={formsLocked}>
        <legend>Policies</legend>
        {policyRows.map((r) => (
          <div key={r.id} className="ce-row" data-policy-row={r.key}>
            <label className="field"><span>Name</span><input type="text" value={r.key} onChange={(e) => { touch(); setPolicyRows((rs) => rs.map((x) => (x.id === r.id ? { ...x, key: e.target.value } : x))); }} /></label>
            <label className="field ce-wide"><span>Policy text</span><textarea rows={2} value={r.value} onChange={(e) => { touch(); setPolicyRows((rs) => rs.map((x) => (x.id === r.id ? { ...x, value: e.target.value } : x))); }} /></label>
            <button type="button" className="btn-ghost ce-del" onClick={() => { touch(); setPolicyRows((rs) => rs.filter((x) => x.id !== r.id)); }}>Delete</button>
          </div>
        ))}
        <button type="button" className="btn-ghost" onClick={() => { touch(); setPolicyRows((rs) => [...rs, { id: rid(), key: '', value: '' }]); }}>+ Add policy</button>
      </fieldset>

      <fieldset className="ce-section" disabled={formsLocked}>
        <legend>Staff FAQ</legend>
        <p className="small muted">Answers here are quoted word-for-word to patients whose question closely matches (labelled “Staff FAQ”). Add them from a ticket with “Also save this reply as an FAQ”, or here.</p>
        {faq.map((f, i) => (
          <div key={i} className="ce-row" data-faq-row={i}>
            <label className="field ce-wide"><span>Question</span><input type="text" data-faq-field="q" value={f.q} onChange={(e) => editList<FaqEntry>('faq', (xs) => { xs[i] = { ...xs[i], q: e.target.value }; return xs; })} /></label>
            <label className="field ce-wide"><span>Answer</span><textarea rows={2} data-faq-field="a" value={f.a} onChange={(e) => editList<FaqEntry>('faq', (xs) => { xs[i] = { ...xs[i], a: e.target.value }; return xs; })} /></label>
            {f.from && <span className="small muted">From ticket {f.from}{f.addedBy ? ` · ${f.addedBy}` : ''}</span>}
            <button type="button" className="btn-ghost ce-del" data-action="delete-faq" onClick={() => editList<FaqEntry>('faq', (xs) => xs.filter((_, j) => j !== i))}>Delete</button>
          </div>
        ))}
        <button type="button" className="btn-ghost" data-action="add-faq" onClick={() => editList<FaqEntry>('faq', (xs) => [...xs, { q: '', a: '' }])}>+ Add FAQ</button>
      </fieldset>

      <details className="ce-section ce-advanced" open={jsonDirty}>
        <summary>Advanced — raw clinic file (JSON)</summary>
        <p className="small muted">Paste a replacement clinic file here (e.g. hidden test data), then press Save. Invalid JSON is never saved. While you edit here, the forms above are paused.</p>
        <textarea id="clinic-json" spellCheck={false} rows={18} value={shownJson} onChange={(e) => { setJsonText(e.target.value); setJsonDirty(true); setDirty(true); setMsg(null); }} />
        {jsonDirty && <button type="button" className="btn-ghost" onClick={() => { setJsonDirty(false); setErrors([]); }}>Discard JSON edits</button>}
      </details>
    </div>
  );
}
