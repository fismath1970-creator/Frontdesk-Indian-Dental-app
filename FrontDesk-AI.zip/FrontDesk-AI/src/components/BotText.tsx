import { Fragment } from 'react';

/** Renders reply text, turning the clinic's own phone numbers into tap-to-call links. */
export function BotText({ text, phones }: { text: string; phones: string[] }) {
  const uniq = [...new Set(phones.filter(Boolean))].sort((a, b) => b.length - a.length);
  const esc = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const re = uniq.length ? new RegExp(`(${uniq.map(esc).join('|')})`, 'g') : null;
  return (
    <>
      {text.split('\n').map((line, i) => (
        <Fragment key={i}>
        {i > 0 && '\n'}
        <p className="bot-line">
          {re
            ? line.split(re).map((chunk, j) =>
                uniq.includes(chunk) ? (
                  <a key={j} className="tel-link" href={`tel:${chunk.replace(/[^\d+]/g, '')}`}>{chunk}</a>
                ) : (
                  <Fragment key={j}>{chunk}</Fragment>
                ),
              )
            : line}
        </p>
        </Fragment>
      ))}
    </>
  );
}
