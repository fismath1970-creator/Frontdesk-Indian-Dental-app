import { useRef, useState } from 'react';
import type { Ticket } from '../tickets/types.ts';
import type { Ageing } from '../tickets/sla.ts';
import { BookingPanel } from './BookingPanel.tsx';

const fmt = (iso: string) => new Date(iso).toLocaleString('en-IN', { timeZone: 'Asia/Kolkata', day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
export function age(iso: string, now = Date.now()): string {
  const mins = Math.max(0, Math.floor((now - Date.parse(iso)) / 60000));
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins} min ago`;
  const h = Math.floor(mins / 60);
  if (h < 24) return `${h} h ${mins % 60} min ago`;
  return `${Math.floor(h / 24)} d ${h % 24} h ago`;
}
export function duration(mins: number): string {
  if (mins < 60) return `${mins} min`;
  const h = Math.floor(mins / 60);
  if (h < 24) return `${h} h ${String(mins % 60).padStart(2, '0')} min`;
  return `${Math.floor(h / 24)} d ${h % 24} h`;
}
const BAND_LABEL: Record<Ageing['band'], string> = { new: 'New', waiting: 'Waiting', delayed: 'Delayed', overdue: 'Overdue', handled: 'Handled', closed: 'Closed', emergency: 'Emergency' };
const timeOf = (iso: string) => new Date(iso).toLocaleString('en-IN', { timeZone: 'Asia/Kolkata', weekday: 'short', hour: '2-digit', minute: '2-digit' });

export function AgeingBar({ a }: { a: Ageing }) {
  let detail: string;
  if (a.band === 'emergency') detail = `Emergency line case · open for ${duration(a.ageMinutes)} — not covered by the 2-hour callback promise; act now`;
  else if (a.band === 'closed') detail = `Closed · total age ${duration(a.ageMinutes)}`;
  else if (a.band === 'handled') detail = a.respondedAt ? `Staff responded · ${timeOf(a.respondedAt)} IST` : 'Answered from the clinic file — no callback needed';
  else if (a.band === 'overdue') detail = `Waiting ${duration(a.ageMinutes)} (${a.workingMinutesWaiting} working min) · callback was due ${timeOf(a.callbackDueAt!)} IST · overdue by ${duration(-(a.dueInWorkingMinutes ?? 0))} working time`;
  else detail = `Waiting ${duration(a.ageMinutes)} (${a.workingMinutesWaiting} working min) · callback due by ${timeOf(a.callbackDueAt!)} IST · ${duration(a.dueInWorkingMinutes ?? 0)} working time left`;
  return (
    <div className={`ageing ageing-${a.band}`} data-age-band={a.band} data-age-minutes={a.ageMinutes}>
      <span className="ageing-band">{BAND_LABEL[a.band]}</span>
      <span className="ageing-detail">{detail}</span>
    </div>
  );
}

const STATUS_LABEL: Record<string, string> = { answered: 'Answered', 'needs human': 'Needs human', urgent: 'Urgent', closed: 'Closed' };
const SENDER_LABEL = { patient: 'Patient', bot: 'FrontDesk AI', staff: 'Staff' } as const;
const SHOW_LAST = 6;

interface Props {
  ticket: Ticket;
  emergencyPhone?: string;
  draft: string;
  onDraft: (v: string) => void;
  onReply: (text: string, saveFaq: boolean) => Promise<{ savedFaqVersion?: number } | unknown>;
  onClose: () => Promise<unknown>;
  onReopen: () => Promise<unknown>;
  onAssign: () => Promise<unknown>;
  onDecide: (input: { decision: 'confirm' | 'reject'; date?: string; time?: string; note?: string }) => Promise<unknown>;
}

export function TicketCard({ ticket: t, emergencyPhone, draft, onDraft, onReply, onClose, onReopen, onAssign, onDecide }: Props) {
  const replyRef = useRef<HTMLTextAreaElement>(null);
  const [feedback, setFeedback] = useState<{ tone: 'ok' | 'err'; text: string } | null>(null);
  const [sending, setSending] = useState(false);
  const [showAll, setShowAll] = useState(false);
  const faqRef = useRef<HTMLInputElement>(null);
  const canTeach = t.status === 'needs human' && t.type !== 'booking' && t.type !== 'emergency';
  const msgs = showAll ? t.messages : t.messages.slice(-SHOW_LAST);
  const hidden = t.messages.length - msgs.length;
  const staffReplies = t.messages.filter((m) => m.sender === 'staff').length;

  const run = async (fn: () => Promise<unknown>, okText: string) => {
    setSending(true); setFeedback(null);
    try { await fn(); setFeedback({ tone: 'ok', text: okText }); } catch (e) { setFeedback({ tone: 'err', text: e instanceof Error ? e.message : 'Action failed — please retry.' }); } finally { setSending(false); }
  };

  const send = () => {
    const el = replyRef.current; // read the DOM value so programmatic fills by test harnesses also work
    const text = (el?.value || '').trim();
    if (!text) { setFeedback({ tone: 'err', text: 'Type a reply first.' }); el?.focus(); return; }
    const saveFaq = !!(canTeach && faqRef.current?.checked);
    setSending(true); setFeedback(null);
    void (async () => {
      try {
        const res = (await onReply(text, saveFaq)) as { savedFaqVersion?: number } | undefined;
        if (el) el.value = ''; onDraft('');
        setFeedback({ tone: 'ok', text: res?.savedFaqVersion ? `Reply sent ✓ · saved as an FAQ (clinic file v${res.savedFaqVersion})` : 'Reply sent to the patient’s chat ✓' });
      } catch (e) { setFeedback({ tone: 'err', text: e instanceof Error ? e.message : 'Action failed — please retry.' }); } finally { setSending(false); }
    })();
  };

  return (
    <article
      className={`ticket ticket-${t.status.replace(' ', '-')} prio-${t.priority}`}
      data-ticket={t.id}
      data-status={t.status}
      data-priority={t.priority}
      data-category={t.category}
      data-type={t.type}
      data-age-band={t.ageing?.band}
      data-age-minutes={t.ageing?.ageMinutes}
      data-lang={t.lang}
      {...(t.type === 'booking' ? { 'data-requested-time': t.requestedTime || '' } : {})}
      {...(t.booking?.outsideHours ? { 'data-outside-hours': 'true' } : {})}
      aria-label={`Ticket ${t.id}, ${STATUS_LABEL[t.status]}, ${t.priority} priority`}
    >
      {t.status === 'urgent' && (
        <div className="ticket-urgent-banner">🚨 EMERGENCY — patient was told to call {emergencyPhone || 'the emergency line'} and go to the nearest hospital. Follow up immediately.</div>
      )}
      <header className="ticket-head">
        <div className="ticket-badges">
          <span className={`badge status-${t.status.replace(' ', '-')}`}>{STATUS_LABEL[t.status]}</span>
          <span className={`badge prio prio-badge-${t.priority}`}>{t.priority === 'critical' ? '▲▲ Critical' : t.priority === 'high' ? '▲ High' : t.priority === 'normal' ? 'Normal' : 'Low'} priority</span>
          <span className="badge cat">{t.category}</span>
          {t.source && <span className={`badge src-badge src-${t.source}`} data-answer-source={t.source} title={t.aiNote || ''}>{t.source === 'ai' ? 'AI-worded' : 'Clinic file'}</span>}
          <span className={`badge lang-badge lang-${t.lang}`} title="Patient's language">{t.lang === 'hi' ? 'हिंदी · HI' : t.lang === 'te' ? 'తెలుగు · TE' : 'EN'}</span>
          {t.booking?.outsideHours && <span className="badge outside-badge" data-flag="outside-hours">⚠ Outside clinic hours</span>}
        </div>
        <code className="ticket-id">{t.id}</code>
      </header>

      {t.ageing && <AgeingBar a={t.ageing} />}

      <dl className="ticket-facts">
        <div><dt>Patient</dt><dd>{t.patientName || <span className="muted">Name not given</span>}</dd></div>
        <div><dt>Phone</dt><dd>{t.phone ? <a href={`tel:${t.phone.replace(/[^\d+]/g, '')}`}>{t.phone}</a> : <span className="muted">Not given</span>}</dd></div>
        <div><dt>Created</dt><dd>{fmt(t.createdAt)}</dd></div>
        <div><dt>Waiting</dt><dd>{t.ageing ? `${t.ageing.ageMinutes} min (${(t.ageing.ageMinutes / 60).toFixed(1)} h)` : age(t.createdAt)}</dd></div>
        <div><dt>Last updated</dt><dd>{fmt(t.updatedAt)}</dd></div>
        <div><dt>Assigned</dt><dd>{t.assignedTo || <span className="muted">Unassigned</span>}</dd></div>
        <div><dt>Staff replies</dt><dd>{staffReplies}</dd></div>
      </dl>

      {t.aiNote && <p className="small muted ai-note">AI: {t.aiNote}</p>}
      <blockquote className="ticket-question"><span className="muted small">Original question</span>{t.question}</blockquote>

      {t.type === 'booking' && t.booking && <BookingPanel ticket={t} onDecide={onDecide} />}

      <details className="ticket-convo" open>
        <summary>Conversation ({t.messages.length} messages)</summary>
        {hidden > 0 && <button type="button" className="btn-link" onClick={() => setShowAll(true)}>Show {hidden} earlier messages</button>}
        <ol>
          {msgs.map((m) => (
            <li key={m.id} className={`cm cm-${m.sender}`}>
              <span className="cm-who">{m.sender === 'staff' ? `Staff · ${m.staffName || ''}` : SENDER_LABEL[m.sender]} · {fmt(m.createdAt)}</span>
              <span className="cm-text">{m.text}</span>
            </li>
          ))}
        </ol>
      </details>

      <div className="ticket-reply">
        <label className="reply-label">
          <span>Reply to patient</span>
          <textarea
            id="staff-reply"
            ref={replyRef}
            name="staff-reply"
            rows={3}
            maxLength={2000}
            defaultValue={draft}
            onInput={(e) => onDraft((e.target as HTMLTextAreaElement).value)}
            placeholder="Your reply appears in the patient’s chat…"
          />
        </label>
        {canTeach && (
          <label className="faq-check">
            <input ref={faqRef} type="checkbox" name="save-faq" data-action="save-faq" />
            <span>Also save this reply as an FAQ <span className="muted small">(the bot will answer this question with your exact words next time)</span></span>
          </label>
        )}
        <div className="ticket-actions">
          <button id="staff-send" type="button" className="btn-primary" onClick={send} disabled={sending}>Send reply</button>
          {t.status === 'closed'
            ? <button type="button" className="btn-secondary" disabled={sending} onClick={() => void run(onReopen, 'Ticket reopened')}>Reopen ticket</button>
            : <button type="button" className="btn-secondary" data-action="close" disabled={sending} onClick={() => void run(onClose, 'Ticket closed')}>Close ticket</button>}
          {!t.assignedTo && <button type="button" className="btn-ghost" disabled={sending} onClick={() => void run(onAssign, 'Assigned to you')}>Assign to me</button>}
        </div>
        {feedback && <p className={`feedback fb-${feedback.tone}`} role="status">{feedback.text}</p>}
      </div>
    </article>
  );
}
