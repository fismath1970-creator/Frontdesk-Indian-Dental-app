// HTTP API for FrontDesk AI. Framework-free (Web Request/Response) so the same
// code runs in the Netlify Function and in the local test server.
import { NotFoundError, ValidationError, type TicketService } from '../tickets/service.ts';
import { VersionConflictError } from '../tickets/errors.ts';
import type { ClinicStore } from '../clinic/store.ts';
import { buildMessages, MAX_CLINIC_BYTES } from '../ai/prompt.ts';
import { callModel, type AiEnv } from '../ai/provider.ts';
import { validateAiReply } from '../ai/validate.ts';
import { allow, clientIp } from '../ai/ratelimit.ts';
import type { ClinicData, Lang } from '../engine/types.ts';
import { ConflictError } from '../tickets/kv.ts';

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' } });

async function body(req: Request): Promise<Record<string, unknown>> {
  try { const b = await req.json(); return b && typeof b === 'object' ? (b as Record<string, unknown>) : {}; } catch { throw new ValidationError('Request body must be JSON.'); }
}

export async function handleApi(req: Request, svc: TicketService, info: { storage: string }, clinic?: ClinicStore, aiEnv?: () => AiEnv): Promise<Response> {
  const url = new URL(req.url);
  const path = url.pathname.replace(/^\/(\.netlify\/functions\/)?api/, '').replace(/\/+$/, '') || '/';
  const m = req.method.toUpperCase();
  try {
    if (path === '/health' && m === 'GET') return json({ ok: true, service: 'frontdesk', storage: info.storage });
    if (clinic && path === '/clinic' && m === 'GET') return json({ clinic: await clinic.get() });
    if (clinic && path === '/clinic' && (m === 'PUT' || m === 'POST')) {
      const b = await body(req);
      const base = typeof b.baseVersion === 'number' ? b.baseVersion : undefined;
      return json({ clinic: await clinic.save(b.data, base, typeof b.staffName === 'string' && b.staffName.trim() ? b.staffName.trim().slice(0, 60) : 'Clinic staff') });
    }
    if (clinic && path === '/clinic/reset' && m === 'POST') {
      const b = await body(req);
      if (b.confirm !== true) throw new ValidationError('Reset needs confirm: true.');
      return json({ clinic: await clinic.reset(typeof b.staffName === 'string' && b.staffName.trim() ? b.staffName.trim().slice(0, 60) : 'Clinic staff') });
    }
    if (path === '/chat' && m === 'POST') { const b = await body(req); return json(await svc.handleChat({ conversationId: b.conversationId, message: b.message, clientMessageId: b.clientMessageId, noAI: b.noAI === true, via: b.via })); }
    if (path === '/ask' && m === 'POST') return await ask(req, aiEnv ? aiEnv() : {});
    if (path === '/conversation' && m === 'GET') return json(await svc.getConversation(url.searchParams.get('id')));
    if (path === '/tickets' && m === 'GET') {
      const sort = url.searchParams.get('sort');
      return json({ tickets: await svc.listTickets(sort === 'oldest' || sort === 'newest' ? sort : 'priority') });
    }
    const tm = path.match(/^\/tickets\/([A-Za-z0-9_-]{8,80})(?:\/(reply|status|assign|booking))?$/);
    if (tm) {
      const [, id, action] = tm;
      if (!action && m === 'GET') { const t = await svc.getTicket(id); return t ? json({ ticket: t }) : json({ error: 'Ticket not found.' }, 404); }
      if (m === 'POST' && action === 'reply') { const b = await body(req); return json({ ticket: await svc.staffReply(id, { text: b.text, staffName: b.staffName, saveFaq: b.saveFaq }) }); }
      if (m === 'POST' && action === 'status') { const b = await body(req); return json({ ticket: await svc.setStatus(id, { status: b.status, staffName: b.staffName }) }); }
      if (m === 'POST' && action === 'booking') { const b = await body(req); return json({ ticket: await svc.decideBooking(id, { decision: b.decision, date: b.date, time: b.time, note: b.note, staffName: b.staffName }) }); }
      if (m === 'POST' && action === 'assign') { const b = await body(req); return json({ ticket: await svc.assign(id, { staffName: b.staffName }) }); }
    }
    return json({ error: 'Not found.' }, 404);
  } catch (e) {
    if (e instanceof ValidationError) return json({ error: e.message, details: e.details || [] }, 400);
    if (e instanceof VersionConflictError) return json({ error: e.message, currentVersion: e.current }, 409);
    if (e instanceof NotFoundError) return json({ error: e.message }, 404);
    if (e instanceof ConflictError) return json({ error: 'Busy, please retry.' }, 409);
    console.error('[frontdesk api]', e);
    return json({ error: 'Something went wrong.' }, 500);
  }
}

/**
 * POST /api/ask {message, lang, clinic, facts} — ONE model call, no tools, no retries.
 * 503 {"error":"no_key"} when AI_API_KEY is missing/empty. Errors never contain key details.
 */
async function ask(req: Request, env: AiEnv): Promise<Response> {
  if (!env.apiKey) return json({ error: 'no_key' }, 503);
  if (!allow(clientIp(req))) return json({ error: 'rate_limited' }, 429);
  const b = await body(req);
  const message = typeof b.message === 'string' ? b.message.trim() : '';
  const lang = (['en', 'hi', 'te'].includes(String(b.lang)) ? b.lang : 'en') as Lang;
  const clinic = b.clinic as ClinicData;
  const facts = Array.isArray(b.facts) ? b.facts.filter((f): f is string => typeof f === 'string').slice(0, 20).map((f) => f.slice(0, 1000)) : [];
  if (!message || message.length > 1000) return json({ error: 'bad_message' }, 400);
  if (!clinic || typeof clinic !== 'object' || !clinic.clinic) return json({ error: 'bad_clinic' }, 400);
  if (JSON.stringify(clinic).length > MAX_CLINIC_BYTES) return json({ error: 'clinic_too_large' }, 413);
  const res = await callModel(env, buildMessages({ clinic, lang, message, facts }));
  if (!res.ok) return json({ error: res.error === 'timeout' ? 'timeout' : 'model_unavailable' }, res.error === 'timeout' ? 504 : 502);
  let parsed: unknown;
  try { parsed = JSON.parse(res.content); } catch { return json({ error: 'bad_model_output' }, 502); }
  const v = validateAiReply(res.content, { clinic, message, lang, engineAnswered: false });
  return json({ reply: parsed, valid: v.ok, ...(v.ok ? {} : { reasons: v.reasons }) });
}
