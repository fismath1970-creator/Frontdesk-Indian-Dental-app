import type { KV } from '../tickets/kv.ts';

/** Structural type of the parts of a Netlify Blobs Store we use. */
export interface BlobStoreLike {
  getWithMetadata(key: string, opts: { type: 'json' }): Promise<{ data: unknown; etag?: string } | null>;
  setJSON(key: string, data: unknown, opts?: { onlyIfNew?: boolean; onlyIfMatch?: string }): Promise<{ modified: boolean; etag?: string }>;
  list(opts: { prefix: string }): Promise<{ blobs: Array<{ key: string }> }>;
}

export class BlobsKV implements KV {
  readonly namespace: string;
  private store: BlobStoreLike;
  constructor(store: BlobStoreLike, namespace = 'netlify-blobs:frontdesk') { this.store = store; this.namespace = namespace; }
  async get<T>(key: string) {
    const r = await this.store.getWithMetadata(key, { type: 'json' });
    return r && r.data != null ? { value: r.data as T, etag: r.etag || '' } : null;
  }
  async create(key: string, value: unknown) { return (await this.store.setJSON(key, value, { onlyIfNew: true })).modified; }
  async replace(key: string, value: unknown, etag: string) {
    // Netlify Blobs returns an ETag on reads; if a store does not, fall back to a plain
    // write — callers verify-after-write (updateJSON) and messages are create-only blobs.
    return (await this.store.setJSON(key, value, etag ? { onlyIfMatch: etag } : {})).modified;
  }
  async list(prefix: string) { return (await this.store.list({ prefix })).blobs.map((b) => b.key); }
}
