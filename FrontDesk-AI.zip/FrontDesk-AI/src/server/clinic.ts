import clinicFile from '../data/clinic-data.json' with { type: 'json' };
import type { ClinicData } from '../engine/types.ts';

/** The ORIGINAL uploaded clinic file: the starting point and the "Reset to original" target only. */
export const ORIGINAL_CLINIC = clinicFile as ClinicData;
