import type { BookingDetails, BookingState, Lang, Priority, TicketStatus, TicketType } from '../engine/types.ts';
import type { Ageing } from './sla.ts';

export type Sender = 'patient' | 'bot' | 'staff';

export type TicketCategory =
  | 'emergency' | 'booking' | 'human' | 'medical' | 'unsupported' | 'refusal' | 'prices' | 'doctors'
  | 'hours' | 'insurance' | 'contact & location' | 'policy' | 'general';

export interface ChatMessage {
  id: string;
  conversationId: string;
  ticketId?: string;
  sender: Sender;
  text: string;
  createdAt: string; // ISO
  staffName?: string;
  meta?: {
    status?: TicketStatus;
    ticketType?: TicketType;
    emergency?: boolean;
    source?: 'clinic-file' | 'staff-faq' | 'ai' | 'staff';
    aiSources?: string[]; // "Source: …" line for AI-worded answers
    faqMixed?: boolean;
    lang?: Lang;
    offline?: boolean;
    bookingState?: BookingState; // state of the request when this message was written
    bookingDecision?: 'confirmed' | 'rejected'; // set on the staff message that recorded a decision
    needsPhone?: boolean; // the open request still has no phone number (drives the "Add my phone number" chip)
    unknown?: boolean; // the bot could not answer from the clinic file (drives "Share my phone number")
  };
}

export interface Ticket {
  id: string;
  conversationId: string;
  patientName?: string;
  phone?: string;
  question: string; // original patient question
  category: TicketCategory;
  type: TicketType;
  status: TicketStatus;
  statusBeforeClose?: Exclude<TicketStatus, 'closed'>;
  priority: Priority;
  assignedTo?: string;
  createdAt: string;
  updatedAt: string;
  firstStaffReplyAt?: string;
  closedAt?: string;
  closedBy?: string;
  booking?: BookingDetails;
  intents: string[];
  unsupportedTopics: string[];
  lang: Lang;
  knowledgeVersion: number;
  messages: ChatMessage[]; // full conversation for this enquiry
  lastBotReply?: string;
  /** Stage 6: who wrote the first answer — the model (validated) or the engine/clinic file */
  source?: 'ai' | 'file';
  /** why the model was not used (no key, timeout, validation …) — never contains the key */
  aiNote?: string;
  /** booking: ISO with +05:30 ("2026-11-21T17:00:00+05:30"), a window ("…T16:00:00+05:30/…T20:00:00+05:30"), or null */
  requestedTime?: string | null;
  /** computed on every read from the clinic calendar (never stored) */
  ageing?: Ageing;
}

export interface Conversation {
  id: string;
  createdAt: string;
  updatedAt: string;
  ticketIds: string[];
  loose: ChatMessage[]; // greetings etc. sent before any enquiry
  patientName?: string;
  phone?: string;
  lastOffer?: 'booking';
}

export interface ChatResponse {
  conversationId: string;
  ticketId?: string;
  status?: TicketStatus;
  messages: ChatMessage[]; // [patient, bot]
}
