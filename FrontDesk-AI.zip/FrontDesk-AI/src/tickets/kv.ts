// Minimal key-value contract with optimistic concurrency (ETags).
// Implemented by Netlify Blobs (server), localStorage / memory (local demo + tests).
export interface KV {
  /** identifies the underlying store (used to scope the immutable-message cache) */
  readonly namespace?: string;
  get<T>(key: string): Promise<{ value: T; etag: string } | null>;
  /** write only if the key does not exist; false if it already exists */
  create(key: string, value: unknown): Promise<boolean>;
  /** write only if the stored ETag still matches; false if someone else wrote first */
  replace(key: string, value: unknown, etag: string): Promise<boolean>;
  list(prefix: string): Promise<string[]>;
}

export class ConflictError extends Error {}

/**
 * Read-modify-write with retry on concurrent modification.
 * `fn` must be idempotent. When `verify` is given, the stored value is re-read after
 * the write and the update is retried if a concurrent writer overwrote it (this also
 * protects stores that cannot return an ETag on read).
 */
export async function updateJSON<T>(kv: KV, key: string, fn: (current: T | null) => T, verify?: (stored: T) => boolean, attempts = 12): Promise<T> {
  for (let i = 0; i < attempts; i++) {
    const cur = await kv.get<T>(key);
    const next = fn(cur ? structuredClone(cur.value) : null);
    const ok = cur ? await kv.replace(key, next, cur.etag) : await kv.create(key, next);
    if (ok) {
      if (!verify) return next;
      const stored = await kv.get<T>(key);
      if (stored && verify(stored.value)) return stored.value;
    }
    await new Promise((r) => setTimeout(r, 5 + Math.random() * 25 * (i + 1)));
  }
  throw new ConflictError(`Too many concurrent updates to ${key}`);
}

/** In-memory store (tests, and the last-resort fallback when browser storage is blocked). */
export class MemoryKV implements KV {
  readonly namespace = `mem-${Math.random().toString(36).slice(2)}`;
  private m = new Map<string, { json: string; etag: string }>();
  private n = 0;
  async get<T>(key: string) { const e = this.m.get(key); return e ? { value: JSON.parse(e.json) as T, etag: e.etag } : null; }
  async create(key: string, value: unknown) { if (this.m.has(key)) return false; this.m.set(key, { json: JSON.stringify(value), etag: String(++this.n) }); return true; }
  async replace(key: string, value: unknown, etag: string) { const e = this.m.get(key); if (!e || e.etag !== etag) return false; this.m.set(key, { json: JSON.stringify(value), etag: String(++this.n) }); return true; }
  async list(prefix: string) { return [...this.m.keys()].filter((k) => k.startsWith(prefix)); }
}

/** Browser localStorage store — LOCAL DEMO MODE ONLY (shared only within one browser). */
export class LocalStorageKV implements KV {
  readonly namespace = 'localStorage';
  private ls: Storage;
  private prefix: string;
  constructor(ls: Storage, prefix = 'frontdesk:') { this.ls = ls; this.prefix = prefix; }
  private read(key: string): { v: unknown; e: string } | null { const raw = this.ls.getItem(this.prefix + key); return raw ? JSON.parse(raw) : null; }
  private write(key: string, v: unknown) { this.ls.setItem(this.prefix + key, JSON.stringify({ v, e: `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}` })); }
  async get<T>(key: string) { const r = this.read(key); return r ? { value: r.v as T, etag: r.e } : null; }
  async create(key: string, value: unknown) { if (this.read(key)) return false; this.write(key, value); return true; }
  async replace(key: string, value: unknown, etag: string) { const r = this.read(key); if (!r || r.e !== etag) return false; this.write(key, value); return true; }
  async list(prefix: string) {
    const out: string[] = [];
    for (let i = 0; i < this.ls.length; i++) { const k = this.ls.key(i); if (k && k.startsWith(this.prefix + prefix)) out.push(k.slice(this.prefix.length)); }
    return out;
  }
}
