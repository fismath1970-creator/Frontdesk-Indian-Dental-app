export class ValidationError extends Error {
  details: string[];
  constructor(message: string, details: string[] = []) { super(message); this.details = details; }
}
export class NotFoundError extends Error {}
export class VersionConflictError extends Error {
  current: number;
  constructor(current: number) { super(`The clinic file was changed elsewhere (now v${current}). Reload it before saving.`); this.current = current; }
}
