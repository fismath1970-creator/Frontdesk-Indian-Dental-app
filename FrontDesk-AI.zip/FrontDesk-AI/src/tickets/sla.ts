// Ticket ageing (2-working-hour callback target) and dynamic priority.
// Priority is computed from the ticket's nature and waiting time — not copied from its status.
import { addWorkingMinutes, workingMinutesBetween, type ClinicCalendar } from '../engine/schedule.ts';
import { istDate, addDays } from '../engine/datetime.ts';
import type { Priority } from '../engine/types.ts';
import type { Ticket } from './types.ts';

export const CALLBACK_TARGET_MIN = 120; // "within 2 working hours"
export const APPROACHING_MIN = 30; // high priority when the deadline is this close

export type AgeBand = 'new' | 'waiting' | 'delayed' | 'overdue' | 'handled' | 'closed' | 'emergency';

export interface Ageing {
  ageMinutes: number; // wall-clock since creation
  awaitingHuman: boolean; // a person still has to respond
  awaitingSince?: string;
  workingMinutesWaiting?: number; // working time since awaitingSince
  callbackDueAt?: string;
  dueInWorkingMinutes?: number; // negative when overdue
  band: AgeBand;
  respondedAt?: string;
}

type AgeableTicket = Pick<Ticket, 'createdAt' | 'status' | 'type' | 'messages' | 'booking'>;

/** When did the current wait for a human start? (first patient message after the last staff message) */
function awaitingSince(t: AgeableTicket): string | undefined {
  if (t.status !== 'needs human' && t.status !== 'urgent') return undefined;
  const lastStaff = [...t.messages].reverse().find((m) => m.sender === 'staff');
  if (!lastStaff) return t.createdAt;
  return t.messages.find((m) => m.sender === 'patient' && m.createdAt > lastStaff.createdAt)?.createdAt;
}

export function computeAgeing(t: AgeableTicket, cal: ClinicCalendar, now: Date): Ageing {
  const ageMinutes = Math.max(0, Math.floor((now.getTime() - Date.parse(t.createdAt)) / 60000));
  const respondedAt = t.messages.find((m) => m.sender === 'staff')?.createdAt;
  if (t.status === 'closed') return { ageMinutes, awaitingHuman: false, band: 'closed', respondedAt };
  const since = awaitingSince(t);
  if (t.type === 'emergency' && t.status === 'urgent') {
    // emergencies are handled by the emergency line, not the 2-hour callback promise
    return { ageMinutes, awaitingHuman: !!since, awaitingSince: since, band: 'emergency', respondedAt };
  }
  if (!since) return { ageMinutes, awaitingHuman: false, band: 'handled', respondedAt };
  const start = new Date(since);
  const worked = workingMinutesBetween(cal, start, now);
  const due = addWorkingMinutes(cal, start, CALLBACK_TARGET_MIN);
  const overdue = now.getTime() > due.getTime();
  // positive: working minutes left; negative: working minutes overdue (at least -1 once past the deadline)
  const dueIn = overdue ? Math.min(-1, -workingMinutesBetween(cal, due, now)) : CALLBACK_TARGET_MIN - worked;
  const band: AgeBand = overdue ? 'overdue' : worked >= 60 ? 'delayed' : worked >= 15 ? 'waiting' : 'new';
  return { ageMinutes, awaitingHuman: true, awaitingSince: since, workingMinutesWaiting: worked, callbackDueAt: due.toISOString(), dueInWorkingMinutes: dueIn, band, respondedAt };
}

/** Booking for today or the next calendar day that still awaits a decision → time-sensitive. */
function timeSensitiveBooking(t: AgeableTicket, now: Date): boolean {
  const b = t.booking;
  if (t.type !== 'booking' || !b?.requestedDate || b.state === 'confirmed' || b.state === 'rejected') return false;
  const today = istDate(now);
  return b.requestedDate === today || b.requestedDate === addDays(today, 1);
}

export function computePriority(t: AgeableTicket, a: Ageing, now: Date): Priority {
  if (t.type === 'emergency') return 'critical'; // stays critical whatever the status
  if (t.status === 'closed') return 'low';
  if (a.awaitingHuman && (a.band === 'overdue' || (a.dueInWorkingMinutes ?? Infinity) <= APPROACHING_MIN)) return 'high';
  if (t.status === 'needs human' && timeSensitiveBooking(t, now)) return 'high';
  if (t.status === 'needs human' || a.awaitingHuman) return 'normal'; // booking requests, unanswered enquiries
  return 'low'; // routine answered enquiries
}

const PRIORITY_RANK: Record<Priority, number> = { critical: 3, high: 2, normal: 1, low: 0 };
export type SortMode = 'priority' | 'oldest' | 'newest';

/** Open emergencies always first; then the chosen order; closed tickets last. */
export function sortQueue<T extends Pick<Ticket, 'status' | 'type' | 'priority' | 'createdAt' | 'updatedAt'>>(ts: T[], mode: SortMode = 'priority'): T[] {
  const group = (t: T) => (t.status === 'closed' ? 2 : t.type === 'emergency' ? 0 : 1);
  return [...ts].sort((a, b) => {
    const g = group(a) - group(b);
    if (g) return g;
    if (group(a) === 2) return b.updatedAt.localeCompare(a.updatedAt);
    if (mode === 'oldest') return a.createdAt.localeCompare(b.createdAt);
    if (mode === 'newest') return b.createdAt.localeCompare(a.createdAt);
    return PRIORITY_RANK[b.priority] - PRIORITY_RANK[a.priority] || a.createdAt.localeCompare(b.createdAt);
  });
}
