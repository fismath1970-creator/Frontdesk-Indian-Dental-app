// FrontDesk AI — ticket service. Pure logic over a KV store, shared by the
// Netlify Function (server mode) and the browser (local demo mode).
import { answerQuestion, getIndex, stripContact } from '../engine/engine.ts';
import { buildCalendar } from '../engine/schedule.ts';
import { T } from '../engine/templates.ts';
import { computeAgeing, computePriority, sortQueue, type SortMode } from './sla.ts';
import { aiEligible, type AiOutcome } from '../ai/answer.ts';
import type { BookingDetails, ClinicData, EngineResult, FaqEntry, TicketStatus } from '../engine/types.ts';
import { updateJSON, type KV } from './kv.ts';
import type { ChatMessage, ChatResponse, Conversation, Ticket, TicketCategory } from './types.ts';

export const LIMITS = { message: 1000, reply: 2000, staffName: 60 };
const ID_RE = /^[A-Za-z0-9_-]{8,80}$/;
const FOLLOW_UP_WINDOW_MS = 24 * 60 * 60 * 1000;

import { NotFoundError, ValidationError } from './errors.ts';
export { NotFoundError, ValidationError };

const tKey = (id: string) => `ticket/${id}`;
const cKey = (id: string) => `conv/${id}`;
// Messages are immutable, create-only records: concurrent writers can never overwrite one another.
const mKey = (m: ChatMessage) => `msg/${m.ticketId}/${String(Date.parse(m.createdAt)).padStart(14, '0')}_${m.id}`;
type TicketDoc = Omit<Ticket, 'messages'>;

// Immutable messages can be cached forever (per store) — keeps dashboard polling cheap.
const MSG_CACHE = new Map<string, ChatMessage>();
function cacheKey(kv: KV, key: string) { return `${kv.namespace || 'kv'}|${key}`; }

function rand(n: number): string {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const bytes = new Uint8Array(n);
  globalThis.crypto.getRandomValues(bytes);
  return [...bytes].map((b) => alphabet[b % alphabet.length]).join('');
}
export function newId(): string {
  const c = globalThis.crypto as Crypto & { randomUUID?: () => string };
  return c.randomUUID ? c.randomUUID() : `${Date.now().toString(36)}-${rand(16)}`;
}
function newTicketId(now: Date): string {
  const ymd = new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Kolkata', year: '2-digit', month: '2-digit', day: '2-digit' }).format(now).replace(/-/g, '');
  return `BR-${ymd}-${rand(6)}`;
}

const STATUS_RANK: Record<TicketStatus, number> = { answered: 0, 'needs human': 1, urgent: 2, closed: -1 };
const maxStatus = (a: TicketStatus, b: TicketStatus) => (STATUS_RANK[b] > STATUS_RANK[a] ? b : a);

/** ISO (+05:30) for an exact time, "start/end" for a window, null when no day+time yet */
export function requestedTimeOf(b?: BookingDetails): string | null {
  if (!b?.requestedDate) return null;
  if (b.requestedTime) return `${b.requestedDate}T${b.requestedTime}:00+05:30`;
  if (b.requestedWindow) return `${b.requestedDate}T${b.requestedWindow.from}:00+05:30/${b.requestedDate}T${b.requestedWindow.to}:00+05:30`;
  return null;
}

export function categorize(r: Pick<EngineResult, 'intents' | 'emergency' | 'ticketType'>): TicketCategory {
  const i = new Set(r.intents);
  if (r.emergency) return 'emergency';
  if (i.has('ai-answer')) return 'general';
  if (i.has('booking')) return 'booking';
  if (i.has('human') || r.ticketType === 'human') return 'human';
  if (i.has('medical')) return 'medical';
  if ([...i].some((x) => x.startsWith('unsupported')) || r.ticketType === 'unsupported') return 'unsupported';
  if (i.has('refusal')) return 'refusal';
  if (i.has('insurance')) return 'insurance';
  if (i.has('service') || i.has('price-list')) return 'prices';
  if (i.has('doctor')) return 'doctors';
  if (i.has('hours')) return 'hours';
  if (i.has('location') || i.has('contact')) return 'contact & location';
  if (i.has('policy')) return 'policy';
  return 'general';
}

function cleanText(v: unknown, max: number, field: string): string {
  if (typeof v !== 'string') throw new ValidationError(`${field} must be text.`);
  const s = v.replace(/\u0000/g, '').trim();
  if (!s) throw new ValidationError(`${field} cannot be empty.`);
  if (s.length > max) throw new ValidationError(`${field} is too long (max ${max} characters).`);
  return s;
}
function checkId(v: unknown, field: string): string {
  if (typeof v !== 'string' || !ID_RE.test(v)) throw new ValidationError(`Invalid ${field}.`);
  return v;
}

export interface ServiceOptions {
  kv: KV;
  /** MUST read the current clinic file from the store on every call (no caching) */
  getClinic: () => Promise<{ data: ClinicData; version: number }> | { data: ClinicData; version: number };
  /** saves a staff-approved FAQ into the clinic file (bumps its version); returns the new version */
  addFaq?: (entry: FaqEntry, by: string) => Promise<{ version: number }>;
  /** Stage 6: ONE model call that may re-word a fact answer; returns a validated outcome or a fallback */
  ai?: (input: { message: string; lang: EngineResult['lang']; clinic: ClinicData; facts: string[]; engineReply: string; engineAnswered: boolean }) => Promise<AiOutcome>;
  now?: () => Date;
}

export function createTicketService(opts: ServiceOptions) {
  const { kv } = opts;
  const now = () => (opts.now ? opts.now() : new Date());

  async function getMessage(key: string): Promise<ChatMessage | null> {
    const ck = cacheKey(kv, key);
    const hit = MSG_CACHE.get(ck);
    if (hit) return hit;
    const v = (await kv.get<ChatMessage>(key))?.value ?? null;
    if (v) { if (MSG_CACHE.size > 20000) MSG_CACHE.clear(); MSG_CACHE.set(ck, v); }
    return v;
  }
  async function fetchMessages(keys: string[]): Promise<ChatMessage[]> {
    const out: ChatMessage[] = [];
    const sorted = [...keys].sort();
    for (let i = 0; i < sorted.length; i += 25) {
      const chunk = await Promise.all(sorted.slice(i, i + 25).map(getMessage));
      for (const m of chunk) if (m) out.push(m);
    }
    return out;
  }
  async function appendMessages(...msgs: ChatMessage[]) {
    // create-only; "already exists" means a retry of the same message — fine (idempotent)
    for (const m of msgs) await kv.create(mKey(m), m);
  }
  async function getDoc(id: string): Promise<TicketDoc | null> {
    const v = (await kv.get<TicketDoc & { messages?: ChatMessage[] }>(tKey(id)))?.value ?? null;
    if (v && 'messages' in v) delete v.messages;
    return v;
  }
  async function calendar() {
    const { data, version } = await opts.getClinic();
    return buildCalendar(getIndex(data, version));
  }
  /** attach live ageing + priority (computed from the clinic's working hours and holidays) */
  function enrich(t: Ticket, cal: ReturnType<typeof buildCalendar>, at: Date): Ticket {
    const ageing = computeAgeing(t, cal, at);
    return { ...t, ageing, priority: computePriority(t, ageing, at) };
  }
  async function getTicket(id: string): Promise<Ticket | null> {
    const doc = await getDoc(id);
    if (!doc) return null;
    const messages = await fetchMessages(await kv.list(`msg/${id}/`));
    return enrich({ ...doc, messages: messages.filter((m) => m.ticketId === id) }, await calendar(), now());
  }
  const updateDoc = (id: string, fn: (cur: TicketDoc) => TicketDoc, verify: (d: TicketDoc) => boolean) =>
    updateJSON<TicketDoc>(kv, tKey(id), (cur) => { if (!cur) throw new NotFoundError('Ticket not found.'); return fn(cur); }, verify);

  async function handleChat(input: { conversationId?: unknown; message: unknown; clientMessageId?: unknown; noAI?: unknown; via?: unknown }): Promise<ChatResponse> {
    const text = cleanText(input.message, LIMITS.message, 'Message');
    const conversationId = input.conversationId == null || input.conversationId === '' ? newId() : checkId(input.conversationId, 'conversation id');
    const patientMsgId = typeof input.clientMessageId === 'string' && ID_RE.test(input.clientMessageId) ? input.clientMessageId : newId();
    const t0 = now();
    const { data, version } = await opts.getClinic();

    const conv = (await kv.get<Conversation>(cKey(conversationId)))?.value ?? null;
    // idempotency: a retried send with the same client message id returns the stored answer
    if (conv) {
      for (const tid of [...conv.ticketIds].reverse().slice(0, 3)) {
        const t = await getTicket(tid);
        const i = t?.messages.findIndex((m) => m.id === patientMsgId) ?? -1;
        if (t && i >= 0) return { conversationId, ticketId: t.id, status: t.status, messages: t.messages.slice(i, i + 2) };
      }
      const li = conv.loose.findIndex((m) => m.id === patientMsgId);
      if (li >= 0) return { conversationId, messages: conv.loose.slice(li, li + 2) };
    }

    const latestId = conv?.ticketIds[conv.ticketIds.length - 1];
    const latest = latestId ? await getTicket(latestId) : null;
    const fresh = (t: Ticket | null) => !!t && t.status !== 'closed' && t0.getTime() - Date.parse(t.updatedAt) < FOLLOW_UP_WINDOW_MS;
    const latestOpen = fresh(latest) ? latest : null;
    // the most recent unconfirmed booking in this conversation (a quick question like "Doctors" in between
    // must not make the patient start the booking again)
    let bookingOpen: Ticket | null = latestOpen && latestOpen.type === 'booking' ? latestOpen : null;
    // only look back when the latest ticket was simply answered (a quick question); a newer enquiry that
    // still waits for a person is the patient's current topic and keeps their details
    if (!bookingOpen && conv && (!latestOpen || latestOpen.status === 'answered')) for (const tid of [...conv.ticketIds].reverse().slice(1, 6)) {
      const t = await getTicket(tid);
      if (fresh(t) && t!.type === 'booking') { bookingOpen = t; break; }
    }
    // any booking request that staff have not confirmed can still receive details from the patient
    const pendingBooking = bookingOpen && bookingOpen.booking && bookingOpen.booking.state !== 'confirmed' ? bookingOpen.booking : undefined;
    const open = latestOpen;

    let result = answerQuestion(text, data, {
      now: t0,
      knowledgeVersion: version,
      lastOffer: open ? conv?.lastOffer : undefined,
      pendingBooking,
      knownContact: { name: conv?.patientName, phone: conv?.phone },
      hasOpenTicket: !!open,
    });

    // Stage 6 — the model may only RE-WORD eligible fact answers / generic unknowns. Code decides the rest.
    let answerSource: 'ai' | 'file' = 'file';
    let aiNote: string | undefined;
    const eligible = aiEligible(result, typeof input.via === 'string' ? input.via : undefined);
    if (opts.ai && eligible && input.noAI !== true) {
      const out = await opts.ai({ message: text, lang: result.lang, clinic: data, facts: result.parts.filter((p) => p.kind !== 'unsupported').map((p) => p.text), engineReply: result.reply, engineAnswered: eligible === 'fact' }).catch(() => ({ kind: 'fallback', reason: 'error' }) as AiOutcome);
      if (out.kind === 'answer') {
        answerSource = 'ai';
        result = { ...result, reply: out.reply.answer, source: 'ai', aiSources: out.reply.sources, status: 'answered', priority: 'low', ticketRequired: false,
          ticketType: 'enquiry', unsupportedTopics: [], intents: eligible === 'unknown' ? ['ai-answer'] : result.intents, parts: [{ kind: 'clinic-info', key: 'ai', text: out.reply.answer }] };
      } else if (out.kind === 'unanswerable') {
        aiNote = eligible === 'fact' ? 'model said not answerable — engine answer kept' : 'model said not answerable — needs human';
      } else aiNote = `model not used: ${out.reason}`;
    } else if (opts.ai && eligible && input.noAI === true) aiNote = 'model skipped (?nokey=1)';

    const patientMsg: ChatMessage = { id: patientMsgId, conversationId, sender: 'patient', text, createdAt: t0.toISOString() };
    const botMsg: ChatMessage = {
      id: newId(), conversationId, sender: 'bot', text: result.reply, createdAt: new Date(t0.getTime() + 1).toISOString(),
      meta: { status: result.status, ticketType: result.ticketType, emergency: result.emergency, source: result.source, ...(result.aiSources ? { aiSources: result.aiSources } : {}), ...(result.faqMixed ? { faqMixed: true } : {}), lang: result.lang, ...(result.booking?.state ? { bookingState: result.booking.state } : {}),
        ...(result.booking && !result.booking.phone ? { needsPhone: true } : {}),
        ...(result.unsupportedTopics.length && !result.emergency ? { unknown: true } : {}) },
    };
    const contact = result.contact || {};

    let ticketId: string | undefined;
    let status: TicketStatus | undefined;
    const joinable = !result.emergency && !!result.followUp;

    const target = (result.followUp === 'booking-update' || result.followUp === 'booking-start') && bookingOpen ? bookingOpen : open;
    if (joinable && target) {
      // Follow-up for the same enquiry: append to the existing ticket.
      ticketId = target.id;
      patientMsg.ticketId = botMsg.ticketId = ticketId;
      await appendMessages(patientMsg, botMsg);
      const updated = await updateDoc(ticketId, (cur) => {
        if (botMsg.createdAt > cur.updatedAt) cur.updatedAt = botMsg.createdAt;
        cur.lastBotReply = result.reply;
        if (result.followUp === 'booking-update' || result.followUp === 'booking-start') {
          cur.type = 'booking';
          cur.category = 'booking';
          cur.booking = result.booking ? { ...result.booking } : { ...(cur.booking || {}), needsClarification: true };
          cur.requestedTime = requestedTimeOf(cur.booking);
          cur.status = cur.status === 'urgent' ? 'urgent' : 'needs human'; // back with staff until they decide
          if (!cur.intents.includes('booking')) cur.intents.push('booking');
        } else if (result.followUp !== 'smalltalk' && result.followUp !== 'contact') {
          cur.status = maxStatus(cur.status, result.status);
        }
        if (contact.name && !cur.patientName) cur.patientName = contact.name;
        if (contact.phone) cur.phone = contact.phone;
        if (cur.booking) {
          cur.booking.phone = cur.booking.phone || cur.phone; cur.booking.patientName = cur.booking.patientName || cur.patientName;
          if (!cur.patientName && cur.booking.patientName) cur.patientName = cur.booking.patientName;
          if (!cur.phone && cur.booking.phone) cur.phone = cur.booking.phone;
        }
        return cur;
      }, (d) => d.updatedAt >= botMsg.createdAt && (!contact.phone || d.phone === contact.phone) && (!result.booking || (d.type === 'booking'
        && (!result.booking.dateText || d.booking?.dateText === result.booking.dateText)
        && (!result.booking.timeText || d.booking?.timeText === result.booking.timeText)
        && d.booking?.state === result.booking.state)));
      status = updated.status;
    } else if (result.followUp === 'smalltalk') {
      // greeting / thanks with no open enquiry: keep it in the conversation only
    } else {
      // New enquiry → new ticket (every enquiry creates one, including answered ones).
      for (let attempt = 0; attempt < 5 && !ticketId; attempt++) {
        const id = newTicketId(t0);
        patientMsg.ticketId = botMsg.ticketId = id;
        const ticket: TicketDoc = {
          id, conversationId,
          patientName: contact.name || result.booking?.patientName || conv?.patientName,
          phone: contact.phone || result.booking?.phone || conv?.phone,
          question: text,
          category: categorize(result),
          type: result.ticketType,
          status: result.status,
          priority: result.priority,
          createdAt: patientMsg.createdAt,
          updatedAt: botMsg.createdAt,
          booking: result.booking,
          ...(result.ticketType === 'booking' ? { requestedTime: requestedTimeOf(result.booking) } : {}),
          intents: result.intents,
          unsupportedTopics: result.unsupportedTopics,
          lang: result.lang,
          knowledgeVersion: version,
          lastBotReply: result.reply,
          source: answerSource,
          ...(aiNote ? { aiNote } : {}),
        };
        if (await kv.get(tKey(id))) continue; // id collision (astronomically rare) → pick another
        await appendMessages(patientMsg, botMsg); // messages first, so a listed ticket always has its history
        if (await kv.create(tKey(id), ticket)) { ticketId = id; status = ticket.status; }
      }
      if (!ticketId) throw new Error('Could not allocate a ticket id');
    }

    await updateJSON<Conversation>(kv, cKey(conversationId), (cur) => {
      const c: Conversation = cur || { id: conversationId, createdAt: patientMsg.createdAt, updatedAt: patientMsg.createdAt, ticketIds: [], loose: [] };
      if (ticketId && !c.ticketIds.includes(ticketId)) c.ticketIds.push(ticketId);
      if (!ticketId) c.loose.push(patientMsg, botMsg);
      if (contact.name) c.patientName = contact.name;
      if (contact.phone) c.phone = contact.phone;
      c.lastOffer = result.offer;
      c.updatedAt = botMsg.createdAt;
      return c;
    }, (c) => (ticketId ? c.ticketIds.includes(ticketId) : c.loose.some((m) => m.id === patientMsg.id)));

    return { conversationId, ticketId, status, messages: [patientMsg, botMsg] };
  }

  async function getConversation(conversationId: unknown): Promise<{ conversationId: string; messages: ChatMessage[] }> {
    const id = checkId(conversationId, 'conversation id');
    const conv = (await kv.get<Conversation>(cKey(id)))?.value;
    if (!conv) return { conversationId: id, messages: [] };
    const tickets = (await Promise.all(conv.ticketIds.map(getTicket))).filter((t): t is Ticket => !!t && t.conversationId === id);
    const messages = [...conv.loose, ...tickets.flatMap((t) => t.messages)]
      .filter((m) => m.conversationId === id) // defence in depth: never leak another conversation's messages
      .sort((a, b) => a.createdAt.localeCompare(b.createdAt));
    return { conversationId: id, messages };
  }

  async function listTickets(sort: SortMode = 'priority'): Promise<Ticket[]> {
    const [docKeys, msgKeys] = await Promise.all([kv.list('ticket/'), kv.list('msg/')]);
    const docs: TicketDoc[] = [];
    for (let i = 0; i < docKeys.length; i += 25) {
      const chunk = await Promise.all(docKeys.slice(i, i + 25).map((k) => getDoc(k.slice('ticket/'.length))));
      for (const d of chunk) if (d) docs.push(d);
    }
    const byTicket = new Map<string, ChatMessage[]>();
    for (const m of await fetchMessages(msgKeys)) { if (!m.ticketId) continue; (byTicket.get(m.ticketId) || byTicket.set(m.ticketId, []).get(m.ticketId)!).push(m); }
    const cal = await calendar();
    const at = now();
    return sortQueue(docs.map((d) => enrich({ ...d, messages: byTicket.get(d.id) || [] }, cal, at)), sort);
  }

  async function staffReply(ticketId: unknown, input: { text: unknown; staffName?: unknown; saveFaq?: unknown }): Promise<Ticket & { savedFaqVersion?: number }> {
    const id = checkId(ticketId, 'ticket id');
    const text = cleanText(input.text, LIMITS.reply, 'Reply');
    const staffName = typeof input.staffName === 'string' && input.staffName.trim() ? input.staffName.trim().slice(0, LIMITS.staffName) : 'Clinic staff';
    const doc = await getDoc(id);
    if (!doc) throw new NotFoundError('Ticket not found.');
    const at = new Date(Math.max(now().getTime(), Date.parse(doc.updatedAt) + 1)).toISOString();
    const msg: ChatMessage = { id: newId(), conversationId: doc.conversationId, ticketId: id, sender: 'staff', staffName, text, createdAt: at, meta: { source: 'staff' } };
    await appendMessages(msg); // durable the moment this resolves, whatever happens below
    await updateDoc(id, (cur) => {
      if (at > cur.updatedAt) cur.updatedAt = at;
      cur.firstStaffReplyAt = cur.firstStaffReplyAt && cur.firstStaffReplyAt < at ? cur.firstStaffReplyAt : at;
      cur.assignedTo = cur.assignedTo || staffName;
      // a person has now answered it; urgent stays urgent and closed stays closed until staff change it.
      // A booking request stays "needs human" until staff confirm or reject it.
      const undecidedBooking = cur.type === 'booking' && cur.booking?.state !== 'confirmed' && cur.booking?.state !== 'rejected';
      if (cur.status === 'needs human' && !undecidedBooking) cur.status = 'answered';
      return cur;
    }, (d) => d.updatedAt >= at && !!d.firstStaffReplyAt);
    let savedFaqVersion: number | undefined;
    if (input.saveFaq === true) {
      if (!opts.addFaq) throw new ValidationError('Saving FAQs is not available here.');
      if (doc.type === 'emergency') throw new ValidationError('Emergency replies are never saved as FAQs.');
      // the patient's name/phone are removed before the question becomes a clinic FAQ
      savedFaqVersion = (await opts.addFaq({ q: stripContact(doc.question), a: text, from: id }, staffName)).version;
    }
    return { ...(await getTicket(id))!, ...(savedFaqVersion ? { savedFaqVersion } : {}) };
  }

  async function setStatus(ticketId: unknown, input: { status: unknown; staffName?: unknown }): Promise<Ticket> {
    const id = checkId(ticketId, 'ticket id');
    const want = input.status;
    if (want !== 'closed' && want !== 'open') throw new ValidationError('Status must be "closed" or "open".');
    const staffName = typeof input.staffName === 'string' && input.staffName.trim() ? input.staffName.trim().slice(0, LIMITS.staffName) : 'Clinic staff';
    if (!(await getDoc(id))) throw new NotFoundError('Ticket not found.');
    const at = now().toISOString();
    await updateDoc(id, (cur) => {
      if (want === 'closed' && cur.status !== 'closed') {
        cur.statusBeforeClose = cur.status;
        cur.status = 'closed';
        cur.closedAt = at;
        cur.closedBy = staffName;
      } else if (want === 'open' && cur.status === 'closed') {
        cur.status = cur.statusBeforeClose || 'needs human';
        cur.closedAt = undefined;
        cur.closedBy = undefined;
      }
      cur.updatedAt = at > cur.updatedAt ? at : cur.updatedAt;
      return cur;
    }, (d) => (want === 'closed' ? d.status === 'closed' : d.status !== 'closed'));
    return (await getTicket(id))!;
  }

  async function decideBooking(ticketId: unknown, input: { decision: unknown; date?: unknown; time?: unknown; note?: unknown; staffName?: unknown }): Promise<Ticket> {
    const id = checkId(ticketId, 'ticket id');
    const decision = input.decision;
    if (decision !== 'confirm' && decision !== 'reject') throw new ValidationError('Decision must be "confirm" or "reject".');
    const staffName = typeof input.staffName === 'string' && input.staffName.trim() ? input.staffName.trim().slice(0, LIMITS.staffName) : 'Clinic staff';
    const note = typeof input.note === 'string' && input.note.trim() ? input.note.trim().slice(0, LIMITS.reply) : undefined;
    const doc = await getDoc(id);
    if (!doc) throw new NotFoundError('Ticket not found.');
    if (doc.type !== 'booking' || !doc.booking) throw new ValidationError('This ticket is not an appointment request.');
    const b = doc.booking;
    let date: string | undefined, time: string | undefined;
    if (decision === 'confirm') {
      date = typeof input.date === 'string' && input.date ? input.date : b.requestedDate;
      time = typeof input.time === 'string' && input.time ? input.time : b.requestedTime;
      if (!date || !/^\d{4}-\d{2}-\d{2}$/.test(date) || Number.isNaN(Date.parse(`${date}T00:00:00Z`))) throw new ValidationError('Enter the confirmed date (YYYY-MM-DD).');
      if (!time || !/^([01]\d|2[0-3]):[0-5]\d$/.test(time)) throw new ValidationError('Enter the confirmed time (HH:MM).');
    }
    const { data, version } = await opts.getClinic();
    const policy = getIndex(data, version).policies.find((p) => /appoint/i.test(p.key))?.value;
    const requested = [b.dateText, b.timeText].filter(Boolean).join(' at ');
    const at = new Date(Math.max(now().getTime(), Date.parse(doc.updatedAt) + 1)).toISOString();
    const text = T(doc.lang).bookingDecision({ decision, date, time, doctor: b.doctor, service: b.service, note, policy, requested });
    const state = decision === 'confirm' ? 'confirmed' as const : 'rejected' as const;
    await appendMessages({ id: newId(), conversationId: doc.conversationId, ticketId: id, sender: 'staff', staffName, text, createdAt: at, meta: { source: 'staff', bookingDecision: state, bookingState: state } });
    await updateDoc(id, (cur) => {
      cur.booking = { ...(cur.booking || { needsClarification: false }), state, decidedBy: staffName, decidedAt: at, decisionNote: note, confirmedDate: date, confirmedTime: time };
      if (cur.status === 'needs human') cur.status = 'answered'; // staff have reviewed it
      if (at > cur.updatedAt) cur.updatedAt = at;
      cur.firstStaffReplyAt = cur.firstStaffReplyAt && cur.firstStaffReplyAt < at ? cur.firstStaffReplyAt : at;
      cur.assignedTo = cur.assignedTo || staffName;
      return cur;
    }, (d) => d.booking?.state === state && d.booking.decidedAt === at);
    return (await getTicket(id))!;
  }

  async function assign(ticketId: unknown, input: { staffName: unknown }): Promise<Ticket> {
    const id = checkId(ticketId, 'ticket id');
    const name = cleanText(input.staffName, LIMITS.staffName, 'Staff name');
    if (!(await getDoc(id))) throw new NotFoundError('Ticket not found.');
    await updateDoc(id, (cur) => { cur.assignedTo = name; return cur; }, (d) => d.assignedTo === name);
    return (await getTicket(id))!;
  }

  return { handleChat, getConversation, listTickets, getTicket, staffReply, setStatus, assign, decideBooking };
}

export type TicketService = ReturnType<typeof createTicketService>;

/** Staff queue order (kept for existing callers). */
export function sortTickets(ts: Ticket[], mode: SortMode = 'priority'): Ticket[] { return sortQueue(ts, mode); }
