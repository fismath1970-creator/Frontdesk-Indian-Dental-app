import { useEffect, useState } from 'react';
import { PatientChat } from './components/PatientChat.tsx';
import { StaffDashboard } from './components/StaffDashboard.tsx';

const isStaffRoute = () => (window.location.pathname.replace(/\/+$/, '') || '/') === '/staff' || window.location.hash.startsWith('#/staff');

export function App() {
  const [staff, setStaff] = useState(isStaffRoute);
  useEffect(() => {
    const on = () => setStaff(isStaffRoute());
    window.addEventListener('popstate', on);
    window.addEventListener('hashchange', on);
    return () => { window.removeEventListener('popstate', on); window.removeEventListener('hashchange', on); };
  }, []);
  return staff ? <StaffDashboard /> : <PatientChat />;
}
