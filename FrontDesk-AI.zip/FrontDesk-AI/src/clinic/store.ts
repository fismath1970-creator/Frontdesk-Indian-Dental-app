// The ONE current clinic file, stored server-side (Netlify Blobs) or in the local demo store.
// Every read goes to the store — nothing is cached in memory.
import { validateClinicData } from '../engine/knowledge.ts';
import type { ClinicData, FaqEntry } from '../engine/types.ts';
import { ValidationError, VersionConflictError } from '../tickets/errors.ts';
import { updateJSON, type KV } from '../tickets/kv.ts';

export interface ClinicRecord {
  data: ClinicData;
  version: number;
  updatedAt?: string;
  updatedBy?: string;
  change?: string; // short description of the last change
}

const KEY = 'clinic/current';

export function createClinicStore(kv: KV, original: ClinicData, now: () => Date = () => new Date()) {
  const initial = (): ClinicRecord => ({ data: structuredClone(original), version: 1 });

  async function get(): Promise<ClinicRecord> {
    const r = await kv.get<ClinicRecord>(KEY);
    return r ? r.value : initial();
  }

  async function write(change: string, by: string, fn: (cur: ClinicRecord) => ClinicData, baseVersion?: number): Promise<ClinicRecord> {
    const at = now().toISOString();
    const stamp = `${at}#${Math.random().toString(36).slice(2, 10)}`;
    return updateJSON<ClinicRecord & { stamp?: string }>(kv, KEY, (cur) => {
      const c = cur || initial();
      if (baseVersion !== undefined && baseVersion !== c.version) throw new VersionConflictError(c.version);
      const data = fn(c);
      const v = validateClinicData(data);
      if (!v.ok) throw new ValidationError('The clinic file has errors and was not saved.', v.errors);
      return { data, version: c.version + 1, updatedAt: at, updatedBy: by, change, stamp };
    }, (stored) => stored.stamp === stamp);
  }

  return {
    get,
    save: async (data: unknown, baseVersion: number | undefined, by = 'Clinic staff') => {
      if (!data || typeof data !== 'object') throw new ValidationError('The clinic file has errors and was not saved.', ['The clinic file must be a JSON object.']);
      return write('Edited in the clinic editor', by, () => structuredClone(data as ClinicData), baseVersion);
    },
    reset: (by = 'Clinic staff') => write('Reset to the original sample file', by, () => structuredClone(original)),
    /** append (or update, for the same ticket) a staff-approved FAQ */
    addFaq: (entry: FaqEntry, by = 'Clinic staff') => write(`FAQ added from ticket ${entry.from || ''}`.trim(), by, (cur) => {
      const data = structuredClone(cur.data);
      const list = Array.isArray(data.faq) ? data.faq.filter((f) => !entry.from || f.from !== entry.from) : [];
      data.faq = [...list, { q: entry.q, a: entry.a, from: entry.from, addedAt: now().toISOString(), addedBy: by }];
      return data;
    }),
  };
}
export type ClinicStore = ReturnType<typeof createClinicStore>;
