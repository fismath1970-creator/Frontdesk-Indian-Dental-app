// FrontDesk AI — language resources. These hold vocabulary only, never clinic
// facts: every fact in a reply comes from the clinic data at answer time.

/** Map words to one canonical form (applied after light stemming). */
export const CANONICAL: Record<string, string> = {
  // children
  child: 'child', children: 'child', childrens: 'child', kid: 'child', kids: 'child', kiddo: 'child',
  baby: 'child', babies: 'child', toddler: 'child', son: 'child', daughter: 'child', infant: 'child',
  paediatric: 'child', pediatric: 'child', paediatrics: 'child', pediatrics: 'child',
  pedodontist: 'child', paedodontist: 'child', paediatrician: 'child', pediatrician: 'child',
  // cleaning
  cleaning: 'clean', clean: 'clean', scaling: 'clean', scale: 'clean', polishing: 'clean', polish: 'clean',
  // whitening
  whitening: 'whiten', whiten: 'whiten', whitener: 'whiten', bleach: 'whiten', bleaching: 'whiten', white: 'whiten',
  // x-ray
  xray: 'xray', xrays: 'xray', radiograph: 'xray', radiographs: 'xray',
  // filling
  filling: 'fill', fillings: 'fill', fill: 'fill', cavity: 'fill', cavities: 'fill',
  // consultation
  consultation: 'consult', consultations: 'consult', consult: 'consult', consulting: 'consult',
  checkup: 'consult', checkups: 'consult', examination: 'consult',
  // orthodontics
  orthodontist: 'ortho', orthodontists: 'ortho', orthodontic: 'ortho', orthodontics: 'ortho', ortho: 'ortho',
  brace: 'brace', braces: 'brace',
  aligner: 'aligner', aligners: 'aligner',
  canal: 'canal', canals: 'canal',
  implant: 'implant', implants: 'implant',
  // generic dental words
  tooth: 'tooth', teeth: 'tooth', dental: 'dental',
  doctor: 'doctor', doctors: 'doctor', dr: 'doctor', dentist: 'doctor', dentists: 'doctor', doc: 'doctor',
  physician: 'doctor', specialist: 'doctor', specialists: 'doctor', surgeon: 'doctor',
};

/** Words that never identify a specific service or doctor on their own. */
export const GENERIC = new Set([
  'tooth', 'dental', 'treatment', 'treatments', 'single', 'per', 'doctor', 'lead', 'senior', 'consultant',
  'under', 'and', 'or', 'the', 'a', 'an', 'of', 'for', 'with', 'only', 'care', 'service', 'services',
  'procedure', 'oral', 'general', 'clinic', 'session', 'visit', 'basic',
]);

export const STOPWORDS = new Set([
  'a', 'an', 'the', 'is', 'are', 'am', 'was', 'were', 'be', 'do', 'does', 'did', 'you', 'your', 'yours', 'we',
  'our', 'i', 'me', 'my', 'it', 'its', 'to', 'of', 'in', 'on', 'at', 'for', 'and', 'or', 'can', 'could',
  'would', 'should', 'will', 'please', 'tell', 'about', 'what', 'which', 'who', 'how', 'much', 'many', 'any',
  'there', 'this', 'that', 'have', 'has', 'with', 'get', 'know', 'want', 'need', 'like', 'hi', 'hello',
  'hey', 'ok', 'okay', 'thanks', 'thank', 'also', 'just', 'some', 'if', 'so', 'than', 'then', 'from', 'by',
  'us', 'they', 'them', 'he', 'she', 'his', 'her', 'when', 'where', 'why', 'not', 'no', 'yes', 'offer',
  'provide', 'available', 'there', 'see', 'sees', 'seen', 'treat', 'treats', 'take', 'takes', 'accept',
  'accepts', 'let', 'give', 'kindly', 'sir', 'madam', 'maam', 'dear', 'is', 'be', 'cost', 'price', 'fee',
  'fees', 'charge', 'charges', 'rate', 'rates', 'rs', 'rupees', 'inr', 'mean',
]);

export const DAY_ALIASES: Record<string, number> = {
  sun: 0, sunday: 0, sundays: 0,
  mon: 1, monday: 1, mondays: 1,
  tue: 2, tues: 2, tuesday: 2, tuesdays: 2,
  wed: 3, wednesday: 3, wednesdays: 3,
  thu: 4, thur: 4, thurs: 4, thursday: 4, thursdays: 4,
  fri: 5, friday: 5, fridays: 5,
  sat: 6, saturday: 6, saturdays: 6,
};
export const DAY_NAMES = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

export const HOLIDAY_WORDS = [
  'holiday', 'holidays', 'public holiday', 'bank holiday', 'festival', 'diwali', 'deepavali', 'holi', 'eid',
  'christmas', 'pongal', 'sankranti', 'sankranthi', 'ugadi', 'dussehra', 'dasara', 'navratri', 'ganesh chaturthi',
  'independence day', 'republic day', 'gandhi jayanti', 'new year', 'bakrid', 'ramzan', 'good friday', 'bonalu',
  'bathukamma', 'telangana formation day',
];

/**
 * Dental services/brands that a patient may ask about. If one is mentioned and
 * the clinic data does not list it as a service (or a doctor's stated work),
 * the engine must NOT infer it — it escalates to a human.
 * `related` words let the reply honestly point at what the file DOES say.
 */
export const DENTAL_TERMS: Array<{ label: string; phrases: string[]; related?: string[] }> = [
  { label: 'Invisalign', phrases: ['invisalign', 'invisaline', 'invisalin'], related: ['aligner'] },
  { label: 'ceramic braces', phrases: ['ceramic braces', 'ceramic brace', 'ceramic'], related: ['brace'] },
  { label: 'clear braces', phrases: ['clear braces', 'clear brace', 'transparent braces'], related: ['brace', 'aligner'] },
  { label: 'lingual braces', phrases: ['lingual braces', 'lingual', 'self ligating', 'damon braces'], related: ['brace'] },
  { label: 'veneers', phrases: ['veneer', 'veneers', 'laminate', 'laminates'] },
  { label: 'crowns', phrases: ['crown', 'crowns', 'cap for tooth', 'tooth cap', 'dental cap', 'zirconia', 'emax', 'e max', 'pfm'], related: ['crown'] },
  { label: 'dental bridges', phrases: ['bridge', 'bridges', 'dental bridge'] },
  { label: 'dentures', phrases: ['denture', 'dentures', 'false teeth', 'false tooth', 'partial denture'] },
  { label: 'tooth extraction', phrases: ['extraction', 'extractions', 'extract', 'pull out', 'pulled out', 'remove my tooth', 'remove a tooth', 'tooth removal', 'removal of tooth'] },
  { label: 'wisdom tooth removal', phrases: ['wisdom tooth', 'wisdom teeth', 'impacted tooth'] },
  { label: 'gum treatment', phrases: ['gum surgery', 'gum treatment', 'periodontal', 'periodontist', 'flap surgery', 'gum disease treatment', 'gum graft', 'gum contouring'] },
  { label: 'deep cleaning', phrases: ['deep cleaning', 'deep clean', 'root planing', 'curettage'] },
  { label: 'laser treatment', phrases: ['laser', 'lasers'] },
  { label: 'Botox or fillers', phrases: ['botox', 'dermal filler', 'lip filler', 'fillers'] },
  { label: 'smile makeover', phrases: ['smile design', 'smile makeover', 'smile correction', 'cosmetic dentistry', 'hollywood smile'] },
  { label: 'retainers', phrases: ['retainer', 'retainers'] },
  { label: 'night guards', phrases: ['night guard', 'mouth guard', 'mouthguard', 'sports guard', 'bite guard', 'grinding guard'] },
  { label: 'dental bonding', phrases: ['bonding', 'composite bonding'] },
  { label: 'sealants or fluoride', phrases: ['sealant', 'sealants', 'fluoride', 'varnish'] },
  { label: 'tooth jewellery', phrases: ['tooth jewel', 'tooth jewellery', 'tooth jewelry', 'tooth gem', 'grillz'] },
  { label: 'pulp treatment for children', phrases: ['pulpectomy', 'pulpotomy'] },
  { label: 'inlays or onlays', phrases: ['inlay', 'onlay', 'inlays', 'onlays'] },
  { label: 'full mouth rehabilitation', phrases: ['full mouth', 'rehabilitation', 'all on 4', 'all on four'] },
  { label: 'jaw joint (TMJ) treatment', phrases: ['tmj', 'jaw joint'] },
  { label: 'sleep apnoea / snoring appliances', phrases: ['sleep apnea', 'sleep apnoea', 'snoring'] },
  { label: 'oral cancer screening', phrases: ['oral cancer', 'cancer screening', 'biopsy'] },
  { label: '3D scans (CBCT/OPG)', phrases: ['cbct', 'opg', '3d scan', 'panoramic', 'full mouth xray'] },
  { label: 'sedation', phrases: ['sedation', 'general anaesthesia', 'general anesthesia', 'laughing gas', 'nitrous'] },
  { label: 'home visits', phrases: ['home visit', 'house call', 'come to my home', 'come home'] },
  { label: 'online consultations', phrases: ['online consult', 'online consultation', 'video consult', 'video call', 'teleconsult', 'telemedicine'] },
  { label: 'tongue-tie treatment', phrases: ['tongue tie', 'frenectomy'] },
  { label: 'teeth whitening kits', phrases: ['whitening kit', 'home whitening', 'whitening strips'] },
];

/** Indian health insurers — so a named insurer can be recognised even if not on the clinic's list. */
export const INSURERS = [
  'star health', 'niva bupa', 'max bupa', 'hdfc ergo', 'icici lombard', 'bajaj allianz', 'care health', 'religare',
  'tata aig', 'aditya birla', 'aditya birla health', 'new india assurance', 'new india', 'united india',
  'oriental insurance', 'national insurance', 'sbi general', 'manipal cigna', 'manipalcigna', 'cigna',
  'reliance general', 'iffco tokio', 'cholamandalam', 'future generali', 'kotak', 'digit', 'go digit', 'acko',
  'universal sompo', 'liberty', 'magma', 'raheja qbe', 'navi', 'cghs', 'esi', 'esic', 'echs', 'galaxy health',
  'narayana health', 'medi assist', 'paramount', 'vidal', 'aarogyasri', 'ayushman bharat', 'pmjay',
];

/**
 * Hindi / Telugu (native script and common transliterations) → English intent words.
 * The engine appends these English hints to the normalised text so the same
 * matcher works for all three languages. Replies stay grounded in clinic data.
 */
export const INDIC_HINTS: Array<[string, string]> = [
  // Hindi – Devanagari
  ['कितना', 'how much'], ['कितने', 'how much'], ['कितनी', 'how much'], ['दाम', 'price'], ['कीमत', 'price'],
  ['फीस', 'price'], ['शुल्क', 'price'], ['खर्च', 'price'], ['समय', 'timing'], ['टाइम', 'timing'], ['खुल', 'open'],
  ['बंद', 'closed'], ['कब', 'when'], ['डॉक्टर', 'doctor'], ['डाक्टर', 'doctor'], ['दंत चिकित्सक', 'dentist'],
  ['बच्च', 'children'], ['बीमा', 'insurance'], ['इंश्योरेंस', 'insurance'], ['पता', 'address'], ['कहाँ', 'where'],
  ['कहां', 'where'], ['पार्किंग', 'parking'], ['अपॉइंटमेंट', 'appointment'], ['बुक', 'book'], ['दर्द', 'pain'],
  ['दवा', 'medicine'], ['दवाई', 'medicine'], ['गोली', 'tablet'], ['रूट कैनाल', 'root canal'], ['सफाई', 'cleaning'],
  ['फिलिंग', 'filling'], ['ब्रेसेस', 'braces'], ['इम्प्लांट', 'implant'], ['इंप्लांट', 'implant'], ['एक्स-रे', 'xray'],
  ['एक्सरे', 'xray'], ['व्हाइटनिंग', 'whitening'], ['भुगतान', 'payment'], ['फोन', 'phone'], ['नंबर', 'number'],
  ['भाषा', 'language'], ['छूट', 'discount'], ['डिस्काउंट', 'discount'], ['सोमवार', 'monday'], ['मंगलवार', 'tuesday'],
  ['बुधवार', 'wednesday'], ['गुरुवार', 'thursday'], ['शुक्रवार', 'friday'], ['शनिवार', 'saturday'], ['रविवार', 'sunday'],
  ['आज', 'today'], ['कल', 'tomorrow'], ['परसों', 'day after tomorrow'], ['छुट्टी', 'holiday'],
  ['सुबह', 'morning'], ['दोपहर', 'afternoon'], ['शाम', 'evening'], ['अगले', 'next'],
  ['मुफ्त', 'for free'], ['मुफ़्त', 'for free'], ['फ्री', 'for free'], ['पेनकिलर', 'painkiller'], ['दर्द निवारक', 'painkiller'],
  ['सूजन', 'swelling'], ['खून', 'bleeding'], ['सांस', 'breathing'], ['आपातकाल', 'emergency'], ['इमरजेंसी', 'emergency'],
  ['दांत', 'tooth'], ['दाँत', 'tooth'], ['समय सारणी', 'timings'], ['खुलता', 'open'], ['खुलते', 'open'], ['क्लिनिक', 'clinic'],
  // Hindi – transliterated (whole words only)
  ['kitna', 'how much'], ['kitne', 'how much'], ['kitni', 'how much'], ['daam', 'price'], ['keemat', 'price'],
  ['kimat', 'price'], ['kharcha', 'price'], ['samay', 'timing'], ['khulta', 'open'], ['khulte', 'open'],
  ['khula', 'open'], ['kab', 'when'], ['kahan', 'where'], ['kaha', 'where'], ['bachche', 'children'],
  ['bacche', 'children'], ['bachon', 'children'], ['bacchon', 'children'], ['beema', 'insurance'], ['bima', 'insurance'],
  ['dard', 'pain'], ['dawai', 'medicine'], ['dawa', 'medicine'], ['dava', 'medicine'], ['shanivar', 'saturday'],
  ['ravivar', 'sunday'], ['somvar', 'monday'], ['mangalvar', 'tuesday'], ['budhvar', 'wednesday'],
  ['guruvar', 'thursday'], ['shukravar', 'friday'], ['aaj', 'today'], ['chhoot', 'discount'], ['chhut', 'discount'],
  ['kal', 'tomorrow'], ['parso', 'day after tomorrow'], ['parson', 'day after tomorrow'], ['subah', 'morning'], ['dopahar', 'afternoon'],
  ['shaam', 'evening'], ['sham', 'evening'], ['goli', 'tablet'], ['muft', 'for free'], ['daant', 'tooth'], ['dant', 'tooth'],
  // Telugu – script
  ['ఎంత', 'how much'], ['ధర', 'price'], ['ఫీజు', 'price'], ['ఖర్చు', 'price'], ['సమయం', 'timing'], ['సమయాలు', 'timing'],
  ['టైమింగ్', 'timing'], ['తెరిచి', 'open'], ['తెరుస్తారు', 'open'], ['మూసి', 'closed'], ['ఎప్పుడు', 'when'],
  ['డాక్టర్', 'doctor'], ['వైద్యుడు', 'doctor'], ['పిల్ల', 'children'], ['ఇన్సూరెన్స్', 'insurance'], ['బీమా', 'insurance'],
  ['చిరునామా', 'address'], ['అడ్రస్', 'address'], ['ఎక్కడ', 'where'], ['పార్కింగ్', 'parking'],
  ['అపాయింట్‌మెంట్', 'appointment'], ['అపాయింట్మెంట్', 'appointment'], ['బుక్', 'book'], ['నొప్పి', 'pain'],
  ['మందు', 'medicine'], ['మాత్ర', 'tablet'], ['రూట్ కెనాల్', 'root canal'], ['క్లీనింగ్', 'cleaning'],
  ['ఫిల్లింగ్', 'filling'], ['బ్రేసెస్', 'braces'], ['ఇంప్లాంట్', 'implant'], ['ఎక్స్-రే', 'xray'], ['ఎక్స్‌రే', 'xray'],
  ['చెల్లింపు', 'payment'], ['ఫోన్', 'phone'], ['నంబర్', 'number'], ['భాష', 'language'], ['తగ్గింపు', 'discount'],
  ['డిస్కౌంట్', 'discount'], ['సోమవారం', 'monday'], ['మంగళవారం', 'tuesday'], ['బుధవారం', 'wednesday'],
  ['గురువారం', 'thursday'], ['శుక్రవారం', 'friday'], ['శనివారం', 'saturday'], ['ఆదివారం', 'sunday'],
  ['ఈరోజు', 'today'], ['రేపు', 'tomorrow'], ['ఎల్లుండి', 'day after tomorrow'], ['సెలవు', 'holiday'],
  ['ఉదయం', 'morning'], ['మధ్యాహ్నం', 'afternoon'], ['సాయంత్రం', 'evening'], ['వచ్చే', 'next'],
  ['ఉచితం', 'for free'], ['ఉచితంగా', 'for free'], ['ఫ్రీ', 'for free'], ['పెయిన్ కిల్లర్', 'painkiller'],
  ['వాపు', 'swelling'], ['రక్తం', 'bleeding'], ['పన్ను', 'tooth'], ['పంటి', 'tooth'], ['పళ్ళు', 'tooth'], ['పళ్లు', 'tooth'],
  ['అత్యవసర', 'emergency'], ['ఎమర్జెన్సీ', 'emergency'], ['క్లినిక్', 'clinic'],
  // Telugu – transliterated
  ['entha', 'how much'], ['enta', 'how much'], ['dhara', 'price'], ['ekkada', 'where'], ['eppudu', 'when'],
  ['pillalu', 'children'], ['pillala', 'children'], ['noppi', 'pain'], ['mandu', 'medicine'], ['mandulu', 'medicine'],
  ['shanivaram', 'saturday'], ['sanivaram', 'saturday'], ['aadivaram', 'sunday'], ['adivaram', 'sunday'],
  ['somavaram', 'monday'], ['mangalavaram', 'tuesday'], ['budhavaram', 'wednesday'], ['guruvaram', 'thursday'],
  ['shukravaram', 'friday'], ['sukravaram', 'friday'], ['eroju', 'today'], ['repu', 'tomorrow'],
  ['ellundi', 'day after tomorrow'], ['udayam', 'morning'], ['sayantram', 'evening'], ['madhyahnam', 'afternoon'],
  ['dhara', 'price'], ['ela', 'how'], ['pannu', 'tooth'],
];

/** Transliterated words that strongly indicate Hindi or Telugu (for language detection only). */
export const HINDI_TRANSLIT = new Set([
  'kya', 'hai', 'hain', 'kitna', 'kitne', 'kitni', 'kab', 'kahan', 'kaha', 'mujhe', 'mera', 'meri', 'aap', 'aapka',
  'aapke', 'nahi', 'nahin', 'ho', 'raha', 'rahi', 'dard', 'dawai', 'karna', 'chahiye', 'chahta', 'chahti', 'khulta',
  'khulte', 'bachche', 'bachon', 'kaun', 'kaise', 'kyun', 'hoga', 'milega', 'batao', 'bataiye', 'daant', 'dant',
  'kal', 'baje', 'shaam', 'subah', 'dopahar', 'parso', 'karna', 'karwana', 'karwani', 'dijiye', 'kijiye', 'dawai', 'goli', 'khoon', 'sujan',
]);
export const TELUGU_TRANSLIT = new Set([
  'enti', 'entha', 'enta', 'ekkada', 'eppudu', 'unnara', 'unnaya', 'undi', 'ledu', 'naaku', 'naku', 'meeru',
  'mee', 'cheyandi', 'cheppandi', 'kavali', 'noppi', 'pillalu', 'pillala', 'emiti', 'ela', 'vastara', 'chestara',
  'pannu', 'pallu', 'doctorgaru', 'garu', 'avunu', 'kadu', 'repu', 'ellundi', 'sayantram', 'udayam', 'dhara', 'gantalaku',
  'cheyandi', 'cheyali', 'mandu', 'noppi',
]);
