// Kept for older imports — all reply templates now live in i18n.ts (en / hi / te).
export { T, type Templates } from './i18n.ts';
