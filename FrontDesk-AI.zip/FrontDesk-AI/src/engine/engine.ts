// FrontDesk AI — deterministic receptionist pipeline.
// Order of checks (safety first): emergency → prompt-injection/discount →
// medical-safety → booking → clinic facts → unsupported (needs human).
import { DAY_ALIASES, DAY_NAMES, DENTAL_TERMS, HOLIDAY_WORDS, STOPWORDS } from './lexicon.ts';
import { addIndicHints, anyPhrase, detectLang, hasPhrase, normalize, stem, tokens } from './normalize.ts';
import { asText, buildIndex, faqTokens, type DoctorEntry, type KnowledgeIndex, type ServiceEntry } from './knowledge.ts';
import type { AnswerPart, BookingDetails, ClinicData, ContactDetails, EngineContext, EngineResult, FollowUp, Priority } from './types.ts';
import { QUICK_LABELS, T, type Templates } from './i18n.ts';
import { istDate, istMinutes, resolveDate, resolveTime } from './datetime.ts';
import { buildCalendar, openStatus, OUTSIDE_CODES, slotIssues } from './schedule.ts';

// ---------------------------------------------------------------- index
// Built fresh from the CURRENT clinic file on every call — no cache, no module-level copy,
// so a staff edit is reflected in the very next answer. (Building it takes well under 1 ms.)
export function getIndex(data: ClinicData, _version?: number): KnowledgeIndex {
  return buildIndex(data);
}
/** kept for older tests; there is nothing to clear any more */
export function clearEngineCache() {}

// ---------------------------------------------------------------- staff FAQ
export const FAQ_THRESHOLD = 0.6;
/** Best FAQ entry by normalised token overlap |A∩B| / max(|A|,|B|) ≥ 0.6. */
export function matchFaq(idx: KnowledgeIndex, text: string): { q: string; a: string; from?: string; score: number } | null {
  const qt = faqTokens(text);
  if (!qt.length) return null;
  let best: { q: string; a: string; from?: string; score: number } | null = null;
  for (const f of idx.faq) {
    if (!f.toks.length) continue;
    const inter = f.toks.filter((x) => qt.includes(x)).length;
    const score = inter / Math.max(f.toks.length, qt.length);
    if (score >= FAQ_THRESHOLD && (!best || score > best.score)) best = { q: f.q, a: f.a, from: f.from, score };
  }
  return best;
}

/** Remove a patient's name/phone sentences from a question (used before saving it as an FAQ). */
export function stripContact(text: string): string {
  const pieces = text.split(/(?<=[.!?;,])\s+/);
  const kept = pieces.filter((p) => !isContactOnly(p, extractContact(p)));
  let out = (kept.length ? kept.join(' ') : text).replace(PHONE_RE, '').replace(/\s{2,}/g, ' ').replace(/[\s,;]+$/, '').trim();
  if (!out) out = text.trim();
  return out;
}

// ---------------------------------------------------------------- specialists
const SPECIALTIES: Array<{ label: string; re: RegExp; roles: string[] }> = [
  { label: 'an orthodontist', re: /\borthodont\w*/, roles: ['ortho', 'brace', 'aligner'] },
  { label: 'an endodontist (root canal specialist)', re: /\bendodont\w*|\broot canal (specialist|doctor|dentist)/, roles: ['canal'] },
  { label: "a children's dentist", re: /\b(paediatric|pediatric|pedodont\w*|paedodont\w*)\b|\b(child|children|childrens|kids?) ?'?s? (dentist|doctor|specialist)\b/, roles: ['child'] },
  { label: 'a gum specialist (periodontist)', re: /\bperiodont\w*|\bgum (specialist|doctor)/, roles: ['gum', 'periodontist', 'periodontal'] },
  { label: 'a prosthodontist', re: /\bprosthodont\w*/, roles: ['denture', 'crown', 'bridge', 'prosthodontist'] },
  { label: 'an oral surgeon', re: /\b(oral|maxillofacial|dental) surgeon\b|\bmaxillofacial\b/, roles: ['extraction', 'wisdom', 'surgery'] },
  { label: 'an implant specialist', re: /\bimplantolog\w*|\bimplant (specialist|doctor|dentist)/, roles: ['implant'] },
];
const ROLE_TOPIC = new Set(SPECIALTIES.flatMap((s) => s.roles));

// ---------------------------------------------------------------- emergency
const EN_EMERGENCY: RegExp[] = [
  // breathing
  /\b(cannot|can not|not able to|unable to|could not|hard to|difficult to|difficulty|trouble|struggling to|struggle to|problem|problems)\b(\s+\w+){0,3}\s+(breath|breathe|breathing)\b/,
  /\b(short of breath|shortness of breath|breathless|breathlessness|gasping|choking|suffocating|suffocation|stopped breathing|not breathing)\b/,
  /\bbreathing\s+(problem|difficulty|trouble|issue|is hard|is difficult)/,
  // heavy bleeding that does not stop
  /\bbleed\w*\b(\s+\w+){0,6}\s+(not stop|will not stop|wont stop|does not stop|doesnt stop|not stopping|non stop|nonstop|for hours|continuously|heavily|a lot|too much|profusely|keeps)\b/,
  /\b(heavy|heavily|severe|profuse|uncontrolled|nonstop|non stop|continuous|lot of)\s+(\w+\s+){0,2}(bleeding|blood)\b/,
  /\b(blood|bleeding)\b(\s+\w+){0,4}\s+(everywhere|will not stop|wont stop|not stopping|does not stop|is not stopping|keeps coming|pouring)\b/,
  /\b(cannot|can not|unable to|could not)\s+(stop|control)\s+(the\s+)?(bleeding|blood)\b/,
  // swelling of face or neck
  /\b(face|facial|neck|throat|cheek|cheeks|jaw|eye|eyes|lip|lips|tongue)\b(\s+\w+){0,4}\s+(swell\w*|swollen|puff\w*|ballooning)\b/,
  /\b(swell\w*|swollen|puff\w*)\b(\s+\w+){0,4}\s+(face|facial|neck|throat|cheek|cheeks|jaw|eye|eyes|tongue)\b/,
  // other clearly urgent presentations
  /\b(unconscious|fainted|fainting|passed out|collapsed|seizure|fits|convulsion\w*|anaphyla\w*|allergic reaction|chest pain)\b/,
  /\b(cannot|can not|unable to)\s+(swallow|open my mouth|open mouth)\b/,
  /\b(accident|fell|fall|hit in the face|got hit|knocked out|knocked)\b(\s+\w+){0,6}\s+(tooth|teeth|jaw|face|mouth|bleed\w*)\b/,
  /\b(broken|fractured|fracture)\s+(jaw|face)\b/,
  /\b(this is|it is|its|having|have|we have|i have|there is)\s+(an?\s+)?(medical\s+|dental\s+)?emergency\b/,
  /^(emergency|urgent|help)\b(?!\s+(number|phone|line|contact|hours|timing))/,
  /\b(high fever)\b(\s+\w+){0,6}\s+(swell\w*|swollen)\b|\b(swell\w*|swollen)\b(\s+\w+){0,6}\s+(high fever)\b/,
];

const INDIC_EMERGENCY: Array<{ any: string[]; with?: string[] }> = [
  // Hindi breath + negation/difficulty
  { any: ['सांस', 'साँस', 'श्वास'], with: ['नहीं', 'नही', 'तकलीफ', 'दिक्कत', 'मुश्किल', 'रुक', 'फूल'] },
  { any: ['saans', 'sans', 'saas'], with: ['nahi', 'nahin', 'taklif', 'takleef', 'dikkat', 'mushkil', 'ruk', 'phool'] },
  // Hindi face/neck swelling
  { any: ['सूजन', 'सूज', 'फूल गया', 'फूल गई'], with: ['चेहर', 'गर्दन', 'गला', 'गले', 'मुंह', 'मुँह', 'गाल', 'जबड़'] },
  { any: ['sujan', 'soojan', 'sooj', 'suj gaya', 'sooja'], with: ['chehra', 'chehre', 'gardan', 'gala', 'gale', 'gaal', 'muh', 'munh'] },
  // Hindi bleeding not stopping
  { any: ['खून', 'रक्त'], with: ['रुक नहीं', 'रुक नही', 'बंद नहीं', 'बंद नही', 'बहुत', 'लगातार', 'रुकना'] },
  { any: ['khoon', 'khun'], with: ['ruk nahi', 'band nahi', 'bahut', 'lagatar', 'ruk nahin'] },
  // Telugu breath
  { any: ['ఊపిరి', 'శ్వాస'], with: ['లేదు', 'ఆడటం', 'ఆడట్లేదు', 'కష్టం', 'ఇబ్బంది', 'రావట్లేదు'] },
  { any: ['oopiri', 'upiri', 'swasa'], with: ['ledu', 'aadatledu', 'adatledu', 'kashtam', 'ibbandi'] },
  // Telugu swelling of face/neck
  { any: ['వాపు', 'ఉబ్బ', 'వాచి', 'వాచింది', 'వాస్తోంది'], with: ['ముఖం', 'ముఖ', 'మెడ', 'గొంతు', 'దవడ', 'బుగ్గ'] },
  { any: ['बेहोश', 'స్పృహ తప్ప', 'behosh'] },
  { any: ['खून', 'रक्त'], with: ['नहीं रुक', 'नही रुक', 'रुकता नहीं', 'रुक ही नहीं'] },
  { any: ['vaapu', 'vapu', 'ubbi'], with: ['mukham', 'muham', 'meda', 'gontu', 'davada', 'bugga'] },
  // Telugu bleeding
  { any: ['రక్తం', 'రక్త'], with: ['ఆగడం లేదు', 'ఆగట్లేదు', 'ఆగడంలేదు', 'చాలా', 'ఆగదు'] },
  { any: ['raktham', 'raktam'], with: ['aagatledu', 'agatledu', 'aagadam ledu', 'chala'] },
  // explicit words
  { any: ['आपातकाल', 'इमरजेंसी', 'అత్యవసర', 'ఎమర్జెన్సీ'], with: ['है', 'हूँ', 'मदद', 'సహాయం', 'ఉంది', 'help', '!'] },
];

export function isEmergency(raw: string): boolean {
  const n = normalize(raw);
  if (EN_EMERGENCY.some((r) => r.test(n))) return true;
  for (const rule of INDIC_EMERGENCY) {
    const hit = rule.any.some((w) => (/^[a-z ]+$/.test(w) ? hasPhrase(n, w) || n.includes(w) : n.includes(w) || raw.includes(w)));
    if (!hit) continue;
    if (!rule.with) return true;
    if (rule.with.some((w) => n.includes(w) || raw.includes(w))) return true;
  }
  return false;
}

// ---------------------------------------------------------------- injection / discount
const INJECTION: RegExp[] = [
  /\b(ignore|disregard|forget|override|bypass|skip|break|drop|delete|remove)\b(\s+\w+){0,4}\s+(rules?|instructions?|prompts?|guidelines?|polic(y|ies)|restrictions?|programming|system|guardrails?)\b/,
  /\b(you are now|from now on you|pretend (to be|you)|act as|roleplay as|developer mode|dan mode|jailbreak|system prompt|new rules?|reveal your|show me your (prompt|instructions|rules))\b/,
  /\b(change|update|edit|modify|set|lower|reduce|cut|drop)\b(\s+\w+){0,3}\s+(the\s+|your\s+)?(price|prices|fee|fees|cost|costs|charges?|rules?|rate|rates|data|records?|hours|timings?)\b/,
  /\b(admin|administrator|staff|owner|manager|doctor) (mode|override|access|command)\b/,
];
const DISCOUNT: RegExp[] = [
  /\bdiscount\w*\b/, /\d+\s*%/, /\b(percent|percentage)\s+off\b/, /\boff (the|your|my) (price|bill|fee|cost)\b/,
  /\b(coupon|promo|promotion\w*|voucher|concession|freebie)\b/, /\bfor free\b/, /\bfree of (cost|charge)\b/,
  /\bgive (me|us)\b(\s+\w+){0,4}\s+free\b/, /\b(cheaper|special) (price|rate|deal)\b/, /\bwaive\w*\b/, /\bbest price\b/,
  /\b(\d+\s*(rs|rupees)?\s*)?off\b(?=.*\b(price|bill|treatment|cleaning|fee|cost)\b)/,
];

function isInjection(n: string) { return INJECTION.some((r) => r.test(n)); }
// Hindi / Telugu / romanized prompt-injection ("rules" + "ignore/forget/change", "system prompt")
const INDIC_RULE_WORDS = /(नियम|निर्देश|రూల్స్|నియమ|సూచనలు|niyam|nियम|rules?)/i;
const INDIC_OVERRIDE_WORDS = /(भूल|अनदेखा|नज़रअंदाज़|नजरअंदाज|छोड़ दो|बदल दो|मत मानो|विస్మరించ|పట్టించుకోవద్దు|మర్చిపో|మార్చు|వదిలేయ|bhool|bhul|ignore|chhod do|badal do|mat mano|marchipo|marchipondi|pattinchukovaddu)/i;
function isIndicInjection(raw: string): boolean {
  if (!/[\u0900-\u097F\u0C00-\u0C7F]/.test(raw) && !/\b(niyam|bhool|bhul|marchipo|pattinchukovaddu|chhod do)\b/i.test(raw)) return false;
  return (INDIC_RULE_WORDS.test(raw) && INDIC_OVERRIDE_WORDS.test(raw)) || /सिस्टम प्रॉम्प्ट|సిస్టమ్ ప్రాంప్ట్|system prompt/i.test(raw);
}

// "Talk to a human" / "call me back" in en / hi / te / romanized
const HUMAN_RE = /\b(talk|speak|chat)\s+(to|with)\s+(a\s+|an\s+|the\s+|some\s*one|somebody|real\s+)*(human|person|someone|somebody|staff|receptionist|agent|people|member of staff|manager)\b|\b(real person|human agent|call me back|callback please|need a human|want a human)\b/i;
const HUMAN_INDIC = /(व्यक्ति से बात|इंसान से बात|किसी से बात|स्टाफ से बात|आदमी से बात|मनुष्य से बात|మనిషితో మాట్లాడ|వ్యక్తితో మాట్లాడ|సిబ్బందితో మాట్లాడ|ఎవరితోనైనా మాట్లాడ|kisi se baat|insaan se baat|manishitho matladali)/i;
// "Share my phone number" / "Add my phone number"
const ASK_PHONE_RE = /^\s*((share|give|add|send|leave|take)\s+(my\s+)?(phone|mobile|contact)(\s+number)?|(मेरा|मेरी)\s+(फ़ोन|फोन|मोबाइल)\s*(नंबर)?\s*(साझा|दे|जोड़|लिख|लें|लो)?.*|నా\s+(ఫోన్|మొబైల్)\s*(నంబర్)?.*(ఇస్తాను|ఇవ్వ|జోడించ|తీసుకో).*|mera (phone|number) (do|le lo|add karo))\s*[.!]?\s*$/i;
function isDiscount(n: string) { return DISCOUNT.some((r) => r.test(n)) || hasPhrase(n, 'discount'); }

// ---------------------------------------------------------------- medical safety
const SYMPTOM = /\b(hurt\w*|pain\w*|ache\w*|aching|toothache|sore|swell\w*|swollen|bleed\w*|blood|sensitiv\w*|infect\w*|pus|abscess|throbbing|cracked|chipped|broken|broke|loose|wobbly|numb|numbness|fever|ulcer\w*|bump|lump|boil|stain\w*|bad breath|cavity hurting|decay\w*|black spot|hole in my tooth|bleeding gums?)\b/;
const MEDICATION = /\b(painkiller\w*|pain killer\w*|paracetamol|ibuprofen|aspirin|antibiotic\w*|amoxicillin|amoxycillin|metronidazole|dolo|crocin|combiflam|calpol|brufen|ketorol\w*|diclofenac|nimesulide|medicine\w*|medication\w*|tablet\w*|pill\w*|drug\w*|dose|dosage|ointment|gel|mouthwash|clove oil|home remed\w*|remed\w*|cure)\b/;
const ADVICE = /\b(should i|what should|what can i|is it (normal|serious|bad|safe|dangerous)|what does it mean|do i need|is this|diagnos\w*|what is wrong|what wrong|why does|why is my|safe (for|during|to)|pregnan\w*|diabet\w*|blood thinner\w*|heart patient|side effect\w*|allerg\w*)\b/;

const DIAG_Q = /\b(is (this|it|that)|do i have|could (it|this) be|am i having|does it look like)\b.*\b(cavity|cavities|decay|infection|infected|abscess|cancer|ulcer|gum disease|fill)\b/;
function medicalKind(n: string): 'symptom' | 'medication' | 'advice' | null {
  if (DIAG_Q.test(n)) return 'advice';
  if (MEDICATION.test(n)) return 'medication';
  if (SYMPTOM.test(n)) return 'symptom';
  if (/\b(pregnan\w*|diabet\w*|blood thinner\w*|heart patient|side effect\w*)\b/.test(n) && ADVICE.test(n)) return 'advice';
  return null;
}

// ---------------------------------------------------------------- intents
const PRICE_WORDS = ['how much', 'cost', 'costs', 'price', 'prices', 'pricing', 'fee', 'fees', 'charge', 'charges',
  'rate', 'rates', 'rs', 'rupees', 'inr', 'expensive', 'cheap', 'afford', 'tariff', 'budget', 'amount', 'quote', 'estimate'];
const DURATION_WORDS = ['how long', 'how much time', 'duration', 'minutes', 'how many visits', 'how many sittings',
  'sittings', 'how many appointments', 'take long', 'time does it take', 'time will it take'];
const HOURS_STRONG = ['open', 'opening', 'opens', 'close', 'closing', 'closes', 'closed', 'timing', 'timings', 'hours',
  'working hours', 'business hours', 'schedule', 'working', 'lunch', 'lunch break', 'break time', 'office hours',
  'clinic hours', 'opening time', 'closing time', 'shut'];
const HOURS_WEAK = ['when', 'what time', 'which days', 'what days', 'today', 'tomorrow', 'now', 'tonight', 'weekend', 'weekends'];
const DOCTOR_ASK = ['which doctor', 'which dentist', 'who', 'doctor', 'dentist', 'specialist', 'which specialist',
  'dr', 'doctors', 'dentists', 'consultant', 'surgeon', 'team', 'staff'];
const BOOK_WORDS = ['book', 'booking', 'appointment', 'appointments', 'reserve', 'slot', 'schedule me', 'schedule a', 'schedule an', 'fix an appointment', 'see the dentist', 'see your dentist',
  'come in', 'visit', 'see the doctor', 'see a dentist', 'see a doctor', 'see dr', 'consultation on', 'meet the doctor'];
const BOOK_REQUEST = /\b(i want|i would like|i wanna|i need|we need|we want|please book|book me|book us|book an?|book for|book with|can i (get|have|book|come)|could i (get|have|book)|can you book|could you book|i like to book|want to book|like to book|need to book|schedule (me|an|a)|fix (an|a|my)|make an appointment|get an appointment|request an appointment|reserve)\b/;
const HOW_QUESTION = /\b(how (do|can|should|to) (i|we|you)?\s*(book|make|cancel|reschedule)|how to book|can i book (on|by|through|via|over)|where (do|can) i book|cancel|cancellation|reschedul\w*|move my)\b/;

const LIVE_AVAILABILITY = /\b(slot|slots|vacanc\w*|free time|any (time|opening)|openings?|earliest|next available|availability|spare)\b/;
const AVAIL_WORD = /\b(available|availability|free|open|any|have|earliest|next)\b/;

const GREETING = /^(hi|hello|hey|hii+|helo|good (morning|afternoon|evening)|namaste|namaskar|namaskaram|vanakkam|salaam|hola|नमस्ते|నమస్కారం|నమస్తే)(\s+(there|team|doctor|sir|madam))?$/;
const THANKS = /^(thanks|thank you|thank u|thx|ty|ok thanks|okay thanks|great thanks|dhanyavad|dhanyavaad|shukriya|dhanyavadalu|thanks a lot|thank you so much|ok|okay|cool|great|bye|goodbye|धन्यवाद|ధన్యవాదాలు)$/;
const AFFIRM = /^(yes|yeah|yep|yup|sure|ok|okay|please|yes please|ok please|sure please|go ahead|haan|haa|ha ji|haanji|ji haan|avunu|sare|सही|हाँ|हां|అవును|సరే)(\s+(please|book|book it|i would|i do))?$/;

const DAY_REGEX = new RegExp(`\\b(${Object.keys(DAY_ALIASES).join('|')})\\b`, 'g');
function daysIn(n: string): number[] {
  const out = new Set<number>();
  for (const m of n.matchAll(DAY_REGEX)) {
    const w = m[1];
    // "sat"/"sun"/"mon"/"wed" are ambiguous English words; accept only near day context
    if (['sat', 'sun', 'mon', 'wed'].includes(w) && !/\b(on|this|next|every|open|till|until|to|from|by)\s+$/.test(n.slice(0, m.index))) continue;
    out.add(DAY_ALIASES[w]);
  }
  return [...out];
}
function weekdayIn(now: Date, tz: string, offsetDays = 0): number {
  const d = new Date(now.getTime() + offsetDays * 86400000);
  const name = new Intl.DateTimeFormat('en-US', { timeZone: tz, weekday: 'long' }).format(d);
  return DAY_NAMES.indexOf(name);
}

// ---------------------------------------------------------------- clause split
function splitClauses(raw: string): string[] {
  let s = raw.replace(/\bdr\.\s*/gi, 'Dr ').replace(/(\d)\.(\d)/g, '$1:$2');
  s = s.replace(/\s+(?:and|also|plus|&)\s+(?=(?:what|how|which|who|when|where|do|does|is|are|can|could|will|would|any|tell)\b)/gi, ' ||| ');
  s = s.replace(/[,;]\s*(?:and\s+)?also\b/gi, ' ||| ').replace(/\balso,?\s+(?=(?:what|how|which|who|when|where|do|does|is|are|can)\b)/gi, ' ||| ');
  return s.split(/\|\|\||[?!;\n।]+|\.(?:\s+|$)/).map((x) => x.trim()).filter((x) => x.length > 0);
}

// ---------------------------------------------------------------- matching helpers
const MODIFIERS = new Set(['clear', 'metal', 'ceramic', 'porcelain', 'deep', 'full', 'partial', 'simple', 'complex', 'basic',
  'advanced', 'complete', 'small', 'large', 'minor', 'major', 'front', 'back', 'upper', 'lower', 'new', 'regular', 'standard',
  'premium', 'normal', 'quick', 'express', 'laser', 'digital', 'cosmetic', 'surgical', 'permanent', 'temporary', 'child',
  'adult', 'kid', 'home', 'emergency', 'removal', 'treatment', 'whole', 'mouth']);
function matchServices(idx: KnowledgeIndex, toks: Set<string>): ServiceEntry[] {
  const scored = idx.services.map((s) => {
    const hits = s.primary.filter((t) => toks.has(t));
    const p = hits.length;
    const q = s.secondary.filter((t) => toks.has(t)).length;
    // a distinctive head word (e.g. "invisalign", "implant") identifies the service on its own;
    // a bare modifier ("clear", "metal", "deep") does not
    const strong = hits.some((t) => !MODIFIERS.has(t));
    return { s, p, q, strong, ratio: s.primary.length ? p / s.primary.length : 0 };
  });
  const primaryHits = scored.filter((x) => x.p > 0 && (x.ratio >= 0.5 || x.strong));
  if (primaryHits.length) {
    const best = Math.max(...primaryHits.map((x) => x.p + x.q + x.ratio));
    // keep every service the patient clearly named (multi-service questions), drop weaker partials
    return primaryHits.filter((x) => x.ratio === 1 || x.p + x.q + x.ratio >= best).map((x) => x.s);
  }
  return scored.filter((x) => x.q > 0).map((x) => x.s);
}

/**
 * A dentist counts as NAMED only by their first name ("Sneha") or with a title ("Dr Rao", "doctor Nair").
 * A bare surname is not enough — common surnames (Rao, Reddy, Nair) are often the PATIENT's own name —
 * and words that belong to the patient's own name never select a dentist.
 */
function matchDoctorsByName(idx: KnowledgeIndex, n: string, patientName?: string): DoctorEntry[] {
  const words = new Set(n.split(' '));
  const own = new Set(normalize(patientName || '').split(' ').filter(Boolean));
  const titledWords = new Set<string>();
  for (const m of n.matchAll(/\b(?:dr|doctor|dentist)\s+(\w+)(?:\s+(\w+))?/g)) { titledWords.add(m[1]); if (m[2]) titledWords.add(m[2]); }
  return idx.doctors.filter((d) => {
    if (d.nameTokens.some((tk) => tk.length > 2 && titledWords.has(tk))) return true; // "Dr Rao", "Dr Sneha Rao"
    const first = d.nameTokens[0];
    return !!first && first.length > 2 && words.has(first) && !own.has(first); // "Sneha" — but not the patient's own name
  });
}
function matchDoctorsByRole(idx: KnowledgeIndex, toks: Set<string>): DoctorEntry[] {
  return idx.doctors.filter((d) => d.roleTokens.some((t) => toks.has(t)));
}

function findInsurers(idx: KnowledgeIndex, n: string): string[] {
  const out: string[] = [];
  for (const ins of idx.knownInsurers) {
    if (hasPhrase(n, ins)) { out.push(ins); continue; }
    const first = ins.split(' ')[0];
    if (ins.includes(' ') && first.length >= 4 && !['star', 'care', 'new', 'national', 'future', 'united', 'universal', 'liberty', 'health'].includes(first) && hasPhrase(n, first)) out.push(ins);
  }
  // prefer the longest overlapping names
  return out.filter((a) => !out.some((b) => b !== a && b.includes(a)));
}

function serviceLine(s: ServiceEntry['service'], t: Templates): string {
  const extra = [asText(s.note), s.duration ? t.takesAbout(asText(s.duration)) : ''].filter(Boolean).join('; ');
  return t.serviceLine(t.serviceName(String(s.name)), asText(s.price), extra);
}

function doctorLine(d: DoctorEntry, t: Templates): string {
  return t.doctorLine(String(d.doctor.name), asText(d.doctor.role), d.daysText);
}

function extractBooking(raw: string, n: string, doctors: DoctorEntry[], services: ServiceEntry[]): BookingDetails {
  const dateM = n.match(/\b(today|tomorrow|day after tomorrow|tonight|this (monday|tuesday|wednesday|thursday|friday|saturday|sunday|week|weekend)|next (monday|tuesday|wednesday|thursday|friday|saturday|sunday|week)|(on )?(monday|tuesday|wednesday|thursday|friday|saturday|sunday)|\d{1,2}(st|nd|rd|th)? (of )?(jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)\w*|(jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)\w* \d{1,2}(st|nd|rd|th)?)\b/)
    || raw.match(/\b\d{1,2}[/-]\d{1,2}([/-]\d{2,4})?\b/);
  // most specific first: "5:30 pm" / "17:00" / "at 5" beat a day part ("evening") added by a Hindi/Telugu hint
  const timeM = n.match(/\b(\d{1,2}(:\d{2})?\s?(am|pm))\b/) || n.match(/\b(\d{1,2}:\d{2})\b/) || n.match(/\bat (\d{1,2})\b(?!\s*(st|nd|rd|th|nov|dec|jan|feb|mar|apr|may|jun|jul|aug|sep|oct))/)
    || n.match(/\b(morning|afternoon|evening|noon|after work|after office)\b/);
  const contact = extractContact(raw);
  const dateText = dateM ? dateM[0].replace(/^on /, '').replace(/\b[a-z]/g, (c) => c.toUpperCase()) : undefined;
  const timeText = timeM ? timeM[0].replace(/^at /, '') : undefined;
  return {
    dateText, timeText,
    doctor: doctors[0]?.doctor.name,
    service: services[0]?.service.name,
    patientName: contact.name,
    phone: contact.phone,
    needsClarification: !dateText || !timeText,
  };
}

const PHONE_RE = /(?:\+?91[\s-]?)?(?:0\d{2,4}[\s-]?\d{3,4}[\s-]?\d{4}|[6-9]\d{4}[\s-]?\d{5}|[6-9]\d{9})\b/;
// prefix in any case ('I am', 'i am', 'My name is'); the name itself must be capitalised
const NAME_RE = /\b(?:[Mm]y [Nn]ame [Ii]s|[Mm]y [Nn]ame's|[Nn]ame [Ii]s|[Nn]ame:|[Tt]his [Ii]s|[Ii] [Aa]m|[Ii]'[Mm]|[Ii]m)\s+([A-Z][a-zA-Z]+(?:\s+[A-Z][a-zA-Z]+)?)/;
const NOT_A_NAME = new Set(['doctor', 'doctors', 'dentist', 'dentists', 'prices', 'price', 'timings', 'timing', 'insurance', 'location', 'yes', 'no', 'ok', 'okay', 'thanks', 'hello', 'hi', 'cleaning', 'filling', 'braces', 'morning', 'evening', 'afternoon', 'today', 'tomorrow', 'emergency', 'help', 'whitening', 'implant', 'consultation']);
const NOT_NAMES = new Set(['In', 'Not', 'Having', 'Very', 'So', 'Looking', 'Interested', 'Going', 'Calling', 'Here', 'From', 'The', 'A', 'An', 'Sorry', 'Fine', 'Ok', 'Okay', 'Your', 'Free', 'Available', 'Pregnant', 'Diabetic', 'Asking', 'Writing', 'New', 'Planning', 'Afraid', 'Scared', 'Worried']);

export function extractContact(raw: string): ContactDetails {
  const phone = raw.match(PHONE_RE)?.[0]?.trim();
  const m = raw.match(NAME_RE);
  let name = m && !NOT_NAMES.has(m[1].split(' ')[0]) ? m[1] : undefined;
  if (!name && phone) {
    // "Ravi Kumar 98765 43210" / "Ravi Kumar, phone 98765 43210"
    const rest = raw.replace(phone, ' ').replace(/[,.;:\-–]/g, ' ').trim().split(/\s+/)
      .filter((w) => w && !CONTACT_FILLER.has(w.toLowerCase()));
    if (rest.length >= 1 && rest.length <= 3 && rest.every((w) => /^[A-Z][a-z]+$/.test(w)) && !NOT_NAMES.has(rest[0])) name = rest.join(' ');
  }
  return { ...(name ? { name } : {}), ...(phone ? { phone } : {}) };
}

const CONTACT_FILLER = new Set(['my', 'name', 'is', 'number', 'phone', 'mobile', 'contact', 'call', 'me', 'here', 'it', 'this', 'am', 'and', 'on', 'at', 'cell', 'whatsapp', 'details', 'please', 'you', 'can', 'reach', 'back', 'sir', 'madam', 'thanks', 'thank', 'ok', 'okay', 'yes', 'sure', 'mr', 'mrs', 'ms', 'miss', 'dr', 'no', 'num', 'ph', 'mob', 'tel', 'the', 'is', 'i', 'a', 'callback', 'later']);
function isContactOnly(raw: string, c: ContactDetails): boolean {
  if (!c.phone && !c.name) return false;
  let rest = raw;
  if (c.phone) rest = rest.replace(c.phone, ' ');
  if (c.name) rest = rest.replace(c.name, ' ');
  const words = normalize(rest).split(' ').filter((w) => w && !CONTACT_FILLER.has(w) && !/^\d+$/.test(w));
  // a bare "Ravi Kumar 98765 43210" leaves only the (capitalised) name words
  const capitalised = new Set((rest.match(/\b[A-Z][a-z]+\b/g) || []).map((w) => w.toLowerCase()));
  return words.filter((w) => !(c.phone && capitalised.has(w))).length === 0;
}

function contentWords(n: string): string[] {
  return n.split(' ').filter((w) => w.length > 2 && !STOPWORDS.has(w) && !/^\d+$/.test(w));
}

// ---------------------------------------------------------------- main entry
export function answerQuestion(question: string, data: ClinicData, ctx: EngineContext = {}): EngineResult {
  const idx = getIndex(data, ctx.knowledgeVersion);
  const lang = detectLang(question);
  const now = ctx.now || new Date();
  const tz = 'Asia/Kolkata';
  const t = T(lang);
  const parts: AnswerPart[] = [];
  const intents = new Set<string>();
  const unsupported: string[] = [];
  let booking: BookingDetails | undefined;
  let offer: 'booking' | undefined;
  let followUp: FollowUp | undefined;
  const contact = extractContact(question);
  const known: ContactDetails = { ...ctx.knownContact, ...contact };
  const add = (p: AnswerPart) => { if (!parts.some((x) => x.key === p.key)) parts.push(p); };

  const fullNorm = addIndicHints(normalize(question));
  const cal = buildCalendar(idx);

  /** Resolve dates/times, list what is missing, check LISTED hours, and set the request state. */
  const completeBooking = (b: BookingDetails): BookingDetails => {
    const out: BookingDetails = { ...b };
    out.phone = out.phone || known.phone; out.patientName = out.patientName || known.name;
    const d = resolveDate(out.dateText, now);
    const tm = resolveTime(out.timeText);
    out.requestedDate = d.ymd && !d.past ? d.ymd : undefined;
    out.requestedTime = tm.hm;
    out.requestedWindow = tm.window;
    if (!tm.window) delete out.requestedWindow;
    out.dateIssue = d.past ? 'past' : d.vague ? 'vague' : undefined;
    out.timeIssue = tm.vague ? 'vague' : undefined;
    const missing: BookingDetails['missing'] = [];
    if (!out.requestedDate) missing.push('date');
    if (!out.requestedTime && !out.requestedWindow) missing.push('time');
    if (!out.patientName) missing.push('name');
    if (!out.phone) missing.push('phone');
    if (!out.service) missing.push('treatment');
    out.missing = missing;
    out.needsClarification = !out.requestedDate || (!out.requestedTime && !out.requestedWindow);
    const issues = slotIssues(idx, cal, out.requestedDate, out.requestedTime, out.doctor);
    if (d.past) issues.unshift({ code: 'past-date' });
    else if (out.requestedDate === istDate(now)) {
      const t0 = istMinutes(now);
      const reqMin = out.requestedTime ? Number(out.requestedTime.slice(0, 2)) * 60 + Number(out.requestedTime.slice(3))
        : out.requestedWindow ? Number(out.requestedWindow.to.slice(0, 2)) * 60 : undefined;
      if (reqMin !== undefined && reqMin <= t0) issues.unshift({ code: 'past-time' });
    }
    out.issues = issues;
    out.outsideHours = issues.some((x) => OUTSIDE_CODES.has(x.code));
    out.warnings = issues.map((x) => T('en').slotIssue(x)); // English copy for the staff dashboard
    if (out.state !== 'confirmed') {
      const complete = !!(out.requestedDate && (out.requestedTime || out.requestedWindow) && out.patientName && out.phone);
      out.state = complete ? 'awaiting confirmation' : 'requested';
      delete out.confirmedDate; delete out.confirmedTime; delete out.decidedBy; delete out.decidedAt; delete out.decisionNote;
    }
    return out;
  };

  const finish = (): EngineResult => {
    const emergency = intents.has('emergency');
    const needsHuman = unsupported.length > 0 || intents.has('booking') || intents.has('discount-request');
    const status = emergency ? 'urgent' : needsHuman ? 'needs human' : 'answered';
    const priority: Priority = emergency ? 'critical' : status === 'answered' ? 'low' : 'normal';
    const ticketType = emergency ? 'emergency' : intents.has('booking') ? 'booking' : unsupported.length || intents.has('discount-request') ? 'unsupported' : 'enquiry';
    if (unsupported.length && !emergency) add({ kind: 'unsupported', key: 'unsupported', text: t.unsupported(unsupported, idx.mainPhone, !known.phone) });
    const reply = parts.map((p) => p.text).join('\n\n').trim();
    const faqUsed = parts.some((p) => p.kind === 'faq');
    const faqMixed = faqUsed && parts.some((p) => p.kind !== 'faq');
    if (!unsupported.length) for (const i of [...intents]) if (i.startsWith('unsupported')) intents.delete(i);
    return {
      reply, parts, status, priority, ticketRequired: status !== 'answered', ticketType,
      intents: [...intents], unsupportedTopics: unsupported, lang, source: faqUsed ? 'staff-faq' : 'clinic-file', faqUsed, faqMixed, emergency,
      offer, booking, knowledgeVersion: ctx.knowledgeVersion, followUp, contact,
    };
  };

  // 0. empty
  if (!fullNorm) { add({ kind: 'greeting', key: 'empty', text: t.empty() }); return finish(); }

  // 1. EMERGENCY — always first, never waits on anything else
  if (isEmergency(question)) {
    intents.add('emergency');
    add({ kind: 'emergency', key: 'emergency', text: t.emergency(idx.emergencyPhone || idx.mainPhone || '', idx.emergencyRules) });
    return finish();
  }

  // 2. greeting / thanks / affirmation-only messages
  if (GREETING.test(fullNorm)) { intents.add('greeting'); followUp = 'smalltalk'; add({ kind: 'greeting', key: 'greet', text: t.greeting(idx.clinicName) }); return finish(); }
  if (THANKS.test(fullNorm) && !(ctx.lastOffer === 'booking' && AFFIRM.test(fullNorm))) { intents.add('thanks'); followUp = 'smalltalk'; add({ kind: 'thanks', key: 'thanks', text: t.thanks() }); return finish(); }
  if ((ctx.lastOffer === 'booking' || ctx.pendingBooking) && AFFIRM.test(fullNorm)) {
    intents.add('booking');
    followUp = 'booking-start';
    booking = completeBooking({ ...(ctx.pendingBooking || {}), needsClarification: true });
    add({ kind: 'booking', key: 'booking', text: ctx.pendingBooking ? t.bookingReply(booking, { updated: true }) : t.bookingAsk(policyText(idx, 'appoint')) });
    return finish();
  }

  // 2a. "Share/Add my phone number" chips — ask for the details, join the open request
  if (ASK_PHONE_RE.test(question.trim()) && !contact.phone) {
    intents.add('contact');
    followUp = 'contact';
    add({ kind: 'thanks', key: 'ask-phone', text: t.askPhone() });
    const r = finish();
    return ctx.hasOpenTicket ? r : { ...r, status: 'needs human', ticketRequired: true, ticketType: 'human' };
  }
  // 2a'. "Talk to a human" → needs-human ticket (type human) with the callback promise
  if ((HUMAN_RE.test(question) || HUMAN_INDIC.test(question)) && !isInjection(fullNorm) && !isIndicInjection(question)) {
    intents.add('human');
    add({ kind: 'human', key: 'human', text: t.human(!known.phone, idx.mainPhone) });
    const r = finish();
    return { ...r, status: 'needs human', ticketRequired: true, ticketType: 'human', priority: 'normal' };
  }

  // 2b. follow-up details for an open booking request ("Saturday at 11am", "Ravi 98765 43210")
  if (ctx.pendingBooking) {
    // a quick-reply topic chip ("Doctors", "Prices", "डॉक्टर" …) is a new question, never booking details
    const chipTopic = (['timings', 'doctors', 'prices', 'insurance', 'location', 'human'] as const).some((k) => (['en', 'hi', 'te'] as const).some((l) => QUICK_LABELS[l][k].toLowerCase() === question.trim().toLowerCase()));
    const otherTopic = chipTopic || anyPhrase(fullNorm, [...PRICE_WORDS, 'insurance', 'cashless', 'open', 'opening', 'close', 'closing', 'timing', 'timings', 'hours', 'address', 'where', 'location', 'parking', 'emi', 'payment', 'who', 'which doctor', 'doctor', 'doctors', 'dentist', 'dentists', 'human', 'person']) || isInjection(fullNorm) || isDiscount(fullNorm) || medicalKind(fullNorm) !== null;
    const docs = matchDoctorsByName(idx, fullNorm, contact.name);
    const svcs = matchServices(idx, new Set(tokens(fullNorm)));
    const b2 = extractBooking(question, fullNorm, docs, svcs);
    // a bare "Ravi Kumar" when we asked for the name
    if (!b2.patientName && !ctx.pendingBooking.patientName) {
      const words = question.trim().replace(/[.,!]+$/, '').split(/\s+/);
      if (words.length >= 1 && words.length <= 3 && words.every((w) => /^[A-Z][a-z]+$/.test(w) && !NOT_A_NAME.has(w.toLowerCase())) && !daysIn(normalize(question)).length && !docs.length && !svcs.length) b2.patientName = words.join(' ');
    }
    const hasField = !!(b2.dateText || b2.timeText || b2.phone || b2.patientName || b2.doctor || b2.service);
    const isQuestion = /\?/.test(question) || /^(what|how|which|who|when|where|why|do|does|is|are|can|could|will)\b/.test(fullNorm);
    if (!otherTopic && (hasField || (!isQuestion && contentWords(fullNorm).length > 0 && !isContactOnly(question, contact)))) {
      const merged: BookingDetails = { ...ctx.pendingBooking };
      for (const k of ['dateText', 'timeText', 'doctor', 'service', 'patientName', 'phone'] as const) if (b2[k]) merged[k] = b2[k];
      if (!hasField) merged.notes = [...(merged.notes || []), question.trim().slice(0, 300)]; // additional information
      if (merged.state === 'rejected' && (b2.dateText || b2.timeText)) merged.state = undefined; // new time after a rejection
      booking = completeBooking(merged);
      intents.add('booking');
      followUp = 'booking-update';
      add({ kind: 'booking', key: 'booking', text: t.bookingReply(booking, { updated: true, noteAdded: !hasField }) });
      return finish();
    }
  }

  // 2c. a message that only gives a name / phone number
  if (isContactOnly(question, contact)) {
    intents.add('contact');
    followUp = 'contact';
    if (!ctx.hasOpenTicket) unsupported.length = 0;
    add({ kind: 'thanks', key: 'contact', text: t.contactThanks(contact.name || ctx.knownContact?.name, !!ctx.hasOpenTicket) });
    const r = finish();
    // a new callback request with no earlier enquiry still needs a person
    return ctx.hasOpenTicket ? r : { ...r, status: 'needs human', ticketRequired: true, ticketType: 'unsupported' };
  }

  // 3. clause-by-clause analysis (multi-topic support)
  const clauses = splitClauses(question);
  let carriedDays: number[] = [];
  let carriedServices: ServiceEntry[] = [];
  let carriedDoctors: DoctorEntry[] = [];
  // message-level symptom / self-diagnosis question ("Is this a cavity? I see a black spot")
  const medMsg = medicalKind(fullNorm) !== null || DIAG_Q.test(fullNorm);
  for (const rawClause of clauses) {
    const n = addIndicHints(normalize(rawClause));
    if (!n) continue;
    const toks = new Set(tokens(n));
    let handled = false;
    const uStart = unsupported.length;
    const pStart = parts.length;
    /** Staff-approved FAQ answers replace this clause's "unknown" outcome (never safety outcomes). */
    const applyFaq = () => {
      if (unsupported.length <= uStart) return;
      const hit = matchFaq(idx, rawClause) || (clauses.length > 1 ? null : matchFaq(idx, question));
      if (!hit) return;
      unsupported.splice(uStart);
      for (let i = parts.length - 1; i >= pStart; i--) if (parts[i].kind === 'unsupported') parts.splice(i, 1);
      intents.add('faq');
      add({ kind: 'faq', key: `faq-${hit.from || hit.q}`, text: hit.a }); // quoted verbatim
    };

    if (GREETING.test(n) || THANKS.test(n)) continue;
    // a sentence that only carries the patient's name / phone ("I am Ravi Kumar, 98765 43210") is not a question
    if (clauses.length > 1 && isContactOnly(rawClause, extractContact(rawClause))) continue;
    const stripped = n.replace(/^(hi|hello|hey|namaste|good (morning|afternoon|evening))\s+/, '');

    // 3a. prompt injection / discount demands — refuse politely, never echo the request
    if (isInjection(stripped) || isIndicInjection(rawClause) || isDiscount(stripped)) {
      intents.add('refusal');
      const inj = isInjection(stripped) || isIndicInjection(rawClause);
      add({ kind: 'refusal', key: 'refusal', text: inj ? t.refusalInjection() : t.refusalDiscount() });
      // a plain discount request goes to a person (no discount is promised); rule-breaking attempts are just refused
      if (!inj) { intents.add('discount-request'); add({ kind: 'refusal', key: 'discount-noted', text: t.discountNoted() }); }
      handled = true;
      // a manipulation clause is fully consumed; do not answer anything inside it
      continue;
    }

    // 3b. medical safety
    const med = medicalKind(stripped);
    if (med) {
      intents.add('medical');
      add({ kind: 'medical', key: 'medical', text: t.medical(med) });
      offer = 'booking';
      handled = true;
    }

    // dates
    let qDays = daysIn(stripped);
    if (hasPhrase(stripped, 'today') || hasPhrase(stripped, 'now') || hasPhrase(stripped, 'tonight')) qDays.push(weekdayIn(now, tz));
    if (hasPhrase(stripped, 'tomorrow')) qDays.push(weekdayIn(now, tz, 1));
    if (hasPhrase(stripped, 'day after tomorrow')) qDays.push(weekdayIn(now, tz, 2));
    if (/\bweekends?\b/.test(stripped)) qDays.push(6, 0);
    qDays = [...new Set(qDays)];
    if (!qDays.length && /^(and |what about |how about )/.test(stripped)) qDays = carriedDays;
    if (qDays.length) carriedDays = qDays;
    const holidayAsked = anyPhrase(stripped, HOLIDAY_WORDS);

    // entity matches
    const docsByName = matchDoctorsByName(idx, n, contact.name);
    const docsByRole = matchDoctorsByRole(idx, toks);
    let services = matchServices(idx, toks);
    const priceAsked = anyPhrase(stripped, PRICE_WORDS) && !anyPhrase(stripped, ['how much time']);
    const durationAsked = anyPhrase(stripped, DURATION_WORDS);
    const doctorAsked = anyPhrase(stripped, DOCTOR_ASK) || toks.has('doctor') || toks.has('ortho');
    const insurers = findInsurers(idx, stripped);
    // follow-up like "Do you do braces? How much?" → apply to the service just mentioned
    if (!services.length && (priceAsked || durationAsked) && carriedServices.length && contentWords(stripped).filter((w) => !PRICE_WORDS.includes(w) && !DURATION_WORDS.includes(w)).length === 0) services = carriedServices;
    if ((med || medMsg) && !priceAsked && !durationAsked) services = []; // "is this a cavity?" must not turn into a filling price
    if (services.length) carriedServices = services;
    const insuranceAsked = insurers.length > 0 || anyPhrase(stripped, ['insurance', 'insurer', 'insurers', 'cashless', 'claim', 'mediclaim', 'tpa', 'reimbursement', 'health card', 'health policy']);

    // unknown dental services/brands (never inferred)
    const unknownTerms: string[] = [];
    for (const term of DENTAL_TERMS) {
      const hit = term.phrases.find((p) => hasPhrase(stripped, p));
      if (!hit) continue;
      const hitToks = tokens(normalize(hit)).filter((x) => !['tooth', 'dental'].includes(x));
      const coveredByService = idx.services.some((s) => hitToks.length > 0 && hitToks.every((x) => [...s.primary, ...s.secondary].includes(x)));
      const coveredByDoctor = idx.doctors.some((d) => hitToks.length > 0 && hitToks.every((x) => d.roleTokens.includes(x)));
      if (!coveredByService && !coveredByDoctor) unknownTerms.push(term.label);
      // mention what the file DOES say, without inferring
      if (!coveredByService && !coveredByDoctor && term.related) {
        for (const r of term.related) {
          const d = idx.doctors.find((x) => x.roleTokens.includes(stem(r)));
          const sv = idx.services.find((x) => [...x.primary, ...x.secondary].includes(stem(r)));
          const note = idx.services.map((x) => asText(x.service.note)).find((x) => normalize(x).includes(normalize(r)));
          if (d) add({ kind: 'unsupported', key: `related-${term.label}`, text: t.relatedDoctor(term.label, d.doctor.name, asText(d.doctor.role)) });
          else if (sv) add({ kind: 'unsupported', key: `related-${term.label}`, text: t.relatedService(term.label, sv.service.name) });
          else if (note) add({ kind: 'unsupported', key: `related-${term.label}`, text: t.relatedNote(term.label, note) });
        }
      }
    }
    if (unknownTerms.length) { unknownTerms.forEach((x) => { if (!unsupported.includes(x)) unsupported.push(x); }); handled = true; intents.add('unsupported-service'); }

    // 3c. booking request
    const bookingWord = anyPhrase(stripped, BOOK_WORDS);
    const isHowTo = HOW_QUESTION.test(stripped);
    const hasWhen = qDays.length > 0 || /\b\d{1,2}(:\d{2})?\s?(am|pm)\b|\b(morning|afternoon|evening)\b/.test(stripped);
    const indicBooking = /[\u0900-\u097F\u0C00-\u0C7F]/.test(rawClause) && /\b(book|appointment)\b/.test(stripped) && !/(कैसे|किस तरह|ఎలా|ఎక్కడ)/.test(rawClause);
    const romanBooking = /\b(chahiye|karna hai|karwana|kavali|cheyandi|cheyali|book karo|book kar do)\b/.test(stripped) && /\b(book|appointment)\b/.test(stripped);
    const bookingRequest = bookingWord && !isHowTo && (BOOK_REQUEST.test(stripped) || indicBooking || romanBooking || (hasWhen && /\b(book|appointment|slot)\b/.test(stripped)) || /^(book|appointment)\b/.test(stripped));
    if (bookingRequest) {
      intents.add('booking');
      // only a dentist the patient actually NAMED is recorded as their preference
      booking = completeBooking(extractBooking(rawClause, stripped, docsByName, services));
      add({ kind: 'booking', key: 'booking', text: t.bookingReply(booking, { updated: false, policy: policyText(idx, 'appoint') }) });
      handled = true;
      if (!priceAsked && !insuranceAsked) { applyFaq(); continue; }
    }

    // 3c'. live slot availability is not in the clinic file — never invent it
    const liveAvail = !bookingRequest && LIVE_AVAILABILITY.test(stripped) && AVAIL_WORD.test(stripped);
    const doctorAtTime = !bookingRequest && docsByName.length > 0 && /\b(free|available|availability)\b/.test(stripped) && /\b\d{1,2}(:\d{2})?\s?(am|pm)\b/.test(stripped);
    if (liveAvail || doctorAtTime) {
      intents.add('unsupported-availability');
      if (!unsupported.includes('live appointment availability')) unsupported.push('live appointment availability');
      add({ kind: 'unsupported', key: 'no-live-slots', text: t.noLiveSlots() });
      offer = 'booking';
      handled = true;
    }

    // 3c''. a specialist / "who does X" that no listed dentist covers → unknown path (never guess)
    const rawLower = rawClause.toLowerCase();
    const specialty = SPECIALTIES.find((sp) => sp.re.test(rawLower));
    const docsBySpecialty = specialty ? idx.doctors.filter((d) => d.roleTokens.some((x) => specialty.roles.includes(x))) : [];
    if (specialty && docsBySpecialty.length) for (const d of docsBySpecialty) if (!docsByRole.includes(d)) docsByRole.push(d);
    const whoAsk = /\b(who|which)\b/.test(stripped) && (toks.has('doctor') || toks.has('ortho') || /\bwho (does|do|treats|handles|sees|is|will|can)\b/.test(stripped));
    const topicAsked = !!specialty || services.length > 0 || [...toks].some((x) => ROLE_TOPIC.has(x));
    let noDoctorForTopic = false;
    if (!docsByName.length && !docsByRole.length && !unknownTerms.length && ((specialty && !docsBySpecialty.length) || (whoAsk && topicAsked))) {
      noDoctorForTopic = true;
      intents.add('unsupported-doctor');
      const what = specialty ? specialty.label : services.length ? `which dentist provides ${services[0].service.name.toLowerCase()}` : 'which dentist handles that';
      if (!unsupported.includes(what)) unsupported.push(what);
      handled = true;
    }

    // 3d. doctors ("when is she available?" → the doctor's listed days + the clinic's hours on those days)
    const whenAsked = /\b(when|available|availability|timing|timings|hours|what days|which days|days)\b/.test(stripped);
    const pronounOnly = /\b(she|he|they|her|him|them|that doctor|the doctor)\b/.test(stripped);
    const docHours = (d: DoctorEntry) => { if (d.days.length) add({ kind: 'doctor', key: `doc-hours-${d.doctor.name}`, text: t.doctorHours(String(d.doctor.name), d.daysText, doctorHourGroups(idx, d, t)) }); };
    if (!docsByName.length && !docsByRole.length && carriedDoctors.length && whenAsked && (pronounOnly || contentWords(stripped).filter((w) => /^[a-z]+$/.test(w) && !['available', 'availability', 'timing', 'timings', 'hours', 'days'].includes(w)).length === 0)) {
      intents.add('doctor');
      carriedDoctors.forEach(docHours);
      handled = true;
    }
    if (docsByName.length || docsByRole.length) carriedDoctors = docsByName.length ? docsByName : docsByRole;
    if (docsByName.length) {
      intents.add('doctor');
      for (const d of docsByName) {
        let text = doctorLine(d, t);
        if (qDays.length && d.days.length) {
          const on = qDays.filter((x) => d.days.includes(x)).map((x) => t.day(x));
          const off = qDays.filter((x) => !d.days.includes(x)).map((x) => t.day(x));
          if (on.length) text = t.doctorOnDay(d.doctor.name, on.join(' and '), d.daysText);
          if (off.length) text = (on.length ? text + ' ' : '') + t.doctorNotOnDay(d.doctor.name, off.join(' and '), d.daysText);
        }
        add({ kind: 'doctor', key: `doc-${d.doctor.name}`, text });
        if (whenAsked && !qDays.length) docHours(d);
      }
      handled = true;
    } else if (docsByRole.length && (doctorAsked || !services.length) && !(medMsg && !doctorAsked)) {
      intents.add('doctor');
      for (const d of docsByRole) {
        let text = doctorLine(d, t);
        const off = qDays.filter((x) => d.days.length && !d.days.includes(x)).map((x) => t.day(x));
        if (off.length) text += ' ' + t.doctorNotOnDay(d.doctor.name, off.join(' and '), d.daysText);
        add({ kind: 'doctor', key: `doc-${d.doctor.name}`, text });
        if (whenAsked && !qDays.length) docHours(d);
      }
      // a related policy (e.g. children → parent must be present)
      for (const p of idx.policies) if (p.keywords.some((k) => hasPhrase(stripped, k)) && !/insur|payment|emi/.test(p.key)) add({ kind: 'policy', key: `pol-${p.key}`, text: t.policy(p.label, p.value) });
      handled = true;
    } else if (!noDoctorForTopic && doctorAsked && !services.length && !priceAsked && !insuranceAsked && (/\b(who|which|doctor|doctors|dentist|dentists|specialist|team)\b/.test(stripped))) {
      // general doctor list — but only if nothing more specific was asked
      const specificUnknown = unknownTerms.length > 0;
      if (!specificUnknown && idx.doctors.length && !anyPhrase(stripped, ['emergency number', 'phone'])) {
        intents.add('doctor');
        add({ kind: 'doctor', key: 'doc-all', text: t.doctorList(idx.doctors.map((d) => doctorLine(d, t))) });
        handled = true;
      }
    }

    // 3e. services & prices
    if (services.length) {
      intents.add('service');
      for (const s of services) {
        let text = serviceLine(s.service, t);
        if (durationAsked && !s.service.duration && !s.service.note) { unsupported.push(`how long ${s.service.name.toLowerCase()} takes`); }
        add({ kind: 'service', key: `svc-${s.service.name}`, text });
      }
      if (doctorAsked && docsByRole.length && !docsByName.length) for (const d of docsByRole) add({ kind: 'doctor', key: `doc-${d.doctor.name}`, text: doctorLine(d, t) });
      handled = true;
    } else if (priceAsked && !unknownTerms.length && !insuranceAsked && !docsByName.length && !docsByRole.length) {
      const leftover = contentWords(stripped).filter((w) => /^[a-z0-9]+$/.test(w)).filter((w) => !PRICE_WORDS.includes(w) && !['list', 'treatment', 'treatments', 'services', 'service', 'procedure', 'procedures', 'dental', 'clinic', 'charge', 'charges', 'all', 'your', 'tooth', 'teeth', 'everything', 'general', 'typical', 'usual', 'approximate', 'approx', 'roughly', 'average', 'kind', 'different'].includes(w));
      if (leftover.length === 0 || anyPhrase(stripped, ['price list', 'all prices', 'all treatments', 'all services', 'your prices', 'your fees', 'your charges', 'rate card', 'fee list'])) {
        intents.add('price-list');
        add({ kind: 'price-list', key: 'price-list', text: t.priceList(idx.services.map((s) => serviceLine(s.service, t))) });
        handled = true;
      } else if (!handled) {
        // price of something we cannot identify — never guess
        intents.add('unsupported-price');
        if (!unsupported.includes('that price')) unsupported.push('that price');
        handled = true;
      }
    }

    // 3f. insurance
    if (insuranceAsked) {
      intents.add('insurance');
      const ins = idx.insuranceText;
      if (!ins) { unsupported.push('insurance'); }
      else if (insurers.length) {
        for (const name of insurers) {
          const onList = idx.cashlessProviders.find((p) => normalize(p) === name || normalize(p).includes(name) || name.includes(normalize(p)));
          if (onList) add({ kind: 'insurance', key: `ins-${name}`, text: t.insuranceYes(onList, ins) });
          else {
            // an insurer the file does not name: never decide for the patient — state the file's policy and escalate
            add({ kind: 'insurance', key: 'ins-general', text: t.insuranceGeneral(idx.cashlessProviders, ins) });
            if (!unsupported.includes(`insurance with ${prettyName(name)}`)) unsupported.push(`insurance with ${prettyName(name)}`);
          }
        }
      } else add({ kind: 'insurance', key: 'ins-general', text: t.insuranceGeneral(idx.cashlessProviders, ins) });
      handled = true;
    }

    // 3g. opening hours
    const hoursStrong = anyPhrase(stripped, HOURS_STRONG) || holidayAsked;
    const hoursWeak = anyPhrase(stripped, HOURS_WEAK) || qDays.length > 0;
    const onlyDayQuestion = !handled && qDays.length > 0;
    if ((hoursStrong && !(intents.has('booking') && !anyPhrase(stripped, ['open', 'close', 'timing', 'hours']))) || (!handled && hoursWeak) || onlyDayQuestion) {
      if (idx.hours.length) {
        intents.add('hours');
        if (/\b(now|right now|currently|open today)\b/.test(stripped) || /(अभी|ఇప్పుడు|abhi|ippudu)/i.test(rawClause)) {
          add({ kind: 'open-now', key: 'open-now', text: t.openNow(openStatus(cal, now)) });
        }
        add({ kind: 'hours', key: `hours-${qDays.join(',')}-${holidayAsked}-${hasPhrase(stripped, 'lunch')}`, text: hoursAnswer(idx, qDays, holidayAsked, hasPhrase(stripped, 'lunch') || hasPhrase(stripped, 'break'), t) });
        handled = true;
      } else if (hoursStrong) { unsupported.push('opening hours'); handled = true; }
    }

    // 3h. policies
    for (const p of idx.policies) {
      if (/insur|cashless|mediclaim/.test(normalize(p.key))) continue; // handled above
      if (intents.has('booking') && /appoint/.test(p.key)) continue;
      if (p.keywords.some((k) => hasPhrase(stripped, k))) {
        if (/child/.test(normalize(p.key)) && intents.has('doctor')) { add({ kind: 'policy', key: `pol-${p.key}`, text: t.policy(p.label, p.value) }); continue; }
        intents.add('policy');
        add({ kind: 'policy', key: `pol-${p.key}`, text: t.policy(p.label, p.value) });
        handled = true;
      }
    }

    // 3i. clinic contact / location / other fields
    const fieldHits = idx.clinicFields.filter((f) => f.keywords.some((k) => hasPhrase(stripped, k)));
    let fields = fieldHits;
    // "where do I park" → parking only; "emergency number" → emergency line, not main phone
    if (fields.some((f) => f.key === 'parking')) fields = fields.filter((f) => !['address', 'landmark'].includes(f.key) || anyPhrase(stripped, ['address', 'located', 'location', 'landmark']));
    if (fields.some((f) => f.key === 'emergency_phone')) fields = fields.filter((f) => f.key !== 'phone' || hasPhrase(stripped, 'main'));
    if (fields.some((f) => f.key === 'whatsapp')) fields = fields.filter((f) => f.key !== 'phone' || anyPhrase(stripped, ['phone', 'call']));
    if (handled && !anyPhrase(stripped, ['address', 'located', 'location', 'landmark', 'phone', 'whatsapp', 'parking', 'language', 'languages', 'emergency number', 'number', 'contact', 'speak'])) fields = [];
    if (intents.has('booking')) fields = fields.filter((f) => f.key !== 'phone');
    if (fields.length) {
      if (fields.some((f) => f.key === 'address') && !fields.some((f) => f.key === 'landmark')) {
        const lm = idx.clinicFields.find((f) => f.key === 'landmark'); if (lm) fields.push(lm);
      }
      for (const f of fields) {
        if (f.key === 'name') { intents.add('clinic-info'); add({ kind: 'clinic-info', key: 'f-name', text: t.clinicName(f.value) }); continue; }
        intents.add(['address', 'landmark'].includes(f.key) ? 'location' : ['phone', 'whatsapp', 'emergency_phone'].includes(f.key) ? 'contact' : 'clinic-info');
        add({ kind: ['address', 'landmark'].includes(f.key) ? 'location' : 'contact', key: `f-${f.key}`, text: t.field(f.key, f.label, f.value) });
      }
      handled = true;
    }

    // asked a specific clinic detail that the file does not hold (e.g. "Do you have parking?" with no parking field)
    if (!handled) {
      const askedField = Object.entries({ parking: ['parking', 'park'], email: ['email', 'e mail'], website: ['website'], wifi: ['wifi', 'wi fi'], wheelchair: ['wheelchair', 'lift', 'elevator', 'accessible', 'ramp'], ambulance: ['ambulance'] })
        .find(([, kws]) => anyPhrase(stripped, kws));
      if (askedField) { unsupported.push(askedField[0]); handled = true; }
    }

    // 3j. nothing recognised → needs human (never guess)
    if (!handled) {
      const cw = contentWords(stripped);
      if (cw.length > 0 || clauses.length === 1) {
        intents.add('unsupported');
        if (!unsupported.includes('your question')) unsupported.push('your question');
      }
    }
    applyFaq();
  }

  // de-duplicate generic "your question" when we know specific topics
  if (unsupported.length > 1) {
    const i = unsupported.indexOf('your question');
    if (i >= 0) { unsupported.splice(i, 1); unsupported.push('the rest of your message'); }
  }

  if (!parts.length && !unsupported.length) {
    const hit = matchFaq(idx, question);
    if (hit) { intents.add('faq'); add({ kind: 'faq', key: `faq-${hit.from || hit.q}`, text: hit.a }); }
    else unsupported.push('your question');
  }
  return finish();
}

/** clinic hours on a doctor's listed days, grouped by identical hours text */
function doctorHourGroups(idx: KnowledgeIndex, d: DoctorEntry, t: Templates): string[] {
  const groups = new Map<string, number[]>();
  for (const day of d.days) {
    const h = [...idx.hours].reverse().find((x) => x.kind === 'days' && x.days.includes(day));
    if (!h) continue;
    groups.set(h.text, [...(groups.get(h.text) || []), day]);
  }
  const entries = [...groups.entries()];
  const out = entries.length === 1 ? [entries[0][0]] : entries.map(([text, days]) => `${days.map((x) => t.day(x)).join(', ')}: ${text}`);
  const br = idx.hours.find((x) => x.kind === 'break');
  if (br && out.length) out.push(t.hoursLine(t.hoursLabel(br.key, br.label), br.text).replace(/\.$/, ''));
  return out;
}

function prettyName(n: string): string {
  return n.split(' ').map((w) => (/^(hdfc|icici|sbi|aig|tpa|esi|esic|cghs|echs|qbe|pmjay|iffco)$/.test(w) ? w.toUpperCase() : w.charAt(0).toUpperCase() + w.slice(1))).join(' ');
}

function policyText(idx: KnowledgeIndex, frag: string): string | undefined {
  return idx.policies.find((p) => normalize(p.key).includes(frag))?.value;
}

function hoursAnswer(idx: KnowledgeIndex, qDays: number[], holiday: boolean, lunch: boolean, t: Templates): string {
  const lines: string[] = [];
  const breaks = idx.hours.filter((h) => h.kind === 'break');
  const holidays = idx.hours.filter((h) => h.kind === 'holiday');
  if (qDays.length) {
    for (const d of qDays) {
      const h = idx.hours.find((x) => x.kind === 'days' && x.days.includes(d));
      if (h) lines.push(t.hoursForDay(t.day(d), h.text));
      else lines.push(t.dayNotListed(t.day(d)));
    }
    const normalDay = qDays.some((d) => { const h = idx.hours.find((x) => x.kind === 'days' && x.days.includes(d)); return h && !/emergenc|closed/i.test(h.text); });
    if (normalDay) for (const b of breaks) lines.push(t.hoursLine(t.hoursLabel(b.key, b.label), b.text));
    if (holiday) for (const h of holidays) lines.push(t.hoursLine(t.hoursLabel(h.key, h.label), h.text));
    return lines.join(' ');
  }
  if (holiday && holidays.length && !lunch) return holidays.map((h) => t.hoursLine(t.hoursLabel(h.key, h.label), h.text)).join(' ');
  if (lunch && breaks.length && !holiday) return breaks.map((h) => t.hoursLine(t.hoursLabel(h.key, h.label), h.text)).join(' ');
  return t.hoursAll(idx.hours.map((h) => `${t.hoursLabel(h.key, h.label)}: ${h.text}`));
}
