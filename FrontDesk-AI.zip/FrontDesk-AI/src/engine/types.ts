// FrontDesk AI — shared types for the deterministic clinic knowledge engine.
// Used by the patient UI now and by Netlify Functions from Stage 2 onward.

export type TicketStatus = 'answered' | 'needs human' | 'urgent' | 'closed';
export type Priority = 'critical' | 'high' | 'normal' | 'low';
export type Lang = 'en' | 'hi' | 'te';

export interface Doctor {
  name: string;
  role?: string;
  days?: string | string[];
  [k: string]: unknown;
}

export interface Service {
  name: string;
  price?: string | number;
  note?: string;
  duration?: string;
  [k: string]: unknown;
}

export interface FaqEntry { q: string; a: string; from?: string; addedAt?: string; addedBy?: string }

export interface ClinicData {
  note?: string;
  clinic: {
    name: string;
    address?: string;
    landmark?: string;
    phone?: string;
    emergency_phone?: string;
    whatsapp?: string;
    languages?: string[] | string;
    parking?: string;
    [k: string]: unknown;
  };
  hours?: Record<string, string> | Array<Record<string, unknown>>;
  doctors?: Doctor[];
  services?: Service[];
  policies?: Record<string, string>;
  emergency_rules?: string;
  bot_rules?: string[];
  faq?: FaqEntry[];
  holidays?: Array<{ date: string; name?: string }>;
  [k: string]: unknown;
}

export type TicketType = 'enquiry' | 'unsupported' | 'emergency' | 'booking' | 'human';

export type PartKind =
  | 'faq'
  | 'human'
  | 'open-now'
  | 'emergency'
  | 'refusal'
  | 'medical'
  | 'hours'
  | 'doctor'
  | 'service'
  | 'price-list'
  | 'insurance'
  | 'policy'
  | 'contact'
  | 'location'
  | 'clinic-info'
  | 'booking'
  | 'unsupported'
  | 'greeting'
  | 'thanks';

export interface AnswerPart {
  kind: PartKind;
  key: string; // used for de-duplication
  text: string;
}

export type BookingState = 'requested' | 'awaiting confirmation' | 'confirmed' | 'rejected';
export type BookingField = 'date' | 'time' | 'name' | 'phone' | 'treatment';

export interface SlotIssue {
  code: 'holiday' | 'closed' | 'not-listed' | 'outside' | 'lunch' | 'doctor-day' | 'past-date' | 'past-time';
  day?: number; holiday?: string; text?: string; time?: string; doctor?: string; doctorDays?: string;
}
export interface TimeWindow { part: 'morning' | 'afternoon' | 'evening'; from: string; to: string }

export interface BookingDetails {
  dateText?: string; // as the patient said it ("Saturday", "21 Nov")
  timeText?: string; // as the patient said it ("11am", "evening")
  requestedDate?: string; // resolved YYYY-MM-DD (Asia/Kolkata)
  requestedTime?: string; // resolved HH:MM 24h
  requestedWindow?: TimeWindow; // "evening" → 16:00–20:00
  issues?: SlotIssue[]; // structured conflicts (rendered in the patient's language)
  outsideHours?: boolean; // closed day / holiday / outside listed hours / in the past
  doctor?: string; // preferred dentist, only if the patient named one
  service?: string; // requested treatment
  patientName?: string;
  phone?: string;
  notes?: string[]; // additional information from the patient
  warnings?: string[]; // conflicts with LISTED hours / holidays / doctor days (from clinic data)
  missing?: BookingField[];
  dateIssue?: 'vague' | 'past';
  timeIssue?: 'vague';
  state?: BookingState;
  needsClarification: boolean; // true while the day or exact time is missing
  // set only by an authorised staff member
  confirmedDate?: string;
  confirmedTime?: string;
  decidedBy?: string;
  decidedAt?: string;
  decisionNote?: string;
}

export interface EngineContext {
  /** what the bot last offered, e.g. after a symptom reply it offers booking */
  lastOffer?: 'booking';
  /** an open booking request in this conversation still missing details */
  pendingBooking?: BookingDetails;
  /** contact details already known for this conversation */
  knownContact?: ContactDetails;
  /** the conversation has an open (not closed) ticket that a follow-up can join */
  hasOpenTicket?: boolean;
  /** injectable clock for tests; defaults to now */
  now?: Date;
  knowledgeVersion?: number;
}

export interface ContactDetails { name?: string; phone?: string }
export type FollowUp = 'booking-update' | 'booking-start' | 'contact' | 'smalltalk';

export interface EngineResult {
  reply: string;
  parts: AnswerPart[];
  status: Exclude<TicketStatus, 'closed'>;
  priority: Priority;
  ticketRequired: boolean;
  ticketType: TicketType;
  intents: string[];
  unsupportedTopics: string[];
  lang: Lang;
  source: 'clinic-file' | 'staff-faq' | 'ai';
  /** Stage 6: file sections the model cited (only when source = 'ai') */
  aiSources?: string[];
  /** true when at least one part is a verbatim Staff FAQ answer */
  faqUsed?: boolean;
  /** true when the reply mixes clinic-file facts and a Staff FAQ answer */
  faqMixed?: boolean;
  emergency: boolean;
  offer?: 'booking';
  booking?: BookingDetails;
  knowledgeVersion?: number;
  /** set when the message continues the previous enquiry rather than starting a new one */
  followUp?: FollowUp;
  /** name / phone found in this message */
  contact?: ContactDetails;
}
