// Clinic-time helpers. India Standard Time has no DST, so IST = UTC+05:30 exactly.
export const IST_OFFSET_MIN = 330;
const DAY_MS = 86400000;
const MONTHS = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec'];
const WEEKDAYS = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];

/** YYYY-MM-DD of the IST calendar day containing `d`. */
export function istDate(d: Date): string { return new Date(d.getTime() + IST_OFFSET_MIN * 60000).toISOString().slice(0, 10); }
/** minutes since IST midnight */
export function istMinutes(d: Date): number { const x = new Date(d.getTime() + IST_OFFSET_MIN * 60000); return x.getUTCHours() * 60 + x.getUTCMinutes(); }
export function weekdayOf(ymd: string): number { return new Date(`${ymd}T00:00:00Z`).getUTCDay(); }
export function addDays(ymd: string, n: number): string { return new Date(Date.parse(`${ymd}T00:00:00Z`) + n * DAY_MS).toISOString().slice(0, 10); }
/** UTC instant for an IST wall-clock time on a date */
export function istToDate(ymd: string, minutes: number): Date { return new Date(Date.parse(`${ymd}T00:00:00Z`) + (minutes - IST_OFFSET_MIN) * 60000); }

export function formatYmd(ymd: string): string {
  const d = new Date(`${ymd}T00:00:00Z`);
  return d.toLocaleDateString('en-IN', { timeZone: 'UTC', weekday: 'long', day: 'numeric', month: 'short', year: 'numeric' });
}
export function formatHm(hm: string): string {
  const [h, m] = hm.split(':').map(Number);
  const ap = h >= 12 ? 'pm' : 'am';
  return `${((h + 11) % 12) + 1}:${String(m).padStart(2, '0')} ${ap}`;
}

/** Parse "9:00 am", "9 am", "13:30", "1.30pm" → minutes since midnight. */
export function parseClock(s: string): number | null {
  const m = s.trim().toLowerCase().match(/^(\d{1,2})(?:[:.](\d{2}))?\s*(am|pm|a\.m\.|p\.m\.)?$/);
  if (!m) return null;
  let h = Number(m[1]); const min = Number(m[2] || 0);
  const ap = m[3]?.replace(/\./g, '');
  if (min > 59 || h > 23) return null;
  if (ap) { if (h < 1 || h > 12) return null; if (ap === 'pm' && h !== 12) h += 12; if (ap === 'am' && h === 12) h = 0; }
  return h * 60 + min;
}
/** "9:00 am to 8:00 pm" → [540, 1200]; null if no range or the range is reversed. */
export function parseRange(text: string): [number, number] | null {
  const r = parseRangeLoose(text);
  return r && r[1] > r[0] ? r : null;
}
/** Same parse, but returns reversed ranges too (for validation messages). */
export function parseRangeLoose(text: string): [number, number] | null {
  const m = text.toLowerCase().match(/(\d{1,2}(?:[:.]\d{2})?\s*(?:am|pm)?)\s*(?:to|-|–|until|till)\s*(\d{1,2}(?:[:.]\d{2})?\s*(?:am|pm)?)/);
  if (!m) return null;
  let a = parseClock(m[1]); const b = parseClock(m[2]);
  if (a == null || b == null) return null;
  if (!/am|pm/.test(m[1]) && /pm/.test(m[2]) && a < 12 * 60 && a + 12 * 60 < b) a += 12 * 60; // "1:30 to 2:30 pm"
  return [a, b];
}

export interface ResolvedDate { ymd?: string; vague?: boolean; past?: boolean }
/** Resolve the patient's date phrase against "now" in IST. */
export function resolveDate(text: string | undefined, now: Date): ResolvedDate {
  if (!text) return {};
  const t = text.toLowerCase().trim();
  const today = istDate(now);
  if (/^(today|tonight)$/.test(t)) return { ymd: today };
  if (t === 'tomorrow') return { ymd: addDays(today, 1) };
  if (t === 'day after tomorrow') return { ymd: addDays(today, 2) };
  if (/^(this|next) (week|weekend)$|^weekend$/.test(t)) return { vague: true };
  const wd = t.match(/^(?:(this|next) )?(sunday|monday|tuesday|wednesday|thursday|friday|saturday)$/);
  if (wd) {
    const target = WEEKDAYS.indexOf(wd[2]);
    let delta = (target - weekdayOf(today) + 7) % 7;
    if (wd[1] === 'next' && delta === 0) delta = 7;
    return { ymd: addDays(today, delta) };
  }
  let day: number | undefined, mon: number | undefined, yr: number | undefined;
  let m = t.match(/^(\d{1,2})(?:st|nd|rd|th)?(?: of)? ([a-z]+)(?: (\d{4}))?$/);
  if (m && MONTHS.includes(m[2].slice(0, 3))) { day = +m[1]; mon = MONTHS.indexOf(m[2].slice(0, 3)); yr = m[3] ? +m[3] : undefined; }
  m = t.match(/^([a-z]+) (\d{1,2})(?:st|nd|rd|th)?(?:,? (\d{4}))?$/);
  if (m && MONTHS.includes(m[1].slice(0, 3))) { day = +m[2]; mon = MONTHS.indexOf(m[1].slice(0, 3)); yr = m[3] ? +m[3] : undefined; }
  m = t.match(/^(\d{1,2})[/-](\d{1,2})(?:[/-](\d{2,4}))?$/); // Indian DD/MM[/YYYY]
  if (m) { day = +m[1]; mon = +m[2] - 1; yr = m[3] ? (m[3].length === 2 ? 2000 + +m[3] : +m[3]) : undefined; }
  if (day === undefined || mon === undefined) return { vague: true };
  const y0 = Number(today.slice(0, 4));
  const mk = (y: number) => `${y}-${String(mon! + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
  let ymd = mk(yr ?? y0);
  const valid = (s: string) => new Date(`${s}T00:00:00Z`).toISOString().slice(0, 10) === s;
  if (mon < 0 || mon > 11 || day < 1 || day > 31) return { vague: true };
  if (!valid(ymd)) return { vague: true };
  if (yr === undefined && ymd < today) ymd = mk(y0 + 1);
  return { ymd, past: ymd < today };
}

/** "17:00" → "5:00 PM" */
export function clock12(hm: string): string {
  const [h, m] = hm.split(':').map(Number);
  return `${((h + 11) % 12) + 1}:${String(m).padStart(2, '0')} ${h >= 12 ? 'PM' : 'AM'}`;
}

export const DAY_PARTS = { morning: { from: '09:00', to: '12:00' }, afternoon: { from: '12:00', to: '16:00' }, evening: { from: '16:00', to: '20:00' } } as const;
export interface ResolvedTime { hm?: string; vague?: boolean; window?: { part: 'morning' | 'afternoon' | 'evening'; from: string; to: string } }
/**
 * "11am", "11:30 am", "17:00", "5 pm" → "HH:MM".
 * Bare hour ("at 5"): 1–7 → PM (clinic convention), 8–11 → AM, 12 → noon.
 * "morning" 09–12, "afternoon" 12–16, "evening" 16–20 → a window. "after work" → vague.
 */
export function resolveTime(text: string | undefined): ResolvedTime {
  if (!text) return {};
  const t = text.toLowerCase().trim();
  if (t === 'noon') return { hm: '12:00' };
  if (t === 'morning' || t === 'afternoon' || t === 'evening') return { window: { part: t, ...DAY_PARTS[t] } };
  if (/^(after work|after office)$/.test(t)) return { vague: true };
  if (/^\d{1,2}$/.test(t)) {
    const h = Number(t);
    if (h >= 1 && h <= 7) return { hm: `${String(h + 12).padStart(2, '0')}:00` };
    if (h >= 8 && h <= 11) return { hm: `${String(h).padStart(2, '0')}:00` };
    if (h === 12) return { hm: '12:00' };
    return { vague: true };
  }
  if (!/am|pm/.test(t) && !/:/.test(t)) return { vague: true };
  const m = parseClock(t.replace(/\s+/g, ' '));
  if (m == null) return { vague: true };
  return { hm: `${String(Math.floor(m / 60)).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}` };
}
