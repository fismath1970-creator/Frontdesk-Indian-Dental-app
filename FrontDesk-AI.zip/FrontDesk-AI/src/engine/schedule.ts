// Working-time calendar derived from the clinic data (any dataset with the supported schema).
// Used for the 2-working-hour callback target and for checking requested appointment times
// against the clinic's LISTED hours (never live availability).
import { DEFAULT_HOLIDAYS, type Holiday } from '../config/holidays.ts';
import { addDays, formatHm, istDate, istMinutes, istToDate, parseRange, weekdayOf } from './datetime.ts';
import type { KnowledgeIndex } from './knowledge.ts';
import { DAY_NAMES } from './lexicon.ts';
import type { ClinicData, SlotIssue } from './types.ts';

export interface DayRule { text: string; range: [number, number] | null; emergencyOnly: boolean; closed: boolean }

export interface ClinicCalendar {
  known: boolean; // false → no parseable hours; callbacks fall back to wall-clock time
  dayRule(weekday: number): DayRule | null;
  breaks: Array<[number, number]>;
  breakText?: string;
  holidays: Map<string, string>;
  holidayText?: string;
  /** front-desk working intervals for a date (minutes since IST midnight), holidays/breaks removed */
  workingIntervals(ymd: string): Array<[number, number]>;
}

function subtract(range: [number, number], cuts: Array<[number, number]>): Array<[number, number]> {
  let out: Array<[number, number]> = [range];
  for (const [a, b] of cuts) {
    out = out.flatMap(([x, y]) => (b <= x || a >= y ? [[x, y] as [number, number]] : [[x, Math.min(a, y)], [Math.max(b, x), y]].filter(([p, q]) => q > p) as Array<[number, number]>));
  }
  return out;
}

export function holidaysFrom(data: ClinicData): Holiday[] {
  const raw = (data as Record<string, unknown>).holidays;
  if (Array.isArray(raw)) {
    return raw.map((h) => (typeof h === 'string' ? { date: h, name: 'Public holiday' } : { date: String((h as Holiday).date), name: String((h as Holiday).name || 'Public holiday') }))
      .filter((h) => /^\d{4}-\d{2}-\d{2}$/.test(h.date));
  }
  return DEFAULT_HOLIDAYS;
}

export function buildCalendar(idx: KnowledgeIndex): ClinicCalendar {
  const dayEntries = idx.hours.filter((h) => h.kind === 'days');
  const rules = new Map<number, DayRule>();
  for (const h of dayEntries) {
    const rule: DayRule = { text: h.text, range: parseRange(h.text), emergencyOnly: /emergenc/i.test(h.text), closed: /^\s*closed/i.test(h.text) };
    for (const d of h.days) rules.set(d, rule);
  }
  const breakEntries = idx.hours.filter((h) => h.kind === 'break');
  const breaks = breakEntries.map((b) => parseRange(b.text)).filter((r): r is [number, number] => !!r);
  const holidayEntry = idx.hours.find((h) => h.kind === 'holiday');
  const holidays = new Map(holidaysFrom(idx.data).map((h) => [h.date, h.name]));
  const known = [...rules.values()].some((r) => r.range && !r.emergencyOnly && !r.closed);
  return {
    known,
    dayRule: (wd) => rules.get(wd) ?? null,
    breaks,
    breakText: breakEntries[0]?.text,
    holidays,
    holidayText: holidayEntry?.text,
    workingIntervals(ymd) {
      if (!known) return [[0, 1440]];
      if (holidays.has(ymd) && holidayEntry) return []; // clinic lists holiday closure
      const r = rules.get(weekdayOf(ymd));
      if (!r || !r.range || r.closed || r.emergencyOnly) return []; // emergency-only days are not callback time
      return subtract(r.range, breaks);
    },
  };
}

/** Working minutes between two instants. */
export function workingMinutesBetween(cal: ClinicCalendar, from: Date, to: Date): number {
  if (to <= from) return 0;
  let total = 0;
  let day = istDate(from);
  const last = istDate(to);
  for (let guard = 0; day <= last && guard < 400; guard++, day = addDays(day, 1)) {
    for (const [a, b] of cal.workingIntervals(day)) {
      const s = Math.max(istToDate(day, a).getTime(), from.getTime());
      const e = Math.min(istToDate(day, b).getTime(), to.getTime());
      if (e > s) total += (e - s) / 60000;
    }
  }
  return Math.floor(total);
}

/** The instant reached after `minutes` of working time from `from`. */
export function addWorkingMinutes(cal: ClinicCalendar, from: Date, minutes: number): Date {
  let left = minutes;
  let day = istDate(from);
  for (let guard = 0; guard < 400; guard++, day = addDays(day, 1)) {
    for (const [a, b] of cal.workingIntervals(day)) {
      const s = Math.max(istToDate(day, a).getTime(), from.getTime());
      const e = istToDate(day, b).getTime();
      if (e <= s) continue;
      const avail = (e - s) / 60000;
      if (avail >= left) return new Date(s + left * 60000);
      left -= avail;
    }
  }
  return new Date(from.getTime() + minutes * 60000);
}

/**
 * Check a requested slot against the clinic's LISTED hours / holidays / doctor days.
 * Structured issues (rendered later in the patient's language). Never states availability.
 */
export function slotIssues(idx: KnowledgeIndex, cal: ClinicCalendar, ymd: string | undefined, hm: string | undefined, doctorName?: string): SlotIssue[] {
  const out: SlotIssue[] = [];
  if (!ymd) return out;
  const wd = weekdayOf(ymd);
  if (cal.holidays.has(ymd) && cal.holidayText) out.push({ code: 'holiday', day: wd, holiday: cal.holidays.get(ymd), text: cal.holidayText });
  const r = cal.dayRule(wd);
  if (!r) { if (cal.known) out.push({ code: 'not-listed', day: wd }); }
  else if (r.closed || r.emergencyOnly) out.push({ code: 'closed', day: wd, text: r.text });
  else if (hm && r.range) {
    const [h, m] = hm.split(':').map(Number);
    const t = h * 60 + m;
    if (t < r.range[0] || t >= r.range[1]) out.push({ code: 'outside', day: wd, time: hm, text: r.text });
    else if (cal.breaks.some(([a, b]) => t >= a && t < b)) out.push({ code: 'lunch', day: wd, time: hm, text: cal.breakText });
  }
  if (doctorName) {
    const doc = idx.doctors.find((d) => d.doctor.name === doctorName);
    if (doc && doc.days.length && !doc.days.includes(wd)) out.push({ code: 'doctor-day', day: wd, doctor: doc.doctor.name, doctorDays: doc.daysText });
  }
  return out;
}
/** issues that put a request outside clinic hours (staff flag) */
export const OUTSIDE_CODES = new Set<SlotIssue['code']>(['holiday', 'closed', 'not-listed', 'outside', 'past-date', 'past-time']);

export const nowParts = (d: Date) => ({ ymd: istDate(d), minutes: istMinutes(d) });

export interface OpenStatus {
  state: 'open' | 'break' | 'emergency-only' | 'closed' | 'holiday' | 'unknown';
  label: string; // English
  until?: string; // HH:MM
  next?: { when: 'today' | 'tomorrow' | number; time: string };
  holiday?: string;
}
/** "Open now" badge — computed from the CURRENT clinic file's timings, lunch break and holidays. */
export function openStatus(cal: ClinicCalendar, now: Date): OpenStatus {
  if (!cal.known) return { state: 'unknown', label: 'Opening hours: ask us' };
  const ymd = istDate(now);
  const mins = istMinutes(now);
  const fmt = (m: number) => formatHm(`${String(Math.floor(m / 60)).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}`);
  const hm = (m: number) => `${String(Math.floor(m / 60)).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}`;
  const next = (): OpenStatus['next'] => {
    for (let i = 0; i < 14; i++) {
      const day = addDays(ymd, i);
      const iv = cal.workingIntervals(day).find(([a]) => i > 0 || a > mins);
      if (iv) return { when: i === 0 ? 'today' : i === 1 ? 'tomorrow' : weekdayOf(day), time: hm(iv[0]) };
    }
    return undefined;
  };
  const nextText = (n: OpenStatus['next']) => (n ? `${n.when === 'today' ? 'today' : n.when === 'tomorrow' ? 'tomorrow' : DAY_NAMES[n.when as number]} ${fmt(Number(n.time.slice(0, 2)) * 60 + Number(n.time.slice(3)))}` : 'soon');
  if (cal.holidays.has(ymd) && cal.holidayText) { const n = next(); return { state: 'holiday', holiday: cal.holidays.get(ymd), next: n, label: `Closed today (${cal.holidays.get(ymd)}) · opens ${nextText(n)}` }; }
  const rule = cal.dayRule(weekdayOf(ymd));
  if (rule?.range && mins >= rule.range[0] && mins < rule.range[1]) {
    if (rule.emergencyOnly) return { state: 'emergency-only', until: hm(rule.range[1]), label: `Emergencies only until ${fmt(rule.range[1])}` };
    const br = cal.breaks.find(([a, b]) => mins >= a && mins < b);
    if (br) return { state: 'break', until: hm(br[1]), label: `Lunch break · front desk back at ${fmt(br[1])}` };
    return { state: 'open', until: hm(rule.range[1]), label: `Open now · until ${fmt(rule.range[1])}` };
  }
  const n = next();
  return { state: 'closed', next: n, label: `Closed now · opens ${nextText(n)}` };
}
