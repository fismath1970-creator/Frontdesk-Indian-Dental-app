// FrontDesk AI — reply templates in English, Hindi (hi) and Telugu (te).
// Every FACT is a slot filled from the clinic file and stays VERBATIM: names, prices, times,
// phone numbers, notes, Latin digits. Templates only add connective wording.
//
// ┌──────────────────────────────────────────────────────────────────────────────────┐
// │ TRANSLATION REVIEW NEEDED: every Hindi (hi) and Telugu (te) string in this file    │
// │ was written by FrontDesk AI's developer, not a native speaker. Search for          │
// │ "@i18n-review" and have a native Hindi and Telugu speaker check each block.        │
// └──────────────────────────────────────────────────────────────────────────────────┘
import { clock12 } from './datetime.ts';
import type { BookingDetails, Lang, SlotIssue } from './types.ts';
import type { OpenStatus } from './schedule.ts';

const dot = (s: string) => (/[.!?।]$/.test(s.trim()) ? s.trim() : `${s.trim()}.`);
const dotHi = (s: string) => (/[.!?।]$/.test(s.trim()) ? s.trim() : `${s.trim()}।`);
const joinWith = (xs: string[], and: string) => (xs.length <= 1 ? xs.join('') : `${xs.slice(0, -1).join(', ')} ${and} ${xs[xs.length - 1]}`);

// ───────────────────────────── glossary ─────────────────────────────
// @i18n-review — weekdays
const WEEKDAYS: Record<Lang, string[]> = {
  en: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
  hi: ['रविवार', 'सोमवार', 'मंगलवार', 'बुधवार', 'गुरुवार', 'शुक्रवार', 'शनिवार'],
  te: ['ఆదివారం', 'సోమవారం', 'మంగళవారం', 'బుధవారం', 'గురువారం', 'శుక్రవారం', 'శనివారం'],
};
const WEEKDAYS_SHORT_EN = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

// @i18n-review — dental glossary (≈27 terms). `match` = lower-case fragments of an English service name.
export const DENTAL_GLOSSARY: Array<{ en: string; hi: string; te: string; match: string[] }> = [
  { en: 'Wisdom tooth removal', hi: 'अक़्ल दाढ़ निकालना', te: 'జ్ఞాన దంతం తీయడం', match: ['wisdom'] },
  { en: 'Root canal treatment', hi: 'रूट कैनाल उपचार', te: 'రూట్ కెనాల్ చికిత్స', match: ['root canal'] },
  { en: 'Consultation', hi: 'परामर्श', te: 'సంప్రదింపు (కన్సల్టేషన్)', match: ['consult'] },
  { en: 'Check-up', hi: 'जाँच (चेक-अप)', te: 'పరీక్ష (చెకప్)', match: ['check-up', 'checkup', 'check up'] },
  { en: 'Teeth cleaning (scaling)', hi: 'दांतों की सफाई (स्केलिंग)', te: 'పళ్ల శుభ్రత (స్కేలింగ్)', match: ['clean', 'scaling'] },
  { en: 'Filling', hi: 'फिलिंग (दांत भरना)', te: 'ఫిల్లింగ్ (పన్ను నింపడం)', match: ['filling'] },
  { en: 'Teeth whitening', hi: 'दांत सफेद करना (व्हाइटनिंग)', te: 'పళ్లు తెల్లబరచడం (వైటెనింగ్)', match: ['whiten'] },
  { en: 'Tooth extraction', hi: 'दांत निकालना', te: 'పన్ను తీయడం', match: ['extraction'] },
  { en: 'Braces', hi: 'ब्रेसेस', te: 'బ్రేసెస్', match: ['brace'] },
  { en: 'Aligners', hi: 'अलाइनर', te: 'అలైనర్లు', match: ['aligner', 'invisalign'] },
  { en: 'Dental implant', hi: 'डेंटल इम्प्लांट', te: 'డెంటల్ ఇంప్లాంట్', match: ['implant'] },
  { en: 'Crown', hi: 'क्राउन (कैप)', te: 'క్రౌన్ (క్యాప్)', match: ['crown'] },
  { en: 'Bridge', hi: 'ब्रिज', te: 'బ్రిడ్జ్', match: ['bridge'] },
  { en: 'Dentures', hi: 'डेन्चर (नकली दांत)', te: 'కట్టుడు పళ్లు', match: ['denture'] },
  { en: 'Veneers', hi: 'विनियर', te: 'వెనీర్లు', match: ['veneer'] },
  { en: 'X-ray', hi: 'एक्स-रे', te: 'ఎక్స్-రే', match: ['x-ray', 'xray'] },
  { en: 'Gum treatment', hi: 'मसूड़ों का इलाज', te: 'చిగుళ్ల చికిత్స', match: ['gum', 'periodont'] },
  { en: 'Dentist', hi: 'दंत चिकित्सक', te: 'దంత వైద్యుడు', match: [] },
  { en: 'Orthodontist', hi: 'ऑर्थोडॉन्टिस्ट (दांत सीधे करने वाले विशेषज्ञ)', te: 'ఆర్థోడాంటిస్ట్', match: [] },
  { en: "Children's dentist", hi: 'बच्चों के दंत चिकित्सक', te: 'పిల్లల దంత వైద్యుడు', match: [] },
  { en: 'Tooth', hi: 'दांत', te: 'పన్ను', match: [] },
  { en: 'Toothache', hi: 'दांत दर्द', te: 'పంటి నొప్పి', match: [] },
  { en: 'Cavity', hi: 'कैविटी (सड़न)', te: 'కావిటీ (పుచ్చు)', match: [] },
  { en: 'Sensitivity', hi: 'दांतों में झनझनाहट', te: 'పంటి సున్నితత్వం', match: [] },
  { en: 'Emergency', hi: 'आपातकाल', te: 'అత్యవసరం', match: [] },
  { en: 'Appointment', hi: 'अपॉइंटमेंट', te: 'అపాయింట్‌మెంట్', match: [] },
  { en: 'Insurance', hi: 'बीमा', te: 'బీమా', match: [] },
];
/** Service name for a reply: glossary term + the file's exact English name; English only if no entry. */
export function serviceName(name: string, lang: Lang): string {
  if (lang === 'en') return name;
  const low = name.toLowerCase();
  const g = DENTAL_GLOSSARY.find((e) => e.match.some((m) => low.includes(m)));
  return g ? `${g[lang]} (${name})` : name;
}

// @i18n-review — day-part names
const PARTS: Record<Lang, Record<string, string>> = {
  en: { morning: 'morning', afternoon: 'afternoon', evening: 'evening' },
  hi: { morning: 'सुबह', afternoon: 'दोपहर', evening: 'शाम' },
  te: { morning: 'ఉదయం', afternoon: 'మధ్యాహ్నం', evening: 'సాయంత్రం' },
};

/** "Sat 21 Nov" / "शनिवार 21 Nov" / "శనివారం 21 Nov" (Latin digits always) */
export function shortDate(ymd: string, lang: Lang = 'en'): string {
  const d = new Date(`${ymd}T00:00:00Z`);
  const mon = d.toLocaleDateString('en-GB', { timeZone: 'UTC', month: 'short' });
  const wd = lang === 'en' ? WEEKDAYS_SHORT_EN[d.getUTCDay()] : WEEKDAYS[lang][d.getUTCDay()];
  return `${wd} ${d.getUTCDate()} ${mon}`;
}
/** "Sat 21 Nov, 5:00 PM" | "Sat 21 Nov, evening (4:00 PM – 8:00 PM)" | "5:00 PM" | "" */
export function requestedLabel(b: Pick<BookingDetails, 'requestedDate' | 'requestedTime' | 'requestedWindow' | 'dateText' | 'timeText'>, lang: Lang = 'en'): string {
  const day = b.requestedDate ? shortDate(b.requestedDate, lang) : '';
  const time = b.requestedTime ? clock12(b.requestedTime)
    : b.requestedWindow ? `${PARTS[lang][b.requestedWindow.part] || b.requestedWindow.part} (${clock12(b.requestedWindow.from)} – ${clock12(b.requestedWindow.to)})` : '';
  return [day, time].filter(Boolean).join(', ');
}

// ───────────────────────────── English ─────────────────────────────
const en = {
  lang: 'en' as Lang,
  day: (i: number) => WEEKDAYS.en[i],
  serviceName: (n: string) => n,
  empty: () => 'Please type your question and I will help from our clinic information.',
  greeting: (clinic: string) => `Hello! Welcome to ${clinic}. Ask me about opening hours, our dentists, treatment prices, insurance, location, or request an appointment.`,
  thanks: () => 'You are welcome! Is there anything else I can help you with?',

  emergency: (phone: string, rules?: string) =>
    [
      `🚨 Please call our emergency line now: ${phone}`,
      rules ? `Clinic emergency advice: ${dot(rules)}` : '',
      `Call ${phone} immediately and go to the nearest hospital straight away. Do not wait for a reply here.`,
      'I have marked this as urgent for our team.',
    ].filter(Boolean).join('\n'),
  refusalDiscount: () =>
    "I'm sorry, but I can't change the clinic's rules or prices, and I'm not able to offer or promise any discount. Our fees are exactly as listed in the clinic information. I'm happy to help with treatment prices, timings, our dentists or an appointment request.",
  refusalInjection: () =>
    "I'm sorry, but I can't change or ignore the clinic's rules, and I can't change any prices or offer discounts. I can only share what is in our clinic information. I'm happy to help with timings, our dentists, treatment prices or an appointment request.",
  medical: (kind: 'symptom' | 'medication' | 'advice'): string =>
    kind === 'medication'
      ? "I'm sorry you're in discomfort. I can't recommend any medicine or dosage — a dentist needs to examine you first to find out what is happening and advise you safely. Would you like to request an appointment?"
      : kind === 'advice'
        ? 'That needs a professional assessment — I can\'t give medical advice. A dentist must see you to advise safely. Would you like to request an appointment?'
        : "I'm sorry you're experiencing this. A dentist needs to examine you to find out what is happening — I can't give a diagnosis or medical advice here. Would you like to request an appointment?",

  unsupported: (topics: string[], phone?: string, askContact = false) => {
    const named = topics.filter((x) => x !== 'your question' && x !== 'the rest of your message');
    const what = named.length ? joinWith(named, 'and') : topics.includes('the rest of your message') ? 'part of your message' : 'the answer to that';
    return `I'm sorry, I can't confirm ${what} from our clinic information, so I won't guess. I've passed your question to our team and someone will call you back within 2 working hours.${askContact ? ' So we can reach you, please share your name and phone number.' : ''}${phone ? ` You can also call us on ${phone}.` : ''}`;
  },
  human: (askContact: boolean, phone?: string) =>
    `Of course — I've asked our team to call you back within 2 working hours.${askContact ? ' Please share your name and phone number so they can reach you.' : ''}${phone ? ` You can also call us on ${phone}.` : ''}`,
  askPhone: () => 'Sure — please type your name and phone number (for example: Ravi Kumar, 98765 43210) and I will add them to your request.',
  relatedDoctor: (term: string, doctor: string, role: string) => `Our clinic information lists ${doctor}${role ? ` (${role})` : ''}, but it does not confirm ${term} specifically.`,
  relatedService: (term: string, service: string) => `Our clinic information lists ${service}, but it does not confirm ${term} specifically.`,
  relatedNote: (term: string, note: string) => `Our clinic information only mentions: "${dot(note)}" It does not list ${term} as a separate service or price.`,

  hoursLabel: (_key: string, label: string) => label,
  hoursLine: (label: string, text: string) => `${label}: ${dot(text)}`,
  hoursForDay: (day: string, text: string) => (/^\d/.test(text.trim()) ? `On ${day} we're open ${dot(text)}` : `${day}: ${dot(text)}`),
  hoursAll: (lines: string[]) => `Our opening hours:\n${lines.map((l) => `• ${dot(l)}`).join('\n')}`,
  dayNotListed: (day: string) => `Our clinic information does not list opening hours for ${day}.`,
  openNow: (s: OpenStatus) => s.label,

  doctorLine: (name: string, role: string, days: string) => `${name}${role ? ` — ${role}` : ''}${days ? `. Available: ${days}` : ''}.`,
  doctorHours: (doc: string, days: string, groups: string[]) => `${doc} is at the clinic on: ${dot(days)}${groups.length ? ` Clinic hours on those days: ${groups.join('; ')}.` : ''}`,
  discountNoted: () => "I've passed your message to our team, and someone will call you back within 2 working hours.",
  doctorOnDay: (doc: string, days: string, all: string) => `${doc}'s listed days include ${days} (schedule: ${all}). I can't see live appointment times — staff will confirm an exact time if you send a request.`,
  doctorNotOnDay: (doc: string, days: string, all: string) => `${doc} is not listed for ${days}. ${doc}'s days are: ${dot(all)}`,
  doctorList: (lines: string[]) => `Our dentists:\n${lines.map((l) => `• ${l}`).join('\n')}`,

  serviceLine: (name: string, price: string, extra: string) => `${name}: ${price || 'price not listed in our clinic file'}${extra ? ` (${extra})` : ''}.`,
  takesAbout: (d: string) => `takes about ${d}`,
  priceList: (lines: string[]) => `Our treatment prices:\n${lines.map((l) => `• ${l}`).join('\n')}`,

  insuranceYes: (provider: string, text: string) => `Yes — ${provider} is accepted on a cashless basis. Clinic policy: ${dot(text)}`,
  insuranceOther: (name: string, providers: string[], other: string) => `${name} is not on our cashless list${providers.length ? ` (cashless is available with ${joinWith(providers, 'and')})` : ''}. ${dot(other)}`,
  insuranceGeneral: (providers: string[], text: string) => (providers.length ? `We offer cashless treatment with ${joinWith(providers, 'and')}. Clinic policy: ${dot(text)}` : `Insurance: ${dot(text)}`),
  policy: (_label: string, value: string) => value,

  field: (key: string, label: string, value: string) => {
    switch (key) {
      case 'address': return `We're at ${dot(value)}`;
      case 'landmark': return `Landmark: ${dot(value)}`;
      case 'phone': return `Main phone: ${value}`;
      case 'whatsapp': return `WhatsApp: ${value}`;
      case 'emergency_phone': return `Emergency line: ${value}`;
      case 'languages': return `Our team speaks ${dot(value)}`;
      case 'parking': return `Parking: ${dot(value)}`;
      default: return `${label}: ${dot(value)}`;
    }
  },
  clinicName: (name: string) => `You're chatting with the front desk of ${name}.`,

  contactThanks: (name: string | undefined, joined: boolean) => joined
    ? `Thank you${name ? `, ${name}` : ''}. I've added your contact details to your request — our team will call you back within 2 working hours.`
    : `Thank you${name ? `, ${name}` : ''} — I've passed your details to our team and someone will call you back within 2 working hours. You can also tell me what you need help with.`,

  slotIssue: (i: SlotIssue, day: (n: number) => string = (n) => WEEKDAYS.en[n]) => {
    const dn = i.day !== undefined ? day(i.day) : '';
    switch (i.code) {
      case 'holiday': return `${dn} is a public holiday (${i.holiday}). Our clinic information says: ${i.text || 'closed'}.`;
      case 'closed': return `${dn}: ${dot(i.text || 'Closed')}`;
      case 'not-listed': return `Our clinic information does not list opening hours for ${dn}.`;
      case 'outside': return `${clock12(i.time!)} is outside our listed hours for ${dn} (${i.text}).`;
      case 'lunch': return `${clock12(i.time!)} falls in the lunch break (${i.text}).`;
      case 'doctor-day': return `${i.doctor} is not listed for ${dn}. ${i.doctor}'s days are: ${dot(i.doctorDays || '')}`;
      case 'past-date': return 'That date has already passed — what day suits you instead?';
      case 'past-time': return 'That time has already passed today — what time suits you instead?';
      default: return '';
    }
  },
  bookingReply: (b: BookingDetails, o: { updated: boolean; noteAdded?: boolean; policy?: string }) => {
    const when = requestedLabel(b, 'en');
    const what = [when ? ` for ${when}` : '', b.doctor ? ` with ${b.doctor}` : '', b.service ? ` (${b.service})` : ''].join('');
    const m = b.missing || [];
    const needDay = m.includes('date') && b.dateIssue !== 'past';
    const needTime = m.includes('time');
    return [
      `${o.noteAdded ? "Thank you — I've added that to your request" : o.updated ? "Thank you — I've updated your request" : "I've noted your request"}${what}.`,
      'This is a request, not a confirmed booking. Our team will call you within 2 working hours to confirm.',
      ...(b.issues || []).map((i) => en.slotIssue(i)),
      b.dateIssue === 'vague' ? 'Which exact day would you like (for example, Saturday or 21 Nov)?' : '',
      b.timeIssue === 'vague' ? 'What exact time would suit you (for example, 11:00 AM)?' : '',
      needDay && needTime ? 'What day and time suits you?' : needDay ? 'What day suits you?' : needTime ? 'What time suits you?' : '',
      m.includes('treatment') && !o.noteAdded ? 'Which treatment is it for?' : '',
      m.includes('name') && m.includes('phone') ? 'Please share your name and phone number.' : m.includes('name') ? 'Please share your name.' : m.includes('phone') ? 'Please share your phone number.' : '',
      b.state === 'awaiting confirmation' ? 'Status: awaiting staff confirmation.' : 'Status: appointment requested.',
      o.policy ? `Appointment policy: ${dot(o.policy)}` : '',
    ].filter(Boolean).join('\n');
  },
  noLiveSlots: () => "I can't see live appointment slots or a dentist's free times, so I won't guess. I can send an appointment request and our staff will confirm availability with you.",
  bookingAsk: (policy?: string) => `Of course. What day and time suits you, and which treatment or dentist is it for? Please also share your name and phone number. This is a request, not a confirmed booking — our team will call you within 2 working hours to confirm.${policy ? `\nAppointment policy: ${dot(policy)}` : ''}`,
  bookingDecision: (d: { decision: 'confirm' | 'reject'; date?: string; time?: string; doctor?: string; service?: string; note?: string; policy?: string; requested?: string }) => d.decision === 'confirm'
    ? [`✅ Your appointment is confirmed by our staff: ${[d.date ? longDate(d.date) : '', d.time ? `at ${clock12(d.time).toLowerCase()}` : ''].filter(Boolean).join(' ')}${d.doctor ? ` with ${d.doctor}` : ''}${d.service ? ` for ${d.service}` : ''}.`, d.note || '', d.policy ? `If you need to cancel or move it: ${dot(d.policy)}` : ''].filter(Boolean).join('\n')
    : [`We're sorry — we can't confirm your requested time${d.requested ? ` (${d.requested})` : ''}.`, d.note || '', 'Please reply here with another day and time that suits you, and our team will check again.'].filter(Boolean).join('\n'),
};
function longDate(ymd: string) { return new Date(`${ymd}T00:00:00Z`).toLocaleDateString('en-IN', { timeZone: 'UTC', weekday: 'long', day: 'numeric', month: 'short', year: 'numeric' }); }

export type Templates = typeof en;

// Generic English topic phrases → translations (named topics such as "Invisalign" stay verbatim).
// @i18n-review
const TOPICS: Record<'hi' | 'te', Array<[RegExp, (m: RegExpMatchArray) => string]>> = {
  hi: [
    [/^the rest of your message$/, () => 'आपके संदेश का कुछ हिस्सा'], [/^that price$/, () => 'वह कीमत'],
    [/^live appointment availability$/, () => 'अपॉइंटमेंट की लाइव उपलब्धता'], [/^opening hours$/, () => 'खुलने का समय'],
    [/^an orthodontist$/, () => 'ऑर्थोडॉन्टिस्ट'], [/^an endodontist.*$/, () => 'रूट कैनाल विशेषज्ञ (एंडोडॉन्टिस्ट)'],
    [/^a children's dentist$/, () => 'बच्चों के दंत चिकित्सक'], [/^which dentist (?:provides|handles) (.+)$/, (m) => `"${m[1]}" कौन से दंत चिकित्सक करते हैं`],
    [/^insurance with (.+)$/, (m) => `${m[1]} बीमा`], [/^insurance$/, () => 'बीमा'], [/^parking$/, () => 'पार्किंग'],
  ],
  te: [
    [/^the rest of your message$/, () => 'మీ సందేశంలోని కొంత భాగం'], [/^that price$/, () => 'ఆ ధర'],
    [/^live appointment availability$/, () => 'అపాయింట్‌మెంట్ల ప్రత్యక్ష లభ్యత'], [/^opening hours$/, () => 'తెరిచే సమయాలు'],
    [/^an orthodontist$/, () => 'ఆర్థోడాంటిస్ట్'], [/^an endodontist.*$/, () => 'రూట్ కెనాల్ నిపుణులు (ఎండోడాంటిస్ట్)'],
    [/^a children's dentist$/, () => 'పిల్లల దంత వైద్యుడు'], [/^which dentist (?:provides|handles) (.+)$/, (m) => `"${m[1]}" ఏ దంత వైద్యుడు చేస్తారో`],
    [/^insurance with (.+)$/, (m) => `${m[1]} బీమా`], [/^insurance$/, () => 'బీమా'], [/^parking$/, () => 'పార్కింగ్'],
  ],
};
const topic = (lang: 'hi' | 'te', x: string) => { for (const [re, f] of TOPICS[lang]) { const m = x.match(re); if (m) return f(m); } return x; };
const HOURS_LABEL_RE = /^(sunday|monday|tuesday|wednesday|thursday|friday|saturday)(?:_(?:to|through)_(sunday|monday|tuesday|wednesday|thursday|friday|saturday))?$/;
const WD_INDEX: Record<string, number> = { sunday: 0, monday: 1, tuesday: 2, wednesday: 3, thursday: 4, friday: 5, saturday: 6 };

// ───────────────────────────── Hindi ─────────────────────────────
// @i18n-review — ALL Hindi strings below
const hi: Templates = {
  ...en,
  lang: 'hi',
  day: (i) => WEEKDAYS.hi[i],
  serviceName: (n) => serviceName(n, 'hi'),
  empty: () => 'कृपया अपना प्रश्न लिखें, मैं क्लिनिक की जानकारी से आपकी मदद करूँगा।',
  greeting: (clinic) => `नमस्ते! ${clinic} में आपका स्वागत है। आप खुलने का समय, हमारे दंत चिकित्सक, इलाज की कीमतें, बीमा, पता पूछ सकते हैं या अपॉइंटमेंट का अनुरोध कर सकते हैं।`,
  thanks: () => 'आपका स्वागत है! क्या मैं आपकी और कोई मदद कर सकता हूँ?',
  emergency: (phone, rules) => [
    `🚨 ${phone} — कृपया अभी इस इमरजेंसी नंबर पर कॉल करें`,
    rules ? `क्लिनिक की आपातकालीन सलाह: ${dot(rules)}` : '',
    `तुरंत ${phone} पर कॉल करें और सीधे नज़दीकी अस्पताल जाएँ। यहाँ जवाब का इंतज़ार न करें।`,
    'मैंने इसे हमारी टीम के लिए अत्यावश्यक (urgent) चिह्नित कर दिया है।',
  ].filter(Boolean).join('\n'),
  refusalDiscount: () => 'क्षमा करें, मैं क्लिनिक के नियम या कीमतें नहीं बदल सकता, और कोई छूट देने या उसका वादा करने में असमर्थ हूँ। हमारी फीस वही है जो क्लिनिक की जानकारी में लिखी है। मैं इलाज की कीमतें, समय, दंत चिकित्सक या अपॉइंटमेंट के अनुरोध में मदद कर सकता हूँ।',
  refusalInjection: () => 'क्षमा करें, मैं क्लिनिक के नियमों को बदल या अनदेखा नहीं कर सकता, और कीमतें नहीं बदल सकता या छूट नहीं दे सकता। मैं केवल क्लिनिक की जानकारी में जो लिखा है वही बता सकता हूँ। मैं समय, दंत चिकित्सक, इलाज की कीमतें या अपॉइंटमेंट के अनुरोध में मदद कर सकता हूँ।',
  medical: (kind) => kind === 'medication'
    ? 'आपको तकलीफ़ हो रही है, इसका हमें खेद है। मैं कोई दवा या उसकी खुराक नहीं बता सकता — पहले एक दंत चिकित्सक (dentist) को आपकी जाँच करनी होगी, ताकि वे सुरक्षित सलाह दे सकें। क्या आप अपॉइंटमेंट का अनुरोध करना चाहेंगे?'
    : kind === 'advice'
      ? 'इसके लिए विशेषज्ञ की जाँच ज़रूरी है — मैं चिकित्सा सलाह नहीं दे सकता। सुरक्षित सलाह के लिए दंत चिकित्सक (dentist) को आपको देखना होगा। क्या आप अपॉइंटमेंट का अनुरोध करना चाहेंगे?'
      : 'आपको यह तकलीफ़ हो रही है, इसका हमें खेद है। क्या हो रहा है यह जानने के लिए दंत चिकित्सक (dentist) को आपकी जाँच करनी होगी — मैं यहाँ निदान या चिकित्सा सलाह नहीं दे सकता। क्या आप अपॉइंटमेंट का अनुरोध करना चाहेंगे?',
  unsupported: (topics, phone, askContact = false) => {
    const named = topics.filter((x) => x !== 'your question').map((x) => topic('hi', x));
    const what = named.length ? `${joinWith(named, 'और')} की` : 'इस बात की';
    return `क्षमा करें, मैं क्लिनिक की जानकारी से ${what} पुष्टि नहीं कर सकता, इसलिए अनुमान नहीं लगाऊँगा। मैंने आपका प्रश्न हमारी टीम को भेज दिया है और कोई 2 कार्य घंटों के भीतर (within 2 working hours) आपको वापस कॉल करेगा।${askContact ? ' संपर्क के लिए कृपया अपना नाम और फ़ोन नंबर बताएँ।' : ''}${phone ? ` आप हमें ${phone} पर भी कॉल कर सकते हैं।` : ''}`;
  },
  human: (askContact, phone) => `ज़रूर — मैंने हमारी टीम से कहा है कि वे 2 कार्य घंटों के भीतर (within 2 working hours) आपको वापस कॉल करें।${askContact ? ' कृपया अपना नाम और फ़ोन नंबर बताएँ ताकि वे आपसे संपर्क कर सकें।' : ''}${phone ? ` आप हमें ${phone} पर भी कॉल कर सकते हैं।` : ''}`,
  askPhone: () => 'ज़रूर — कृपया अपना नाम और फ़ोन नंबर लिखें (जैसे: Ravi Kumar, 98765 43210), मैं इसे आपके अनुरोध में जोड़ दूँगा।',
  relatedDoctor: (term, doctor, role) => `क्लिनिक की जानकारी में ${doctor}${role ? ` (${role})` : ''} का नाम है, लेकिन ${term} की विशेष रूप से पुष्टि नहीं है।`,
  relatedService: (term, service) => `क्लिनिक की जानकारी में ${service} है, लेकिन ${term} की विशेष रूप से पुष्टि नहीं है।`,
  relatedNote: (term, note) => `क्लिनिक की जानकारी में केवल यह लिखा है: "${dot(note)}" इसमें ${term} अलग सेवा या कीमत के रूप में नहीं है।`,
  hoursLabel: (key, label) => {
    const m = key.toLowerCase().match(HOURS_LABEL_RE);
    if (m) return m[2] ? `${WEEKDAYS.hi[WD_INDEX[m[1]]]} से ${WEEKDAYS.hi[WD_INDEX[m[2]]]}` : WEEKDAYS.hi[WD_INDEX[m[1]]];
    if (/lunch|break/i.test(key)) return 'दोपहर का भोजन अवकाश';
    if (/holiday/i.test(key)) return 'सार्वजनिक छुट्टियाँ';
    return label;
  },
  hoursLine: (label, text) => `${label}: ${dot(text)}`,
  hoursForDay: (day, text) => (/^\d/.test(text.trim()) ? `${day} को हम ${text.trim()} खुले रहते हैं।` : `${day}: ${dot(text)}`),
  hoursAll: (lines) => `हमारे खुलने का समय:\n${lines.map((l) => `• ${dot(l)}`).join('\n')}`,
  dayNotListed: (day) => `क्लिनिक की जानकारी में ${day} के लिए खुलने का समय नहीं दिया गया है।`,
  openNow: (s) => openNowText(s, 'hi'),
  doctorLine: (name, role, days) => `${name}${role ? ` — ${role}` : ''}${days ? `। उपलब्ध: ${days}` : ''}।`,
  doctorHours: (doc, days, groups) => `${doc} इन दिनों क्लिनिक में होते हैं: ${dot(days)}${groups.length ? ` उन दिनों क्लिनिक का समय: ${groups.join('; ')}।` : ''}`,
  discountNoted: () => 'मैंने आपका संदेश हमारी टीम को भेज दिया है, कोई 2 कार्य घंटों के भीतर (within 2 working hours) आपको वापस कॉल करेगा।',
  doctorOnDay: (doc, days, all) => `${doc} के तय दिनों में ${days} शामिल है (समय-सारणी: ${all})। मैं लाइव अपॉइंटमेंट समय नहीं देख सकता — अनुरोध भेजने पर स्टाफ सही समय की पुष्टि करेगा।`,
  doctorNotOnDay: (doc, days, all) => `${doc} ${days} को उपलब्ध नहीं बताए गए हैं। ${doc} के दिन: ${dot(all)}`,
  doctorList: (lines) => `हमारे दंत चिकित्सक:\n${lines.map((l) => `• ${l}`).join('\n')}`,
  serviceLine: (name, price, extra) => `${name}: ${price || 'कीमत क्लिनिक की जानकारी में नहीं दी गई है'}${extra ? ` (${extra})` : ''}।`,
  takesAbout: (d) => `लगभग ${d} लगते हैं`,
  priceList: (lines) => `हमारे इलाज की कीमतें:\n${lines.map((l) => `• ${l}`).join('\n')}`,
  insuranceYes: (provider, text) => `हाँ — ${provider} कैशलेस (cashless) आधार पर स्वीकार किया जाता है। क्लिनिक नीति: ${dot(text)}`,
  insuranceOther: (name, providers, other) => `${name} हमारी कैशलेस सूची में नहीं है${providers.length ? ` (कैशलेस सुविधा ${joinWith(providers, 'और')} के साथ है)` : ''}। ${dot(other)}`,
  insuranceGeneral: (providers, text) => (providers.length ? `हम ${joinWith(providers, 'और')} के साथ कैशलेस (cashless) इलाज देते हैं। क्लिनिक नीति: ${dot(text)}` : `बीमा: ${dot(text)}`),
  policy: (label, value) => `नीति (${label}): ${value}`,
  field: (key, label, value) => {
    switch (key) {
      case 'address': return `हमारा पता: ${dot(value)}`;
      case 'landmark': return `पहचान चिह्न: ${dot(value)}`;
      case 'phone': return `मुख्य फ़ोन: ${value}`;
      case 'whatsapp': return `व्हाट्सऐप: ${value}`;
      case 'emergency_phone': return `इमरजेंसी लाइन: ${value}`;
      case 'languages': return `हमारी टीम ये भाषाएँ बोलती है: ${dot(value)}`;
      case 'parking': return `पार्किंग: ${dot(value)}`;
      default: return `${label}: ${dot(value)}`;
    }
  },
  clinicName: (name) => `आप ${name} के फ्रंट डेस्क से बात कर रहे हैं।`,
  contactThanks: (name, joined) => joined
    ? `धन्यवाद${name ? `, ${name}` : ''}। मैंने आपके संपर्क विवरण आपके अनुरोध में जोड़ दिए हैं — हमारी टीम 2 कार्य घंटों के भीतर (within 2 working hours) आपको वापस कॉल करेगी।`
    : `धन्यवाद${name ? `, ${name}` : ''} — मैंने आपके विवरण हमारी टीम को भेज दिए हैं और कोई 2 कार्य घंटों के भीतर (within 2 working hours) आपको वापस कॉल करेगा। आप यह भी बता सकते हैं कि आपको किस बारे में मदद चाहिए।`,
  slotIssue: (i) => {
    const dn = i.day !== undefined ? WEEKDAYS.hi[i.day] : '';
    switch (i.code) {
      case 'holiday': return `${dn} को सार्वजनिक छुट्टी (${i.holiday}) है। क्लिनिक की जानकारी: ${i.text || 'Closed'}।`;
      case 'closed': return `${dn}: ${dot(i.text || 'Closed')} (नियमित अपॉइंटमेंट के लिए क्लिनिक का समय नहीं)`;
      case 'not-listed': return `क्लिनिक की जानकारी में ${dn} के लिए खुलने का समय नहीं दिया गया है।`;
      case 'outside': return `${clock12(i.time!)} ${dn} के तय समय (${i.text}) से बाहर है।`;
      case 'lunch': return `${clock12(i.time!)} दोपहर के भोजन अवकाश (${i.text}) में आता है।`;
      case 'doctor-day': return `${i.doctor} ${dn} को उपलब्ध नहीं बताए गए हैं। उनके दिन: ${dot(i.doctorDays || '')}`;
      case 'past-date': return 'यह तारीख निकल चुकी है — इसके बजाय कौन-सा दिन आपके लिए ठीक रहेगा?';
      case 'past-time': return 'आज यह समय निकल चुका है — इसके बजाय कौन-सा समय ठीक रहेगा?';
      default: return '';
    }
  },
  bookingReply: (b, o) => {
    const when = requestedLabel(b, 'hi');
    const what = [when, b.doctor ? `${b.doctor} के साथ` : '', b.service ? `(${serviceName(b.service, 'hi')})` : ''].filter(Boolean).join(', ');
    const m = b.missing || [];
    const needDay = m.includes('date') && b.dateIssue !== 'past';
    const needTime = m.includes('time');
    return [
      `${o.noteAdded ? 'धन्यवाद — मैंने यह जानकारी आपके अनुरोध में जोड़ दी है' : o.updated ? 'धन्यवाद — मैंने आपका अनुरोध अपडेट कर दिया है' : 'मैंने आपका अनुरोध नोट कर लिया है'}${what ? `: ${what}` : ''}।`,
      'यह केवल एक अनुरोध है, पक्की बुकिंग नहीं (not a confirmed booking)। पुष्टि के लिए हमारी टीम 2 कार्य घंटों के भीतर (within 2 working hours) आपको कॉल करेगी।',
      ...(b.issues || []).map((i) => hi.slotIssue(i)),
      b.dateIssue === 'vague' ? 'आप कौन-सा दिन चाहेंगे (जैसे: शनिवार या 21 Nov)?' : '',
      b.timeIssue === 'vague' ? 'कौन-सा सही समय ठीक रहेगा (जैसे: 11:00 AM)?' : '',
      needDay && needTime ? 'आपके लिए कौन-सा दिन और समय ठीक रहेगा?' : needDay ? 'आपके लिए कौन-सा दिन ठीक रहेगा?' : needTime ? 'आपके लिए कौन-सा समय ठीक रहेगा?' : '',
      m.includes('treatment') && !o.noteAdded ? 'यह किस इलाज के लिए है?' : '',
      m.includes('name') && m.includes('phone') ? 'कृपया अपना नाम और फ़ोन नंबर बताएँ।' : m.includes('name') ? 'कृपया अपना नाम बताएँ।' : m.includes('phone') ? 'कृपया अपना फ़ोन नंबर बताएँ।' : '',
      b.state === 'awaiting confirmation' ? 'स्थिति: स्टाफ की पुष्टि का इंतज़ार (awaiting staff confirmation)।' : 'स्थिति: अपॉइंटमेंट का अनुरोध (appointment requested)।',
      o.policy ? `अपॉइंटमेंट नीति: ${dot(o.policy)}` : '',
    ].filter(Boolean).join('\n');
  },
  noLiveSlots: () => 'मैं लाइव अपॉइंटमेंट स्लॉट या दंत चिकित्सक का खाली समय नहीं देख सकता, इसलिए अनुमान नहीं लगाऊँगा। मैं अपॉइंटमेंट का अनुरोध भेज सकता हूँ और स्टाफ आपसे उपलब्धता की पुष्टि करेगा।',
  bookingAsk: (policy) => `ज़रूर। आपके लिए कौन-सा दिन और समय ठीक रहेगा, और यह किस इलाज या किस दंत चिकित्सक के लिए है? कृपया अपना नाम और फ़ोन नंबर भी बताएँ। यह केवल एक अनुरोध है, पक्की बुकिंग नहीं — पुष्टि के लिए हमारी टीम 2 कार्य घंटों के भीतर (within 2 working hours) कॉल करेगी।${policy ? `\nअपॉइंटमेंट नीति: ${dot(policy)}` : ''}`,
  bookingDecision: (d) => d.decision === 'confirm'
    ? [`✅ हमारे स्टाफ ने आपका अपॉइंटमेंट पक्का कर दिया है (confirmed by our staff): ${[d.date ? shortDate(d.date, 'hi') : '', d.time ? clock12(d.time) : ''].filter(Boolean).join(', ')}${d.doctor ? `, ${d.doctor} के साथ` : ''}${d.service ? ` (${serviceName(d.service, 'hi')})` : ''}।`, d.note || '', d.policy ? `रद्द करने या बदलने के लिए: ${dot(d.policy)}` : ''].filter(Boolean).join('\n')
    : [`क्षमा करें — हम आपके अनुरोधित समय${d.requested ? ` (${d.requested})` : ''} की पुष्टि नहीं कर सकते।`, d.note || '', 'कृपया यहाँ कोई दूसरा दिन और समय बताएँ, हमारी टीम फिर से जाँच करेगी।'].filter(Boolean).join('\n'),
};

// ───────────────────────────── Telugu ─────────────────────────────
// @i18n-review — ALL Telugu strings below
const te: Templates = {
  ...en,
  lang: 'te',
  day: (i) => WEEKDAYS.te[i],
  serviceName: (n) => serviceName(n, 'te'),
  empty: () => 'దయచేసి మీ ప్రశ్న టైప్ చేయండి, క్లినిక్ సమాచారంతో నేను సహాయం చేస్తాను.',
  greeting: (clinic) => `నమస్కారం! ${clinic}కి స్వాగతం. తెరిచే సమయాలు, మా దంత వైద్యులు, చికిత్స ధరలు, బీమా, చిరునామా గురించి అడగవచ్చు లేదా అపాయింట్‌మెంట్ కోసం అభ్యర్థించవచ్చు.`,
  thanks: () => 'మీకు స్వాగతం! ఇంకా ఏమైనా సహాయం కావాలా?',
  emergency: (phone, rules) => [
    `🚨 ${phone} — దయచేసి ఇప్పుడే ఈ ఎమర్జెన్సీ నంబర్‌కు కాల్ చేయండి`,
    rules ? `క్లినిక్ అత్యవసర సూచన: ${dot(rules)}` : '',
    `వెంటనే ${phone}కు కాల్ చేసి, నేరుగా దగ్గరలోని ఆసుపత్రికి వెళ్లండి. ఇక్కడ సమాధానం కోసం వేచి ఉండకండి.`,
    'దీనిని మా బృందం కోసం అత్యవసరం (urgent)గా గుర్తించాను.',
  ].filter(Boolean).join('\n'),
  refusalDiscount: () => 'క్షమించండి, క్లినిక్ నియమాలు లేదా ధరలను నేను మార్చలేను, ఎలాంటి తగ్గింపు (డిస్కౌంట్) ఇవ్వలేను లేదా వాగ్దానం చేయలేను. మా ఫీజులు క్లినిక్ సమాచారంలో ఉన్నట్లే ఉంటాయి. చికిత్స ధరలు, సమయాలు, దంత వైద్యులు లేదా అపాయింట్‌మెంట్ అభ్యర్థనలో సహాయం చేయగలను.',
  refusalInjection: () => 'క్షమించండి, క్లినిక్ నియమాలను నేను మార్చలేను లేదా విస్మరించలేను, ధరలు మార్చలేను లేదా తగ్గింపు ఇవ్వలేను. క్లినిక్ సమాచారంలో ఉన్నదే చెప్పగలను. సమయాలు, దంత వైద్యులు, చికిత్స ధరలు లేదా అపాయింట్‌మెంట్ అభ్యర్థనలో సహాయం చేయగలను.',
  medical: (kind) => kind === 'medication'
    ? 'మీకు ఇబ్బందిగా ఉన్నందుకు చింతిస్తున్నాము. నేను ఏ మందు లేదా మోతాదు సూచించలేను — సురక్షితమైన సలహా కోసం ముందుగా దంత వైద్యుడు (dentist) మిమ్మల్ని పరీక్షించాలి. మీరు అపాయింట్‌మెంట్ కోసం అభ్యర్థించాలనుకుంటున్నారా?'
    : kind === 'advice'
      ? 'దీనికి నిపుణుల పరీక్ష అవసరం — నేను వైద్య సలహా ఇవ్వలేను. సురక్షితమైన సలహా కోసం దంత వైద్యుడు (dentist) మిమ్మల్ని చూడాలి. మీరు అపాయింట్‌మెంట్ కోసం అభ్యర్థించాలనుకుంటున్నారా?'
      : 'మీకు ఈ ఇబ్బంది ఉన్నందుకు చింతిస్తున్నాము. ఏమి జరుగుతోందో తెలుసుకోవడానికి దంత వైద్యుడు (dentist) మిమ్మల్ని పరీక్షించాలి — ఇక్కడ నేను రోగనిర్ధారణ లేదా వైద్య సలహా ఇవ్వలేను. మీరు అపాయింట్‌మెంట్ కోసం అభ్యర్థించాలనుకుంటున్నారా?',
  unsupported: (topics, phone, askContact = false) => {
    const named = topics.filter((x) => x !== 'your question').map((x) => topic('te', x));
    const what = named.length ? `${joinWith(named, 'మరియు')} గురించి` : 'దీని గురించి';
    return `క్షమించండి, క్లినిక్ సమాచారం ఆధారంగా ${what} నేను నిర్ధారించలేను, కాబట్టి ఊహించను. మీ ప్రశ్నను మా బృందానికి పంపాను, 2 పని గంటల్లోపు (within 2 working hours) ఎవరైనా మీకు తిరిగి కాల్ చేస్తారు.${askContact ? ' మిమ్మల్ని సంప్రదించడానికి దయచేసి మీ పేరు మరియు ఫోన్ నంబర్ తెలపండి.' : ''}${phone ? ` మీరు మాకు ${phone}కు కూడా కాల్ చేయవచ్చు.` : ''}`;
  },
  human: (askContact, phone) => `తప్పకుండా — 2 పని గంటల్లోపు (within 2 working hours) మీకు తిరిగి కాల్ చేయమని మా బృందానికి చెప్పాను.${askContact ? ' వారు మిమ్మల్ని సంప్రదించడానికి దయచేసి మీ పేరు మరియు ఫోన్ నంబర్ తెలపండి.' : ''}${phone ? ` మీరు మాకు ${phone}కు కూడా కాల్ చేయవచ్చు.` : ''}`,
  askPhone: () => 'తప్పకుండా — దయచేసి మీ పేరు మరియు ఫోన్ నంబర్ టైప్ చేయండి (ఉదా: Ravi Kumar, 98765 43210), వాటిని మీ అభ్యర్థనకు జోడిస్తాను.',
  relatedDoctor: (term, doctor, role) => `క్లినిక్ సమాచారంలో ${doctor}${role ? ` (${role})` : ''} ఉన్నారు, కానీ ${term} ప్రత్యేకంగా నిర్ధారించబడలేదు.`,
  relatedService: (term, service) => `క్లినిక్ సమాచారంలో ${service} ఉంది, కానీ ${term} ప్రత్యేకంగా నిర్ధారించబడలేదు.`,
  relatedNote: (term, note) => `క్లినిక్ సమాచారంలో ఇది మాత్రమే ఉంది: "${dot(note)}" ఇందులో ${term} ప్రత్యేక సేవ లేదా ధరగా లేదు.`,
  hoursLabel: (key, label) => {
    const m = key.toLowerCase().match(HOURS_LABEL_RE);
    if (m) return m[2] ? `${WEEKDAYS.te[WD_INDEX[m[1]]]} నుండి ${WEEKDAYS.te[WD_INDEX[m[2]]]} వరకు` : WEEKDAYS.te[WD_INDEX[m[1]]];
    if (/lunch|break/i.test(key)) return 'మధ్యాహ్న భోజన విరామం';
    if (/holiday/i.test(key)) return 'ప్రభుత్వ సెలవు దినాలు';
    return label;
  },
  hoursLine: (label, text) => `${label}: ${dot(text)}`,
  hoursForDay: (day, text) => (/^\d/.test(text.trim()) ? `${day} మేము ${text.trim()} తెరిచి ఉంటాము.` : `${day}: ${dot(text)}`),
  hoursAll: (lines) => `మా తెరిచే సమయాలు:\n${lines.map((l) => `• ${dot(l)}`).join('\n')}`,
  dayNotListed: (day) => `క్లినిక్ సమాచారంలో ${day} తెరిచే సమయాలు ఇవ్వలేదు.`,
  openNow: (s) => openNowText(s, 'te'),
  doctorLine: (name, role, days) => `${name}${role ? ` — ${role}` : ''}${days ? `. అందుబాటులో: ${days}` : ''}.`,
  doctorHours: (doc, days, groups) => `${doc} ఈ రోజుల్లో క్లినిక్‌లో ఉంటారు: ${dot(days)}${groups.length ? ` ఆ రోజుల్లో క్లినిక్ సమయాలు: ${groups.join('; ')}.` : ''}`,
  discountNoted: () => 'మీ సందేశాన్ని మా బృందానికి పంపాను, 2 పని గంటల్లోపు (within 2 working hours) ఎవరైనా మీకు తిరిగి కాల్ చేస్తారు.',
  doctorOnDay: (doc, days, all) => `${doc} నిర్ణీత రోజుల్లో ${days} ఉంది (షెడ్యూల్: ${all}). ప్రత్యక్ష అపాయింట్‌మెంట్ సమయాలు నేను చూడలేను — అభ్యర్థన పంపితే సిబ్బంది ఖచ్చితమైన సమయం నిర్ధారిస్తారు.`,
  doctorNotOnDay: (doc, days, all) => `${doc} ${days} అందుబాటులో ఉన్నట్లు లేదు. ${doc} రోజులు: ${dot(all)}`,
  doctorList: (lines) => `మా దంత వైద్యులు:\n${lines.map((l) => `• ${l}`).join('\n')}`,
  serviceLine: (name, price, extra) => `${name}: ${price || 'ధర క్లినిక్ సమాచారంలో లేదు'}${extra ? ` (${extra})` : ''}.`,
  takesAbout: (d) => `సుమారు ${d} పడుతుంది`,
  priceList: (lines) => `మా చికిత్స ధరలు:\n${lines.map((l) => `• ${l}`).join('\n')}`,
  insuranceYes: (provider, text) => `అవును — ${provider} క్యాష్‌లెస్ (cashless) పద్ధతిలో అంగీకరించబడుతుంది. క్లినిక్ విధానం: ${dot(text)}`,
  insuranceOther: (name, providers, other) => `${name} మా క్యాష్‌లెస్ జాబితాలో లేదు${providers.length ? ` (క్యాష్‌లెస్ సదుపాయం ${joinWith(providers, 'మరియు')}తో ఉంది)` : ''}. ${dot(other)}`,
  insuranceGeneral: (providers, text) => (providers.length ? `మేము ${joinWith(providers, 'మరియు')}తో క్యాష్‌లెస్ (cashless) చికిత్స అందిస్తాము. క్లినిక్ విధానం: ${dot(text)}` : `బీమా: ${dot(text)}`),
  policy: (label, value) => `విధానం (${label}): ${value}`,
  field: (key, label, value) => {
    switch (key) {
      case 'address': return `మా చిరునామా: ${dot(value)}`;
      case 'landmark': return `గుర్తు: ${dot(value)}`;
      case 'phone': return `ప్రధాన ఫోన్: ${value}`;
      case 'whatsapp': return `వాట్సాప్: ${value}`;
      case 'emergency_phone': return `ఎమర్జెన్సీ లైన్: ${value}`;
      case 'languages': return `మా బృందం మాట్లాడే భాషలు: ${dot(value)}`;
      case 'parking': return `పార్కింగ్: ${dot(value)}`;
      default: return `${label}: ${dot(value)}`;
    }
  },
  clinicName: (name) => `మీరు ${name} ఫ్రంట్ డెస్క్‌తో మాట్లాడుతున్నారు.`,
  contactThanks: (name, joined) => joined
    ? `ధన్యవాదాలు${name ? `, ${name}` : ''}. మీ సంప్రదింపు వివరాలను మీ అభ్యర్థనకు జోడించాను — మా బృందం 2 పని గంటల్లోపు (within 2 working hours) మీకు తిరిగి కాల్ చేస్తుంది.`
    : `ధన్యవాదాలు${name ? `, ${name}` : ''} — మీ వివరాలను మా బృందానికి పంపాను, 2 పని గంటల్లోపు (within 2 working hours) ఎవరైనా మీకు కాల్ చేస్తారు. మీకు ఏ విషయంలో సహాయం కావాలో కూడా చెప్పవచ్చు.`,
  slotIssue: (i) => {
    const dn = i.day !== undefined ? WEEKDAYS.te[i.day] : '';
    switch (i.code) {
      case 'holiday': return `${dn} ప్రభుత్వ సెలవు (${i.holiday}). క్లినిక్ సమాచారం: ${i.text || 'Closed'}.`;
      case 'closed': return `${dn}: ${dot(i.text || 'Closed')} (సాధారణ అపాయింట్‌మెంట్లకు క్లినిక్ సమయం కాదు)`;
      case 'not-listed': return `క్లినిక్ సమాచారంలో ${dn} తెరిచే సమయాలు ఇవ్వలేదు.`;
      case 'outside': return `${clock12(i.time!)} ${dn} నిర్ణీత సమయాలు (${i.text}) బయట ఉంది.`;
      case 'lunch': return `${clock12(i.time!)} మధ్యాహ్న భోజన విరామం (${i.text})లో వస్తుంది.`;
      case 'doctor-day': return `${i.doctor} ${dn} అందుబాటులో ఉన్నట్లు లేదు. వారి రోజులు: ${dot(i.doctorDays || '')}`;
      case 'past-date': return 'ఆ తేదీ ఇప్పటికే గడిచిపోయింది — బదులుగా ఏ రోజు మీకు అనుకూలం?';
      case 'past-time': return 'ఈరోజు ఆ సమయం ఇప్పటికే గడిచిపోయింది — బదులుగా ఏ సమయం అనుకూలం?';
      default: return '';
    }
  },
  bookingReply: (b, o) => {
    const when = requestedLabel(b, 'te');
    const what = [when, b.doctor ? `${b.doctor}తో` : '', b.service ? `(${serviceName(b.service, 'te')})` : ''].filter(Boolean).join(', ');
    const m = b.missing || [];
    const needDay = m.includes('date') && b.dateIssue !== 'past';
    const needTime = m.includes('time');
    return [
      `${o.noteAdded ? 'ధన్యవాదాలు — ఈ సమాచారాన్ని మీ అభ్యర్థనకు జోడించాను' : o.updated ? 'ధన్యవాదాలు — మీ అభ్యర్థనను అప్‌డేట్ చేశాను' : 'మీ అభ్యర్థనను నమోదు చేశాను'}${what ? `: ${what}` : ''}.`,
      'ఇది ఒక అభ్యర్థన మాత్రమే, నిర్ధారిత బుకింగ్ కాదు (not a confirmed booking). నిర్ధారించడానికి మా బృందం 2 పని గంటల్లోపు (within 2 working hours) మీకు కాల్ చేస్తుంది.',
      ...(b.issues || []).map((i) => te.slotIssue(i)),
      b.dateIssue === 'vague' ? 'మీకు ఏ రోజు కావాలి (ఉదా: శనివారం లేదా 21 Nov)?' : '',
      b.timeIssue === 'vague' ? 'ఖచ్చితంగా ఏ సమయం అనుకూలం (ఉదా: 11:00 AM)?' : '',
      needDay && needTime ? 'మీకు ఏ రోజు, ఏ సమయం అనుకూలం?' : needDay ? 'మీకు ఏ రోజు అనుకూలం?' : needTime ? 'మీకు ఏ సమయం అనుకూలం?' : '',
      m.includes('treatment') && !o.noteAdded ? 'ఇది ఏ చికిత్స కోసం?' : '',
      m.includes('name') && m.includes('phone') ? 'దయచేసి మీ పేరు మరియు ఫోన్ నంబర్ తెలపండి.' : m.includes('name') ? 'దయచేసి మీ పేరు తెలపండి.' : m.includes('phone') ? 'దయచేసి మీ ఫోన్ నంబర్ తెలపండి.' : '',
      b.state === 'awaiting confirmation' ? 'స్థితి: సిబ్బంది నిర్ధారణ కోసం వేచి ఉంది (awaiting staff confirmation).' : 'స్థితి: అపాయింట్‌మెంట్ అభ్యర్థించబడింది (appointment requested).',
      o.policy ? `అపాయింట్‌మెంట్ విధానం: ${dot(o.policy)}` : '',
    ].filter(Boolean).join('\n');
  },
  noLiveSlots: () => 'ప్రత్యక్ష అపాయింట్‌మెంట్ స్లాట్లు లేదా దంత వైద్యుల ఖాళీ సమయాలు నేను చూడలేను, కాబట్టి ఊహించను. అపాయింట్‌మెంట్ అభ్యర్థన పంపగలను, సిబ్బంది మీతో లభ్యతను నిర్ధారిస్తారు.',
  bookingAsk: (policy) => `తప్పకుండా. మీకు ఏ రోజు, ఏ సమయం అనుకూలం, ఇది ఏ చికిత్స లేదా ఏ దంత వైద్యుడి కోసం? దయచేసి మీ పేరు మరియు ఫోన్ నంబర్ కూడా తెలపండి. ఇది అభ్యర్థన మాత్రమే, నిర్ధారిత బుకింగ్ కాదు — నిర్ధారించడానికి మా బృందం 2 పని గంటల్లోపు (within 2 working hours) కాల్ చేస్తుంది.${policy ? `\nఅపాయింట్‌మెంట్ విధానం: ${dot(policy)}` : ''}`,
  bookingDecision: (d) => d.decision === 'confirm'
    ? [`✅ మా సిబ్బంది మీ అపాయింట్‌మెంట్‌ను నిర్ధారించారు (confirmed by our staff): ${[d.date ? shortDate(d.date, 'te') : '', d.time ? clock12(d.time) : ''].filter(Boolean).join(', ')}${d.doctor ? `, ${d.doctor}తో` : ''}${d.service ? ` (${serviceName(d.service, 'te')})` : ''}.`, d.note || '', d.policy ? `రద్దు చేయడానికి లేదా మార్చడానికి: ${dot(d.policy)}` : ''].filter(Boolean).join('\n')
    : [`క్షమించండి — మీరు అడిగిన సమయం${d.requested ? ` (${d.requested})` : ''} నిర్ధారించలేము.`, d.note || '', 'దయచేసి ఇక్కడ మరో రోజు, సమయం తెలపండి, మా బృందం మళ్లీ పరిశీలిస్తుంది.'].filter(Boolean).join('\n'),
};
void dotHi;

/** "Open now" badge and reply text in the patient's language. @i18n-review */
export function openNowText(s: OpenStatus, lang: Lang): string {
  if (lang === 'en') return s.label;
  const when = (n?: OpenStatus['next']) => !n ? '' : lang === 'hi'
    ? `${n.when === 'today' ? 'आज' : n.when === 'tomorrow' ? 'कल' : WEEKDAYS.hi[n.when as number]} ${clock12(n.time)}`
    : `${n.when === 'today' ? 'ఈరోజు' : n.when === 'tomorrow' ? 'రేపు' : WEEKDAYS.te[n.when as number]} ${clock12(n.time)}`;
  const until = s.until ? clock12(s.until) : '';
  const H = { open: `अभी खुला है · ${until} तक`, break: `दोपहर का अवकाश · फ्रंट डेस्क ${until} बजे वापस`, 'emergency-only': `केवल आपातकाल · ${until} तक`, closed: `अभी बंद है · ${when(s.next)} खुलेगा`, holiday: `आज बंद (${s.holiday}) · ${when(s.next)} खुलेगा`, unknown: 'खुलने का समय: हमसे पूछें' };
  const Te = { open: `ఇప్పుడు తెరిచి ఉంది · ${until} వరకు`, break: `భోజన విరామం · ఫ్రంట్ డెస్క్ ${until}కు తిరిగి`, 'emergency-only': `అత్యవసరాలకు మాత్రమే · ${until} వరకు`, closed: `ఇప్పుడు మూసి ఉంది · ${when(s.next)} తెరుస్తారు`, holiday: `ఈరోజు సెలవు (${s.holiday}) · ${when(s.next)} తెరుస్తారు`, unknown: 'తెరిచే సమయాలు: మమ్మల్ని అడగండి' };
  return (lang === 'hi' ? H : Te)[s.state];
}

/** Quick-reply chip labels. Clicking sends the label as a normal patient message. @i18n-review */
export const QUICK_LABELS: Record<Lang, Record<'timings' | 'doctors' | 'prices' | 'insurance' | 'location' | 'book' | 'human' | 'phone' | 'addPhone' | 'call', string>> = {
  en: { timings: 'Timings', doctors: 'Doctors', prices: 'Prices', insurance: 'Insurance', location: 'Location', book: 'Book an appointment', human: 'Talk to a human', phone: 'Share my phone number', addPhone: 'Add my phone number', call: 'Call' },
  hi: { timings: 'समय', doctors: 'डॉक्टर', prices: 'कीमतें', insurance: 'बीमा', location: 'पता', book: 'अपॉइंटमेंट बुक करें', human: 'किसी व्यक्ति से बात करें', phone: 'मेरा फ़ोन नंबर साझा करें', addPhone: 'मेरा फ़ोन नंबर जोड़ें', call: 'कॉल करें' },
  te: { timings: 'సమయాలు', doctors: 'డాక్టర్లు', prices: 'ధరలు', insurance: 'బీమా', location: 'చిరునామా', book: 'అపాయింట్‌మెంట్ బుక్ చేయండి', human: 'మనిషితో మాట్లాడండి', phone: 'నా ఫోన్ నంబర్ ఇస్తాను', addPhone: 'నా ఫోన్ నంబర్ జోడించండి', call: 'కాల్ చేయండి' },
};
/** The small source label stays in English; a translation is added after it. @i18n-review */
export const SOURCE_LABEL: Record<Lang, { file: string; faq: string; mixed: string }> = {
  en: { file: 'Answered from the clinic file', faq: 'Answered from the clinic file · Staff FAQ', mixed: 'Answered from the clinic file · Staff FAQ' },
  hi: { file: 'Answered from the clinic file · क्लिनिक फ़ाइल से उत्तर', faq: 'Answered from the clinic file · Staff FAQ · स्टाफ FAQ से उत्तर', mixed: 'Answered from the clinic file · Staff FAQ' },
  te: { file: 'Answered from the clinic file · క్లినిక్ ఫైల్ నుండి సమాధానం', faq: 'Answered from the clinic file · Staff FAQ · సిబ్బంది FAQ నుండి సమాధానం', mixed: 'Answered from the clinic file · Staff FAQ' },
};

const SETS: Record<Lang, Templates> = { en, hi, te };
export function T(lang: Lang): Templates { return SETS[lang] || en; }
