// Builds a searchable index from ANY clinic dataset with the supported schema.
// Nothing here is specific to Bright Roots Dental.
import { DAY_ALIASES, GENERIC, INSURERS } from './lexicon.ts';
import { normalize, stem, tokens, titleCaseKey } from './normalize.ts';
import { parseRangeLoose as parseRangeRaw } from './datetime.ts';
import type { ClinicData, Doctor, Service } from './types.ts';

export interface HoursEntry {
  key: string;
  label: string;
  text: string;
  days: number[]; // empty when not a weekday range
  kind: 'days' | 'holiday' | 'break' | 'other';
}

export interface ServiceEntry {
  service: Service;
  primary: string[]; // distinctive tokens from the main name
  secondary: string[]; // distinctive tokens from bracketed aliases
}

export interface DoctorEntry {
  doctor: Doctor;
  nameTokens: string[];
  roleTokens: string[];
  days: number[];
  daysText: string;
}

export interface FieldEntry {
  key: string;
  label: string;
  value: string;
  keywords: string[]; // phrases
}

export interface KnowledgeIndex {
  data: ClinicData;
  clinicName: string;
  hours: HoursEntry[];
  services: ServiceEntry[];
  doctors: DoctorEntry[];
  policies: FieldEntry[];
  clinicFields: FieldEntry[];
  insuranceText?: string;
  cashlessProviders: string[];
  knownInsurers: string[];
  emergencyPhone?: string;
  mainPhone?: string;
  whatsapp?: string;
  emergencyRules?: string;
  corpus: string; // normalised text of every fact, for "mentioned elsewhere" checks
  faq: Array<{ q: string; a: string; from?: string; toks: string[] }>;
}

export function asText(v: unknown): string {
  if (v == null) return '';
  if (Array.isArray(v)) return v.map(asText).filter(Boolean).join(', ');
  if (typeof v === 'number') return `Rs ${v.toLocaleString('en-IN')}`;
  if (typeof v === 'object') return Object.values(v as Record<string, unknown>).map(asText).filter(Boolean).join(', ');
  return String(v).trim();
}

export function parseDays(text: string): number[] {
  const n = normalize(text).replace(/-/g, ' to ');
  if (/\b(daily|every day|everyday|all days|all week|7 days|seven days)\b/.test(n)) return [0, 1, 2, 3, 4, 5, 6];
  const out = new Set<number>();
  if (/\bweekdays?\b/.test(n)) [1, 2, 3, 4, 5].forEach((d) => out.add(d));
  if (/\bweekends?\b/.test(n)) [0, 6].forEach((d) => out.add(d));
  const words = n.split(/[\s_,/&]+/).filter(Boolean);
  for (let i = 0; i < words.length; i++) {
    const d = DAY_ALIASES[words[i]];
    if (d === undefined) continue;
    const link = words[i + 1];
    const e = DAY_ALIASES[words[i + 2]];
    if ((link === 'to' || link === 'through' || link === 'till' || link === 'until' || link === 'thru') && e !== undefined) {
      for (let k = d; ; k = (k + 1) % 7) { out.add(k); if (k === e) break; }
      i += 2;
    } else out.add(d);
  }
  return [...out].sort();
}

function distinctive(text: string): string[] {
  return tokens(normalize(text)).filter((t) => t.length > 1 && !GENERIC.has(t) && !/^\d+$/.test(t));
}

const POLICY_KEYWORDS: Record<string, string[]> = {
  appointment: ['appointment', 'appointments', 'cancel', 'cancellation', 'cancelling', 'reschedule', 'rescheduling',
    'postpone', 'move my appointment', 'change my appointment', 'late fee', 'cancellation fee', 'how to book',
    'how do i book', 'how can i book', 'book on whatsapp', 'book by phone', 'no show'],
  walk: ['walkin', 'walk in', 'without appointment', 'without an appointment', 'without booking', 'drop in',
    'just come', 'come directly', 'come straight'],
  payment: ['payment', 'pay', 'paying', 'upi', 'gpay', 'google pay', 'phonepe', 'paytm', 'card', 'cards', 'credit card',
    'debit card', 'cash', 'net banking', 'bhim'],
  emi: ['emi', 'instalment', 'installment', 'instalments', 'installments', 'monthly payment', 'pay monthly', 'finance',
    'financing', 'loan', 'no cost emi', 'pay later'],
  insurance: ['insurance', 'insurer', 'insurers', 'cashless', 'claim', 'mediclaim', 'reimbursement', 'reimburse', 'tpa',
    'health cover', 'health policy'],
  child: ['child', 'children', 'kid', 'kids', 'son', 'daughter', 'baby', 'paediatric', 'pediatric', 'parent'],
  first: ['first visit', 'first time', 'first appointment', 'new patient', 'what to bring', 'what should i bring',
    'bring anything', 'bring my', 'should i bring', 'documents'],
  steril: ['sterilisation', 'sterilization', 'sterilise', 'sterilize', 'sterile', 'hygiene', 'hygienic', 'autoclave',
    'instruments', 'infection control', 'is it safe', 'safety'],
};

function policyKeywords(key: string): string[] {
  const k = normalize(key.replace(/[_-]+/g, ' '));
  const out = new Set<string>([k, ...k.split(' ').filter((w) => w.length > 2)]);
  for (const [frag, kws] of Object.entries(POLICY_KEYWORDS)) {
    if (k.includes(frag) || stem(k) === stem(frag)) kws.forEach((x) => out.add(x));
  }
  return [...out];
}

const CLINIC_FIELD_KEYWORDS: Record<string, string[]> = {
  name: ['clinic name', 'name of the clinic', 'name of your clinic', 'what is this clinic', 'who are you'],
  address: ['address', 'where', 'located', 'location', 'directions', 'direction', 'find you', 'reach you', 'how to reach',
    'map', 'situated', 'area', 'which road', 'pin code', 'pincode'],
  landmark: ['landmark', 'near', 'nearby', 'opposite', 'next to'],
  phone: ['phone', 'call', 'contact', 'telephone', 'number', 'mobile', 'reach you', 'landline'],
  emergency_phone: ['emergency number', 'emergency phone', 'emergency line', 'emergency contact', 'after hours number',
    'emergency helpline'],
  whatsapp: ['whatsapp', 'message you', 'text you', 'chat with you', 'sms'],
  languages: ['language', 'languages', 'speak', 'hindi speaking', 'telugu speaking', 'english speaking', 'understand'],
  parking: ['parking', 'park', 'car', 'vehicle', 'bike', 'scooter', 'valet', 'basement'],
  email: ['email', 'e mail', 'mail id'],
  website: ['website', 'site', 'web'],
};

export function buildIndex(data: ClinicData): KnowledgeIndex {
  const clinic = data.clinic || ({ name: 'the clinic' } as ClinicData['clinic']);

  // ---- hours (object or array form)
  const hours: HoursEntry[] = [];
  const rawHours = data.hours;
  const pushHours = (key: string, label: string, text: string) => {
    const lk = normalize(key + ' ' + label);
    let days = parseDays(label);
    let kind: HoursEntry['kind'] = 'days';
    if (/holiday|festival/.test(lk)) { kind = 'holiday'; days = []; }
    else if (/lunch|break/.test(lk)) { kind = 'break'; days = []; }
    else if (!days.length) kind = 'other';
    hours.push({ key, label, text, days, kind });
  };
  if (Array.isArray(rawHours)) {
    rawHours.forEach((h, i) => {
      const label = asText(h.days ?? h.day ?? h.label ?? h.name ?? `Hours ${i + 1}`);
      const text = asText(h.hours ?? h.time ?? h.timing ?? h.text ?? h.value);
      pushHours(label, label, text);
    });
  } else if (rawHours && typeof rawHours === 'object') {
    for (const [k, v] of Object.entries(rawHours)) pushHours(k, titleCaseKey(k), asText(v));
  }

  // ---- services
  const services: ServiceEntry[] = (data.services || []).filter((s) => s && s.name).map((s) => {
    const name = String(s.name);
    const main = name.replace(/\([^)]*\)/g, ' ');
    const brackets = (name.match(/\(([^)]*)\)/g) || []).join(' ');
    const extraAliases = asText((s as Record<string, unknown>).aliases);
    return { service: s, primary: distinctive(main), secondary: distinctive(brackets + ' ' + extraAliases) };
  });

  // ---- doctors
  const doctors: DoctorEntry[] = (data.doctors || []).filter((d) => d && d.name).map((d) => {
    const nameTokens = normalize(String(d.name)).split(' ').filter((w) => w.length > 1 && w !== 'dr' && w !== 'doctor');
    const daysText = asText(d.days);
    return { doctor: d, nameTokens, roleTokens: distinctive(asText(d.role) + ' ' + asText((d as Record<string, unknown>).specialty)), days: parseDays(daysText), daysText };
  });

  // ---- policies
  const policies: FieldEntry[] = Object.entries(data.policies || {}).map(([k, v]) => ({
    key: k, label: titleCaseKey(k), value: asText(v), keywords: policyKeywords(k),
  }));

  // ---- clinic fields
  const clinicFields: FieldEntry[] = Object.entries(clinic)
    .filter(([, v]) => v != null && asText(v) !== '')
    .map(([k, v]) => {
      const nk = normalize(k.replace(/[_-]+/g, ' '));
      const kws = CLINIC_FIELD_KEYWORDS[k] || [nk, ...nk.split(' ').filter((w) => w.length > 3)];
      return { key: k, label: titleCaseKey(k), value: asText(v), keywords: kws };
    });

  // ---- insurance
  const insEntry = policies.find((p) => /insur|cashless|mediclaim/.test(normalize(p.key)));
  const insuranceText = insEntry?.value;
  const cashlessProviders: string[] = [];
  if (insuranceText) {
    const m = insuranceText.match(/cashless(?:\s+(?:with|for|via|through|from))?\s+([^.;]+)/i);
    if (m) {
      m[1].split(/,|\band\b|&|\//i).map((x) => x.replace(/\b(insurance|only|cards?|policies|policy)\b/gi, '').trim())
        .filter((x) => x.length > 1).forEach((x) => cashlessProviders.push(x));
    }
  }
  const knownInsurers = [...new Set([...INSURERS, ...cashlessProviders.map((p) => normalize(p))])];

  const corpus = normalize([
    asText(clinic), ...hours.map((h) => `${h.label} ${h.text}`),
    ...(data.doctors || []).map((d) => `${d.name} ${asText(d.role)} ${asText(d.days)}`),
    ...(data.services || []).map((s) => `${s.name} ${asText(s.price)} ${asText(s.note)} ${asText(s.duration)}`),
    ...policies.map((p) => p.value), asText(data.emergency_rules),
  ].join(' . '));

  return {
    data,
    clinicName: asText(clinic.name) || 'the clinic',
    hours, services, doctors, policies, clinicFields,
    insuranceText, cashlessProviders, knownInsurers,
    emergencyPhone: asText(clinic.emergency_phone) || undefined,
    mainPhone: asText(clinic.phone) || undefined,
    whatsapp: asText(clinic.whatsapp) || undefined,
    emergencyRules: asText(data.emergency_rules) || undefined,
    corpus,
    faq: (Array.isArray(data.faq) ? data.faq : [])
      .filter((f) => f && typeof f.q === 'string' && typeof f.a === 'string' && f.q.trim() && f.a.trim())
      .map((f) => ({ q: f.q, a: f.a, from: f.from, toks: faqTokens(f.q) })),
  };
}

const FAQ_STOP = new Set(['a', 'an', 'the', 'is', 'are', 'am', 'do', 'does', 'did', 'you', 'your', 'we', 'our', 'i', 'me', 'my', 'it',
  'to', 'of', 'in', 'on', 'at', 'for', 'and', 'or', 'can', 'could', 'would', 'should', 'will', 'please', 'tell', 'what', 'which',
  'how', 'there', 'this', 'that', 'have', 'has', 'any', 'also', 'hi', 'hello', 'hey', 'clinic', 'kindly', 'know', 'want', 'like', 'get']);
/** normalised content tokens used for FAQ matching */
export function faqTokens(text: string): string[] {
  return [...new Set(normalize(text).split(' ').filter((w) => w && !FAQ_STOP.has(w)).map(stem))];
}

/** Schema validation used by the clinic editor, JSON import and tests. A broken file is never saved. */
export function validateClinicData(input: unknown): { ok: boolean; errors: string[] } {
  const errors: string[] = [];
  const d = input as ClinicData;
  if (!d || typeof d !== 'object' || Array.isArray(d)) return { ok: false, errors: ['The clinic file must be a JSON object.'] };
  const txt = (v: unknown) => typeof v === 'string' && v.trim().length > 0;
  if (!d.clinic || typeof d.clinic !== 'object' || Array.isArray(d.clinic)) errors.push('Missing "clinic" details.');
  else {
    if (!txt(d.clinic.name)) errors.push('Clinic name is required.');
    if (!txt(d.clinic.emergency_phone)) errors.push('Emergency phone number is required.');
    else if ((String(d.clinic.emergency_phone).match(/\d/g) || []).length < 6) errors.push('Emergency phone number looks incomplete.');
  }
  // timings
  if (d.hours !== undefined) {
    if (typeof d.hours !== 'object' || d.hours === null) errors.push('"hours" must be an object.');
    else if (!Array.isArray(d.hours)) {
      const entries = Object.entries(d.hours);
      if (!entries.length) errors.push('Add at least one timing row.');
      for (const [k, v] of entries) {
        const label = titleCaseKey(k);
        if (!txt(k)) errors.push('A timing row has no days.');
        if (!txt(v)) { errors.push(`Timing "${label}" is empty.`); continue; }
        const text = String(v);
        if (/^\s*closed\b/i.test(text)) continue;
        const r = parseRangeRaw(text);
        if (!r) errors.push(`Timing "${label}": write it as "9:00 am to 8:00 pm" or "Closed".`);
        else if (r[1] <= r[0]) errors.push(`Timing "${label}": closing time must be later than opening time.`);
        const isDayRow = !/holiday|festival|lunch|break/i.test(k);
        if (isDayRow && !parseDays(k.replace(/_/g, ' ')).length) errors.push(`Timing "${label}": the row name must name days, e.g. "monday_to_friday" or "saturday".`);
      }
    }
  }
  // doctors
  if (d.doctors !== undefined && !Array.isArray(d.doctors)) errors.push('"doctors" must be a list.');
  const docNames = new Set<string>();
  (Array.isArray(d.doctors) ? d.doctors : []).forEach((x, i) => {
    if (!x || !txt(x.name)) { errors.push(`Doctor #${i + 1} needs a name.`); return; }
    const k = String(x.name).trim().toLowerCase();
    if (docNames.has(k)) errors.push(`Doctor "${x.name}" is listed twice.`);
    docNames.add(k);
  });
  // services
  if (d.services !== undefined && !Array.isArray(d.services)) errors.push('"services" must be a list.');
  const svcNames = new Set<string>();
  (Array.isArray(d.services) ? d.services : []).forEach((s, i) => {
    if (!s || !txt(s.name)) { errors.push(`Service #${i + 1} needs a name.`); return; }
    const k = String(s.name).trim().toLowerCase().replace(/\s+/g, ' ');
    if (svcNames.has(k)) errors.push(`Service names must be unique: "${s.name}" appears twice.`);
    svcNames.add(k);
    if (s.price !== undefined && !txt(s.price) && typeof s.price !== 'number') errors.push(`Service "${s.name}": price cannot be empty (remove it or write the price).`);
    if (s.aliases !== undefined && !Array.isArray(s.aliases) && typeof s.aliases !== 'string') errors.push(`Service "${s.name}": aliases must be a list.`);
  });
  // policies
  if (d.policies !== undefined) {
    if (typeof d.policies !== 'object' || d.policies === null || Array.isArray(d.policies)) errors.push('"policies" must be an object.');
    else for (const [k, v] of Object.entries(d.policies)) { if (!txt(k)) errors.push('A policy has no name.'); if (!txt(v)) errors.push(`Policy "${titleCaseKey(k)}" is empty.`); }
  }
  // FAQ
  if (d.faq !== undefined && !Array.isArray(d.faq)) errors.push('"faq" must be a list.');
  (Array.isArray(d.faq) ? d.faq : []).forEach((f, i) => { if (!f || !txt(f.q) || !txt(f.a)) errors.push(`FAQ #${i + 1} needs both a question and an answer.`); });
  // holidays
  if (d.holidays !== undefined) {
    if (!Array.isArray(d.holidays)) errors.push('"holidays" must be a list.');
    else d.holidays.forEach((h, i) => { const date = typeof h === 'string' ? h : h?.date; if (!/^\d{4}-\d{2}-\d{2}$/.test(String(date)) || Number.isNaN(Date.parse(`${date}T00:00:00Z`))) errors.push(`Holiday #${i + 1}: date must be YYYY-MM-DD.`); });
  }
  if (JSON.stringify(d).length > 200_000) errors.push('The clinic file is too large (max 200 KB).');
  return { ok: errors.length === 0, errors };
}
