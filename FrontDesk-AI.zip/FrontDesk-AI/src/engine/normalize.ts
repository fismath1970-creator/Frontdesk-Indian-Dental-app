import { CANONICAL, INDIC_HINTS, HINDI_TRANSLIT, TELUGU_TRANSLIT } from './lexicon.ts';
import type { Lang } from './types.ts';

const DEVANAGARI = /[\u0900-\u097F]/;
const TELUGU = /[\u0C00-\u0C7F]/;

/**
 * Per-message language: ≥30% of the letters Devanagari → "hi"; ≥30% Telugu script → "te"; else "en".
 * Romanized Hindi/Telugu (kitna, kab, dard, entha, ela…) is best effort → reply in native script.
 */
export function detectLang(raw: string): Lang {
  const letters = (raw.match(/[\p{L}\p{M}]/gu) || []).length;
  if (letters) {
    const hi = (raw.match(/[\u0900-\u097F]/g) || []).length;
    const te = (raw.match(/[\u0C00-\u0C7F]/g) || []).length;
    if (te / letters >= 0.3 && te >= hi) return 'te';
    if (hi / letters >= 0.3) return 'hi';
    if (te / letters >= 0.3) return 'te';
  }
  const words = raw.toLowerCase().split(/[^a-z]+/).filter(Boolean);
  let h = 0, t = 0;
  for (const w of words) { if (HINDI_TRANSLIT.has(w)) h++; if (TELUGU_TRANSLIT.has(w)) t++; }
  if (t >= 2 || (t >= 1 && words.length <= 4 && t > h)) return 'te';
  if (h >= 2 || (h >= 1 && words.length <= 4 && h > t)) return 'hi';
  return 'en';
}

/** Lower-case, unify punctuation, expand contractions and common spellings. */
export function normalize(raw: string): string {
  // zero-width (non-)joiners are part of Indic spellings (అపాయింట్‌మెంట్) — drop them, never turn them into spaces
  let t = (raw || '').normalize('NFKC').replace(/[\u200c\u200d]/g, '').toLowerCase();
  t = t.replace(/[’‘`´]/g, "'").replace(/[“”]/g, '"').replace(/[–—]/g, '-');
  t = t
    .replace(/\bcan'?t\b/g, 'cannot').replace(/\bwon'?t\b/g, 'will not').replace(/\bdon'?t\b/g, 'do not')
    .replace(/\bdoesn'?t\b/g, 'does not').replace(/\bisn'?t\b/g, 'is not').replace(/\baren'?t\b/g, 'are not')
    .replace(/\bdidn'?t\b/g, 'did not').replace(/\bhaven'?t\b/g, 'have not').replace(/\bwouldn'?t\b/g, 'would not')
    .replace(/\bcouldn'?t\b/g, 'could not').replace(/\bshouldn'?t\b/g, 'should not')
    .replace(/(\w)n't\b/g, '$1 not').replace(/\bwhat'?s\b/g, 'what is').replace(/\bit'?s\b/g, 'it is')
    .replace(/\bi'm\b/g, 'i am').replace(/\bi'd\b/g, 'i would').replace(/\blet'?s\b/g, 'let us')
    .replace(/'s\b/g, '');
  t = t
    .replace(/\bx[\s-]?rays?\b/g, 'xray')
    .replace(/\bwalk[\s-]?ins?\b/g, 'walkin')
    .replace(/\bcheck[\s-]?ups?\b/g, 'checkup')
    .replace(/\bwhats?\s?app\b/g, 'whatsapp')
    .replace(/\brct\b/g, 'root canal')
    .replace(/\bendodontic\w*\b/g, 'root canal')
    .replace(/\bdr\.\s*/g, 'dr ')
    .replace(/\bpaed\b|\bped\b/g, 'paediatric')
    .replace(/\be\.m\.i\.?\b/g, 'emi')
    .replace(/(\d)\s*%/g, '$1 %')
    .replace(/\bper\s?cent\b/g, '%');
  // Hindi / Telugu clock words: "5 बजे", "5 baje", "5 గంటలకు" → "at 5"
  t = t.replace(/(\d{1,2})(?:[:.](\d{2}))?\s*(बजे|baje|बजकर|గంటలకు|గంటకు|గం|gantalaku|gantaku)/g, (_m, h, mm) => (mm ? ` ${h}:${mm} ` : ` at ${h} `));
  // "my 5 year old" → a child (under 14) so paediatric rules apply
  t = t.replace(/\b(\d{1,2})\s*(year|yr|years|yrs)\s*old\b/g, (m, a) => (Number(a) < 14 ? `${m} child` : m));
  // keep letters (any script), combining marks, digits, %, colon (times) and commas inside numbers
  t = t.replace(/(\d),(\d)/g, '$1$2');
  t = t.replace(/[^\p{L}\p{M}\p{N}%:\s]/gu, ' ');
  return t.replace(/\s+/g, ' ').trim();
}

/** Append English intent hints for Hindi/Telugu words so one matcher serves all languages. */
export function addIndicHints(norm: string): string {
  if (!DEVANAGARI.test(norm) && !TELUGU.test(norm) && !/[a-z]/.test(norm)) return norm;
  const words = new Set(norm.split(' '));
  const extra: string[] = [];
  for (const [k, v] of INDIC_HINTS) {
    const isAscii = /^[a-z ]+$/.test(k);
    if (isAscii ? words.has(k) : norm.includes(k.replace(/[\u200c\u200d]/g, ''))) extra.push(v);
  }
  return extra.length ? `${norm} ${extra.join(' ')}` : norm;
}

export function stem(word: string): string {
  if (CANONICAL[word]) return CANONICAL[word];
  let w = word;
  if (w.length > 4 && w.endsWith('ies')) w = w.slice(0, -3) + 'y';
  else if (w.length > 5 && w.endsWith('ing')) w = w.slice(0, -3);
  else if (w.length > 4 && /(ch|sh|x|ss)es$/.test(w)) w = w.slice(0, -2);
  else if (w.length > 3 && w.endsWith('s') && !w.endsWith('ss') && !w.endsWith('us')) w = w.slice(0, -1);
  return CANONICAL[w] || w;
}

export function tokens(norm: string): string[] {
  return norm.split(' ').filter(Boolean).map(stem);
}

/** Whole-phrase test on normalised text (works for ASCII; substring for Indic scripts). */
export function hasPhrase(norm: string, phrase: string): boolean {
  const p = normalize(phrase);
  if (!p) return false;
  if (!/^[a-z0-9 %:]+$/.test(p)) return norm.includes(p);
  return (` ${norm} `).includes(` ${p} `);
}

export function anyPhrase(norm: string, phrases: string[]): boolean {
  return phrases.some((p) => hasPhrase(norm, p));
}

const DAYS = /\b(monday|tuesday|wednesday|thursday|friday|saturday|sunday)\b/g;
export function titleCaseKey(key: string): string {
  const s = key.replace(/[_-]+/g, ' ').trim().replace(DAYS, (d) => d.charAt(0).toUpperCase() + d.slice(1));
  return s.charAt(0).toUpperCase() + s.slice(1);
}
