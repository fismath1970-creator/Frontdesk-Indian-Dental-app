// Safe browser storage (sandboxed iframes / private mode can throw on access).
const mem = new Map<string, string>();
export function safeLocalStorage(): Storage | null {
  try { const ls = window.localStorage; const k = '__fd_probe__'; ls.setItem(k, '1'); ls.removeItem(k); return ls; } catch { return null; }
}
export function getPref(key: string): string | null { const ls = safeLocalStorage(); return ls ? ls.getItem(key) : mem.get(key) ?? null; }
export function setPref(key: string, value: string) { const ls = safeLocalStorage(); if (ls) ls.setItem(key, value); else mem.set(key, value); }
