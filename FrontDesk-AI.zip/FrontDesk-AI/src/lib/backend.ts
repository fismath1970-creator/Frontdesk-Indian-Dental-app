// One interface for the UI, two implementations:
//  - server: Netlify Function + Netlify Blobs (shared by every patient and staff device)
//  - local:  the same ticket service running in this browser (localStorage) — demo/preview only
import clinicFile from '../data/clinic-data.json';
import type { ClinicData } from '../engine/types.ts';
import { LocalStorageKV, MemoryKV, type KV } from '../tickets/kv.ts';
import { createClinicStore, type ClinicRecord } from '../clinic/store.ts';
import { ValidationError, VersionConflictError } from '../tickets/errors.ts';
import { createTicketService } from '../tickets/service.ts';
import type { ChatMessage, ChatResponse, Ticket } from '../tickets/types.ts';
import { safeLocalStorage } from './storage.ts';

export interface Backend {
  mode: 'server' | 'local';
  storageLabel: string;
  chat(conversationId: string, message: string, clientMessageId: string, opts?: { noAI?: boolean; via?: 'quick' | 'typed' }): Promise<ChatResponse>;
  conversation(conversationId: string): Promise<ChatMessage[]>;
  tickets(): Promise<Ticket[]>;
  reply(ticketId: string, text: string, staffName: string, saveFaq?: boolean): Promise<Ticket & { savedFaqVersion?: number }>;
  clinic(): Promise<ClinicRecord>;
  saveClinic(data: unknown, baseVersion: number, staffName: string): Promise<ClinicRecord>;
  resetClinic(staffName: string): Promise<ClinicRecord>;
  setStatus(ticketId: string, status: 'closed' | 'open', staffName: string): Promise<Ticket>;
  assign(ticketId: string, staffName: string): Promise<Ticket>;
  decideBooking(ticketId: string, input: { decision: 'confirm' | 'reject'; date?: string; time?: string; note?: string; staffName: string }): Promise<Ticket>;
}

async function call<T>(path: string, init?: RequestInit, timeoutMs = 12000): Promise<T> {
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), timeoutMs);
  try {
    const res = await fetch(path, { ...init, signal: ctl.signal, headers: { 'content-type': 'application/json', ...(init?.headers || {}) } });
    const data = await res.json().catch(() => ({})) as { error?: string; details?: string[]; currentVersion?: number };
    if (res.status === 409 && typeof data.currentVersion === 'number') throw new VersionConflictError(data.currentVersion);
    if (!res.ok) throw new ValidationError(data.error || `HTTP ${res.status}`, data.details || []);
    return data as T;
  } finally { clearTimeout(timer); }
}

export function serverBackend(): Backend {
  const post = (_path: string, body: unknown) => ({ method: 'POST', body: JSON.stringify(body) });
  return {
    mode: 'server',
    storageLabel: 'Shared server storage (Netlify Blobs)',
    // 9 s client timeout covers the server's 6 s model limit; on any failure the UI answers from the clinic file
    chat: (conversationId, message, clientMessageId, o) => call<ChatResponse>('/api/chat', post('/api/chat', { conversationId, message, clientMessageId, noAI: !!o?.noAI, via: o?.via || 'typed' }), 9000),
    conversation: async (id) => (await call<{ messages: ChatMessage[] }>(`/api/conversation?id=${encodeURIComponent(id)}`)).messages,
    tickets: async () => (await call<{ tickets: Ticket[] }>('/api/tickets')).tickets,
    reply: async (id, text, staffName, saveFaq) => (await call<{ ticket: Ticket & { savedFaqVersion?: number } }>(`/api/tickets/${id}/reply`, post('', { text, staffName, saveFaq: !!saveFaq }))).ticket,
    clinic: async () => (await call<{ clinic: ClinicRecord }>('/api/clinic')).clinic,
    saveClinic: async (data, baseVersion, staffName) => (await call<{ clinic: ClinicRecord }>('/api/clinic', { method: 'PUT', body: JSON.stringify({ data, baseVersion, staffName }) })).clinic,
    resetClinic: async (staffName) => (await call<{ clinic: ClinicRecord }>('/api/clinic/reset', post('', { confirm: true, staffName }))).clinic,
    setStatus: async (id, status, staffName) => (await call<{ ticket: Ticket }>(`/api/tickets/${id}/status`, post('', { status, staffName }))).ticket,
    assign: async (id, staffName) => (await call<{ ticket: Ticket }>(`/api/tickets/${id}/assign`, post('', { staffName }))).ticket,
    decideBooking: async (id, input) => (await call<{ ticket: Ticket }>(`/api/tickets/${id}/booking`, post('', input))).ticket,
  };
}

let memKV: KV | null = null; // one in-memory store per page when browser storage is blocked
export function localBackend(): Backend {
  const ls = safeLocalStorage();
  const kv: KV = ls ? new LocalStorageKV(ls) : (memKV ||= new MemoryKV());
  return backendOn(kv, ls ? 'Local demo mode — this browser only' : 'Local demo mode — this tab only');
}
/** The same service code the server runs, on a given store (local demo mode and tests). */
export function backendOn(kv: KV, storageLabel = 'Local demo mode', now?: () => Date): Backend {
  const clinicStore = createClinicStore(kv, clinicFile as ClinicData, now);
  const svc = createTicketService({ kv, getClinic: () => clinicStore.get(), addFaq: (e, by) => clinicStore.addFaq(e, by), now });
  return {
    mode: 'local',
    storageLabel,
    chat: (conversationId, message, clientMessageId, o) => svc.handleChat({ conversationId, message, clientMessageId, noAI: !!o?.noAI, via: o?.via }),
    conversation: async (id) => (await svc.getConversation(id)).messages,
    tickets: () => svc.listTickets(),
    reply: (id, text, staffName, saveFaq) => svc.staffReply(id, { text, staffName, saveFaq: !!saveFaq }),
    clinic: () => clinicStore.get(),
    saveClinic: (data, baseVersion, staffName) => clinicStore.save(data, baseVersion, staffName),
    resetClinic: (staffName) => clinicStore.reset(staffName),
    setStatus: (id, status, staffName) => svc.setStatus(id, { status, staffName }),
    assign: (id, staffName) => svc.assign(id, { staffName }),
    decideBooking: (id, input) => svc.decideBooking(id, input),
  };
}

async function serverAvailable(): Promise<boolean> {
  for (let i = 0; i < 2; i++) {
    try {
      const h = await call<{ ok?: boolean; service?: string }>('/api/health', undefined, 3500);
      if (h.ok && h.service === 'frontdesk') return true;
      return false; // something answered but it is not our API (e.g. static preview)
    } catch { /* retry once */ }
  }
  return false;
}

let chosen: Promise<Backend> | null = null;
export function getBackend(): Promise<Backend> {
  if (!chosen) chosen = (typeof fetch === 'function' && /^https?:$/.test(location.protocol) ? serverAvailable() : Promise.resolve(false))
    .then((ok) => (ok ? serverBackend() : localBackend()));
  return chosen;
}
/** tests only */
export function setBackendForTests(b: Backend | null) { chosen = b ? Promise.resolve(b) : null; }
