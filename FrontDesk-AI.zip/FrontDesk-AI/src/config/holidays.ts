// Default public-holiday calendar used for the 2-working-hour callback target.
// Source: Government of Telangana, G.O.Rt.No.1715 dated 06.12.2025 — General Holidays 2026 (Annexure-I).
// A clinic dataset may override this with `holidays: [{ "date": "YYYY-MM-DD", "name": "..." }]`.
// Staff will be able to edit the list in the Stage 5 clinic editor.
export interface Holiday { date: string; name: string }
export const DEFAULT_HOLIDAYS: Holiday[] = [
  { date: '2026-01-14', name: 'Bhogi' }, { date: '2026-01-15', name: 'Sankranti / Pongal' },
  { date: '2026-01-26', name: 'Republic Day' }, { date: '2026-02-15', name: 'Maha Shivaratri' },
  { date: '2026-03-03', name: 'Holi' }, { date: '2026-03-19', name: 'Ugadi' },
  { date: '2026-03-21', name: 'Eid-ul-Fitr (Ramzan)' }, { date: '2026-03-22', name: 'Following day of Ramzan' },
  { date: '2026-03-27', name: 'Sri Rama Navami' }, { date: '2026-04-03', name: 'Good Friday' },
  { date: '2026-04-05', name: "Babu Jagjivan Ram's Birthday" }, { date: '2026-04-14', name: "Dr B.R. Ambedkar's Birthday" },
  { date: '2026-05-27', name: 'Eid-ul-Azha (Bakrid)' }, { date: '2026-06-26', name: 'Shahadat Imam Hussain (10th Moharram)' },
  { date: '2026-08-10', name: 'Bonalu' }, { date: '2026-08-15', name: 'Independence Day' },
  { date: '2026-08-26', name: 'Eid Milad-un-Nabi' }, { date: '2026-09-04', name: 'Sri Krishna Astami' },
  { date: '2026-09-14', name: 'Vinayaka Chavithi' }, { date: '2026-10-02', name: 'Mahatma Gandhi Jayanthi' },
  { date: '2026-10-18', name: 'Saddula Bathukamma' }, { date: '2026-10-20', name: 'Vijaya Dasami / Dussehra' },
  { date: '2026-10-21', name: 'Following day of Vijaya Dasami' }, { date: '2026-11-08', name: 'Deepavali' },
  { date: '2026-11-24', name: "Kartika Purnima / Guru Nanak's Jayanthi" }, { date: '2026-12-25', name: 'Christmas' },
  { date: '2026-12-26', name: 'Following day of Christmas' },
];
