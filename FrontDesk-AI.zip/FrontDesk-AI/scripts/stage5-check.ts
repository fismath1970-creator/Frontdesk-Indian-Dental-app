// Stage 5 acceptance CHECK — real Chromium, production build, real Netlify function + Blobs emulator.
// Prints PASS/FAIL per check; exit code 1 if any check fails.   node scripts/stage5-check.ts
import { readFileSync } from 'node:fs';
import { chromium, type Page } from 'playwright-core';
import { startLocalNetlify } from './local-server.ts';

const results: Array<{ name: string; ok: boolean }> = [];
async function check(name: string, fn: () => Promise<string | void>) {
  try { const info = (await fn()) || ''; results.push({ name, ok: true }); console.log(`PASS  ${name}${info ? `  — ${info}` : ''}`); }
  catch (e) { results.push({ name, ok: false }); console.log(`FAIL  ${name}  — ${(e as Error).message.split('\n')[0].slice(0, 300)}`); }
}
const must = (c: unknown, m: string) => { if (!c) throw new Error(m); };
const DEV = /[\u0900-\u097F]/; const TEL = /[\u0C00-\u0C7F]/;
const claimsConfirmed = (s: string) => /confirmed|\bbooked\b/i.test(s.replace(/not a confirmed booking/gi, '').replace(/doctors available for booked patients/gi, ''));

const srv = await startLocalNetlify();
const browser = await chromium.launch();
const page = async (w = 390) => (await browser.newContext({ viewport: { width: w, height: 900 } })).newPage();
const lastBot = (p: Page) => p.locator('.bot-msg').last().innerText();
async function ask(p: Page, q: string) {
  const n = await p.locator('.bot-msg').count();
  await p.fill('#chat-input', q); await p.click('#chat-send');
  await p.waitForFunction((k) => document.querySelectorAll('.bot-msg').length > k, n);
  return lastBot(p);
}
async function structure(p: Page) {
  return p.evaluate(() => {
    const qr = document.getElementById('quick-replies');
    const bots = [...document.querySelectorAll('.bot-msg')];
    const last = bots.at(-1);
    return {
      exists: !!qr,
      insideBot: !!qr?.closest('.bot-msg') || document.querySelectorAll('.bot-msg .quick-reply, .bot-msg #quick-replies').length > 0,
      belowThread: !!(qr && last && (last.compareDocumentPosition(qr) & Node.DOCUMENT_POSITION_FOLLOWING)),
      chips: [...document.querySelectorAll('#quick-replies .quick-reply')].map((b) => ({ key: (b as HTMLElement).dataset.quick, label: b.textContent, href: b.getAttribute('href') })),
    };
  });
}
const istYmd = (d: Date) => new Date(d.getTime() + 330 * 60000).toISOString().slice(0, 10);
const shortDate = (ymd: string) => { const d = new Date(`${ymd}T00:00:00Z`); return `${['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][d.getUTCDay()]} ${d.getUTCDate()} ${d.toLocaleDateString('en-GB', { timeZone: 'UTC', month: 'short' })}`; };

const chat = await page();
await chat.goto(srv.url + '/');
await chat.waitForSelector('.patient[data-ready="true"]');
const staff = await page(1280);
await staff.goto(srv.url + '/staff');
await staff.waitForSelector('#ticket-queue');
const card = async (text: string) => { await staff.reload(); const c = staff.locator('[data-ticket]', { hasText: text }).first(); await c.waitFor({ timeout: 8000 }); return c; };

await check('1. "రూట్ కెనాల్ ధర ఎంత?" → Telugu reply with the exact price', async () => {
  const r = await ask(chat, 'రూట్ కెనాల్ ధర ఎంత?');
  must(TEL.test(r) && r.includes('Rs 6,500 to Rs 9,000'), r);
  const c = await card('రూట్ కెనాల్ ధర ఎంత?');
  must(await c.getAttribute('data-lang') === 'te' && (await c.innerText()).includes('తెలుగు · TE'), 'language badge');
  return `"${r.slice(0, 70)}" · staff badge తెలుగు · TE`;
});
await check('2. "आपका क्लिनिक कब खुलता है?" → Hindi reply with the exact hours', async () => {
  const r = await ask(chat, 'आपका क्लिनिक कब खुलता है?');
  must(DEV.test(r) && r.includes('9:00 am to 8:00 pm') && r.includes('10:00 am to 2:00 pm, emergencies only'), r);
  const label = await chat.locator('.source-tag').last().innerText();
  must(label.startsWith('Answered from the clinic file'), label);
  return `"${r.split('\n')[1]}" · label "${label}"`;
});
await check('3. "मेरा दांत बहुत दर्द कर रहा है" → Hindi medical refusal + booking offer, no medicine', async () => {
  const r = await ask(chat, 'मेरा दांत बहुत दर्द कर रहा है');
  must(DEV.test(r) && /दंत चिकित्सक/.test(r) && /अपॉइंटमेंट/.test(r) && !/पैरासिटामोल|paracetamol|ibuprofen|mg/i.test(r), r);
  const s = await structure(chat);
  must(s.chips.some((c) => c.label === 'अपॉइंटमेंट बुक करें'), `Hindi chips: ${JSON.stringify(s.chips.map((c) => c.label))}`);
  return 'chips switched to Hindi';
});
await check('4. "Book me tomorrow at 5pm" → booking ticket with the right date and time', async () => {
  const r = await ask(chat, 'Book me tomorrow at 5pm');
  const tomorrow = istYmd(new Date(Date.now() + 86400000));
  must(r.startsWith(`I've noted your request for ${shortDate(tomorrow)}, 5:00 PM.`), r);
  must(/This is a request, not a confirmed booking\. Our team will call you within 2 working hours to confirm\./.test(r) && !claimsConfirmed(r), r);
  const c = await card('Book me tomorrow at 5pm');
  const iso = await c.getAttribute('data-requested-time');
  must(iso === `${tomorrow}T17:00:00+05:30`, `data-requested-time=${iso}`);
  must(await c.getAttribute('data-status') === 'needs human' && await c.getAttribute('data-type') === 'booking', 'status/type');
  must((await c.innerText()).includes(`Requested: ${shortDate(tomorrow)}, 5:00 PM`), 'Requested label');
  const s = await structure(chat);
  must(s.chips[0]?.key === 'add-phone', `context chip: ${JSON.stringify(s.chips[0])}`);
  return `data-requested-time=${iso} · "Add my phone number" chip shown`;
});
await check('5. "Book Sunday 11am" → ticket flagged "Outside clinic hours" (Sunday is emergencies only)', async () => {
  const r = await ask(chat, 'Book Sunday 11am');
  must(/Sunday: 10:00 am to 2:00 pm, emergencies only/.test(r) && !claimsConfirmed(r), r);
  const c = await card('Book Sunday 11am');
  must(await c.getAttribute('data-outside-hours') === 'true' && (await c.innerText()).includes('Outside clinic hours'), 'flag missing');
  must(/T11:00:00\+05:30$/.test((await c.getAttribute('data-requested-time')) || ''), 'time');
  return `data-requested-time=${await c.getAttribute('data-requested-time')}`;
});

const fresh = await page();
await fresh.goto(srv.url + '/');
await fresh.waitForSelector('.patient[data-ready="true"]');
const EXPECT: Record<string, RegExp> = {
  timings: /9:00 am to 8:00 pm/, doctors: /Dr\. Meera Nair[\s\S]*Dr\. Sneha Rao/, prices: /Rs 28,000 per tooth/, insurance: /Star Health/,
  location: /Plot 21, Road No\. 12/, book: /not a confirmed booking[\s\S]*What day and time suits you\?/, human: /within 2 working hours/,
};
for (const key of ['timings', 'doctors', 'prices', 'insurance', 'location', 'book', 'human']) {
  await check(`6. Quick reply "${key}" → sent as a patient message; last .bot-msg is its answer; chips outside .bot-msg`, async () => {
    const btn = fresh.locator(`#quick-replies .quick-reply[data-quick="${key}"]`);
    const label = (await btn.innerText()).trim();
    const n = await fresh.locator('.bot-msg').count();
    await btn.click();
    await fresh.waitForFunction((k) => document.querySelectorAll('.bot-msg').length > k, n);
    const pm = (await fresh.locator('.patient-msg').last().innerText()).trim();
    must(pm === label, `patient message "${pm}" ≠ label "${label}"`);
    const r = await lastBot(fresh);
    must(EXPECT[key].test(r), `answer: ${r.slice(0, 160)}`);
    const s = await structure(fresh);
    must(s.exists && !s.insideBot && s.belowThread, JSON.stringify(s));
    return `"${label}"`;
  });
}
await check('6b. "Talk to a human" → needs-human ticket of type human on /staff', async () => {
  const c = await card('Talk to a human');
  must(await c.getAttribute('data-status') === 'needs human' && await c.getAttribute('data-type') === 'human', `${await c.getAttribute('data-status')} / ${await c.getAttribute('data-type')}`);
});
await check('7. Context chips: UNKNOWN → "Share my phone number" + "Book an appointment"; phone flow joins the ticket', async () => {
  await ask(fresh, 'Do you do Invisalign?');
  let s = await structure(fresh);
  must(s.chips[0]?.key === 'phone' && s.chips[1]?.key === 'book', JSON.stringify(s.chips.slice(0, 3)));
  const n = await fresh.locator('.bot-msg').count();
  await fresh.click('#quick-replies [data-quick="phone"]');
  await fresh.waitForFunction((k) => document.querySelectorAll('.bot-msg').length > k, n);
  must(/please type your name and phone number/.test(await lastBot(fresh)), await lastBot(fresh));
  const r = await ask(fresh, 'Ravi Kumar 98765 43210');
  must(/added your contact details/.test(r), r);
  const c = await card('Do you do Invisalign?');
  must((await c.innerText()).includes('98765 43210'), 'phone not on the Invisalign ticket');
  s = await structure(fresh);
  return 'phone added to the same needs-human ticket';
});
await check('8. Context chip after an emergency: tel: link to the emergency number', async () => {
  const r = await ask(fresh, 'నా ముఖం వాచింది, ఊపిరి ఆడటం లేదు');
  must(r.split('\n')[0].includes('98000 00123') && TEL.test(r), `first line: ${r.split('\n')[0]}`);
  const s = await structure(fresh);
  must(s.chips[0]?.key === 'call' && s.chips[0]?.href === 'tel:9800000123', JSON.stringify(s.chips[0]));
  must(s.chips.some((c) => c.label === 'సమయాలు'), 'chips not in Telugu');
  return `first line "${r.split('\n')[0]}" · chip ${s.chips[0].href}`;
});
await check('9. Hindi chip works end-to-end ("कीमतें" → Hindi price list)', async () => {
  await ask(fresh, 'नमस्ते');
  const n = await fresh.locator('.bot-msg').count();
  await fresh.click('#quick-replies [data-quick="prices"]');
  await fresh.waitForFunction((k) => document.querySelectorAll('.bot-msg').length > k, n);
  const r = await lastBot(fresh);
  must((await fresh.locator('.patient-msg').last().innerText()) === 'कीमतें' && DEV.test(r) && r.includes('Rs 6,500 to Rs 9,000'), r.slice(0, 120));
});
await check('10. Stage 1 samples via ?q= still pass (last .bot-msg is the answer)', async () => {
  const samples = JSON.parse(readFileSync(new URL('../src/data/sample-questions.json', import.meta.url), 'utf8'));
  for (const sq of samples) {
    const p = await page(); await p.goto(`${srv.url}/?q=${encodeURIComponent(sq.q)}`); await p.waitForSelector('.bot-msg');
    const r = await lastBot(p);
    for (const i of sq.must_include || []) must(r.includes(i), `${sq.q}: missing ${i}`);
    for (const x of sq.must_not_include || []) must(!r.toLowerCase().includes(x.toLowerCase()), `${sq.q}: has ${x}`);
    must((await structure(p)).insideBot === false, 'chips inside bot-msg');
    await p.context().close();
  }
  return '8/8';
});

await browser.close(); await srv.close();
const failed = results.filter((r) => !r.ok).length;
console.log(`\n${results.length - failed}/${results.length} checks PASS${failed ? ` — ${failed} FAIL` : ''}`);
process.exit(failed ? 1 : 0);
