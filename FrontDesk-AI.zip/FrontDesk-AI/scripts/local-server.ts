// Local stand-in for Netlify: serves dist/ with SPA fallback and routes /api/* to the
// REAL netlify/functions/api.mts handler, whose @netlify/blobs client talks to the
// official BlobsServer emulator (files under a temp dir). Used by API + browser tests.
//   node scripts/local-server.ts [port]
import { createServer, type Server } from 'node:http';
import { mkdtempSync, readFileSync, existsSync, statSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, extname, normalize } from 'node:path';
import { BlobsServer } from '@netlify/blobs/server';

const MIME: Record<string, string> = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon' };

export async function startLocalNetlify(opts: { port?: number; dist?: string; blobsDir?: string } = {}) {
  const blobsDir = opts.blobsDir || mkdtempSync(join(tmpdir(), 'fd-blobs-'));
  const token = 'local-test-token';
  const blobs = new BlobsServer({ directory: blobsDir, token });
  const { port: blobsPort } = await blobs.start();
  process.env.NETLIFY_BLOBS_CONTEXT = Buffer.from(JSON.stringify({ edgeURL: `http://localhost:${blobsPort}`, uncachedEdgeURL: `http://localhost:${blobsPort}`, siteID: 'local-site', token })).toString('base64');
  const fn = (await import('../netlify/functions/api.mts')).default as (req: Request) => Promise<Response>;
  const dist = opts.dist || new URL('../dist/', import.meta.url).pathname;

  const server: Server = createServer(async (req, res) => {
    try {
      const url = new URL(req.url || '/', `http://${req.headers.host}`);
      if (url.pathname.startsWith('/api/') || url.pathname === '/api') {
        const chunks: Buffer[] = [];
        for await (const c of req) chunks.push(c as Buffer);
        const r = await fn(new Request(url, { method: req.method, headers: req.headers as Record<string, string>, body: ['GET', 'HEAD'].includes(req.method || 'GET') ? undefined : Buffer.concat(chunks) }));
        res.writeHead(r.status, Object.fromEntries(r.headers));
        res.end(Buffer.from(await r.arrayBuffer()));
        return;
      }
      let file = join(dist, normalize(url.pathname).replace(/^(\.\.[/\\])+/, ''));
      if (!existsSync(file) || statSync(file).isDirectory()) file = join(dist, 'index.html'); // SPA fallback (= netlify.toml rule)
      res.writeHead(200, { 'content-type': MIME[extname(file)] || 'application/octet-stream' });
      res.end(readFileSync(file));
    } catch (e) { res.writeHead(500); res.end(String(e)); }
  });
  await new Promise<void>((r) => server.listen(opts.port || 0, r));
  const port = (server.address() as { port: number }).port;
  return { url: `http://localhost:${port}`, blobsDir, close: async () => { server.close(); await blobs.stop(); } };
}

if (import.meta.url === `file://${process.argv[1]}`) {
  const s = await startLocalNetlify({ port: Number(process.argv[2]) || 8888 });
  console.log(`FrontDesk AI local Netlify emulation on ${s.url}  (blobs: ${s.blobsDir})`);
}
