// Stage 4 acceptance CHECK — real Chromium, production build, real Netlify function + Blobs emulator.
// Prints PASS/FAIL per check; exit code 1 if any check fails.   node scripts/stage4-check.ts
import { chromium, type Page } from 'playwright-core';
import { startLocalNetlify } from './local-server.ts';

const results: Array<{ name: string; ok: boolean; info: string }> = [];
async function check(name: string, fn: () => Promise<string | void>) {
  try { const info = (await fn()) || ''; results.push({ name, ok: true, info }); console.log(`PASS  ${name}${info ? `  — ${info}` : ''}`); }
  catch (e) { results.push({ name, ok: false, info: (e as Error).message }); console.log(`FAIL  ${name}  — ${(e as Error).message.split('\n')[0]}`); }
}
const must = (cond: unknown, msg: string) => { if (!cond) throw new Error(msg); };

const srv = await startLocalNetlify();
const browser = await chromium.launch();
const nativeDialogs: string[] = [];
const page = async (w = 1280) => { const p = await (await browser.newContext({ viewport: { width: w, height: 900 } })).newPage(); p.on('dialog', (d) => { nativeDialogs.push(d.message()); void d.dismiss(); }); return p; };
const lastBot = (p: Page) => p.locator('.bot-msg').last().innerText();
async function ask(p: Page, q: string) {
  const n = await p.locator('.bot-msg').count();
  await p.fill('#chat-input', q); await p.click('#chat-send');
  await p.waitForFunction((k) => document.querySelectorAll('.bot-msg').length > k, n);
  return lastBot(p);
}
const clinicVersion = async () => ((await (await fetch(`${srv.url}/api/clinic`)).json()) as { clinic: { version: number } }).clinic.version;
async function save(staff: Page) {
  const v = await clinicVersion();
  await staff.click('#clinic-save');
  await staff.waitForFunction((x) => document.querySelector('[data-testid="clinic-saved"]')?.textContent?.includes(`Clinic file v${x + 1} - saved`), v, { timeout: 8000 });
  return (await staff.locator('[data-testid="clinic-saved"]').innerText()).trim();
}

// already-open patient chat tab (never reloaded during the checks)
const chat = await page(390);
await chat.goto(srv.url + '/');
await chat.waitForSelector('.patient[data-ready="true"]');
const staff = await page();
await staff.goto(srv.url + '/staff');
await staff.waitForSelector('#ticket-queue');

await check('Ticket queue is the default /staff view; Clinic file is a separate tab', async () => {
  must(await staff.locator('#ticket-queue').isVisible(), 'queue not visible by default');
  must(await staff.locator('#clinic-json').count() === 0, 'editor shown before choosing the tab');
  await staff.click('[data-tab="clinic"]');
  await staff.waitForSelector('#clinic-json', { state: 'attached' });
  must(await staff.locator('#clinic-save').count() === 1, '#clinic-save missing');
  return (await staff.locator('[data-testid="clinic-version"]').innerText()).trim();
});

await check('1. Root canal price → "Rs 7,500" appears in the ALREADY-OPEN chat tab; old message unchanged', async () => {
  const before = await ask(chat, 'how much is root canal?');
  must(before.includes('6,500'), `baseline: ${before}`);
  await staff.locator('[data-service-row="Root canal treatment"] [data-service-field="price"]').fill('Rs 7,500');
  const saved = await save(staff);
  const after = await ask(chat, 'how much is root canal?');
  must(after.includes('Rs 7,500') && !after.includes('6,500'), `after edit: ${after}`);
  const first = await chat.locator('.bot-msg').first().innerText();
  must(first.includes('6,500'), 'the earlier answer was rewritten');
  return `${saved}; reply: "${after.replace(/\n/g, ' ').slice(0, 70)}"`;
});

await check('2. Delete Dr. Imran (file name: Dr. Imran Qureshi, orthodontist) → "Who is your orthodontist?" goes UNKNOWN, ticket opens', async () => {
  await staff.locator('[data-doctor-row="Dr. Imran Qureshi"] [data-action="delete-doctor"]').click();
  await save(staff);
  const r = await ask(chat, 'Who is your orthodontist?');
  must(/can't confirm an orthodontist/.test(r) && /2 working hours/.test(r) && !/Imran/.test(r), r);
  await staff.click('[data-tab="queue"]');
  const card = staff.locator('[data-ticket]', { hasText: 'Who is your orthodontist?' });
  await card.waitFor({ timeout: 8000 });
  must(await card.getAttribute('data-status') === 'needs human', `status ${await card.getAttribute('data-status')}`);
  await staff.click('[data-tab="clinic"]');
  return 'ticket status: needs human';
});

await check('2b. Endodontist (root canals = Dr. Meera Nair in the file): answered while listed; UNKNOWN after deleting her', async () => {
  const r1 = await ask(chat, 'Who is your endodontist?');
  must(/Meera Nair/.test(r1), r1);
  await staff.locator('[data-doctor-row="Dr. Meera Nair"] [data-action="delete-doctor"]').click();
  await save(staff);
  const r2 = await ask(chat, 'Who is your endodontist?');
  must(/can't confirm an endodontist/.test(r2) && !/Meera/.test(r2), r2);
  return 'before: Dr. Meera Nair · after delete: needs human';
});

await check('3. Change Saturday closing time (split Mon–Sat row, Saturday 9:00 am–6:00 pm) → timings answer uses it', async () => {
  const row = staff.locator('[data-hours-row="monday_to_saturday"]');
  await row.locator('[data-hours-field="key"]').fill('monday_to_friday');
  await staff.click('[data-action="add-hours"]');
  const nr = staff.locator('[data-hours-row=""]').last();
  await nr.locator('[data-hours-field="key"]').fill('saturday');
  const sat = staff.locator('[data-hours-row="saturday"]');
  await sat.locator('[data-hours-field="open"]').fill('09:00');
  await sat.locator('[data-hours-field="close"]').fill('18:00');
  await save(staff);
  const r = await ask(chat, 'What time do you open on Saturday?');
  must(r.includes('9:00 am to 6:00 pm'), r);
  const f = await ask(chat, 'Are you open on Friday?');
  must(f.includes('9:00 am to 8:00 pm'), f);
  const all = await ask(chat, 'What are your timings?');
  must(all.includes('Saturday: 9:00 am to 6:00 pm') && all.includes('Monday to Friday: 9:00 am to 8:00 pm'), all);
  return `"${r.split('.')[0]}"`;
});

await check('3b. "Open now" badge in the already-open chat reflects the edited file (no reload)', async () => {
  await staff.locator('[data-field="clinic.name"]').fill('Bright Roots Dental Care');
  await save(staff);
  await chat.waitForFunction(() => document.querySelector('.brand-name')?.textContent === 'Bright Roots Dental Care', null, { timeout: 12000 });
  const badge = await chat.locator('[data-open-state]').innerText();
  must(badge.length > 0, 'badge missing');
  await staff.locator('[data-field="clinic.name"]').fill('Bright Roots Dental');
  await save(staff);
  return `chat header updated by polling; badge "${badge}"`;
});

const ANSWER = 'Yes, we do clear aligners. Cost is confirmed at consultation.';
await check('4. Unknown question → staff reply with "Also save this reply as an FAQ" → NEW conversation answered from Staff FAQ', async () => {
  const r = await ask(chat, 'Do you do clear aligners?');
  must(/can't confirm/.test(r), `expected UNKNOWN first: ${r}`);
  await staff.click('[data-tab="queue"]');
  const card = staff.locator('[data-ticket]', { hasText: 'Do you do clear aligners?' });
  await card.waitFor({ timeout: 8000 });
  must(await card.getAttribute('data-status') === 'needs human', 'not needs human');
  await card.locator('#staff-reply').fill(ANSWER);
  await card.locator('[data-action="save-faq"]').check();
  await card.locator('#staff-send').click();
  await staff.waitForFunction(() => [...document.querySelectorAll('.fb-ok')].some((e) => /saved as an FAQ \(clinic file v\d+\)/.test(e.textContent || '')), null, { timeout: 8000 });
  const fresh = await page(390);
  await fresh.goto(srv.url + '/');
  await fresh.waitForSelector('.patient[data-ready="true"]');
  const ans = await ask(fresh, 'Do you do clear aligners?');
  must(ans.trim() === ANSWER, `got: ${ans}`);
  const label = await fresh.locator('.source-tag').last().innerText();
  must(label === 'Answered from the clinic file · Staff FAQ', `label: ${label}`); // final-stage rule 20: FAQ answers also carry the clinic-file label
  await fresh.context().close();
  const faq = ((await (await fetch(`${srv.url}/api/clinic`)).json()) as { clinic: { data: { faq: Array<{ q: string; a: string; from: string }> } } }).clinic.data.faq;
  must(faq.length === 1 && faq[0].q === 'Do you do clear aligners?' && faq[0].a === ANSWER && /^BR-/.test(faq[0].from), JSON.stringify(faq));
  return `verbatim answer, label "${label}", faq.from=${faq[0].from}`;
});

await check('4b. FAQ entries are editable and deletable in the editor', async () => {
  await staff.click('[data-tab="clinic"]');
  await staff.waitForSelector('[data-faq-row="0"]');
  await staff.locator('[data-faq-row="0"] [data-faq-field="a"]').fill(ANSWER + ' Ask for Dr. Rao.');
  await save(staff);
  const p = await page(390); await p.goto(srv.url + '/'); await p.waitForSelector('.patient[data-ready="true"]');
  must((await ask(p, 'Do you do clear aligners?')).endsWith('Ask for Dr. Rao.'), 'edited FAQ not used');
  await staff.locator('[data-faq-row="0"] [data-action="delete-faq"]').click();
  await save(staff);
  must(/can't confirm/.test(await ask(p, 'Do you do clear aligners?')), 'deleted FAQ still answered');
  await p.context().close();
  return 'edit used immediately; after delete → UNKNOWN again';
});

await check('5. Invalid JSON is blocked with an inline error and nothing is saved', async () => {
  const v = await clinicVersion();
  await staff.locator('.ce-advanced > summary').click();
  await staff.locator('#clinic-json').fill('{ "clinic": { "name": "Broken", ');
  await staff.click('#clinic-save');
  await staff.waitForSelector('[data-testid="clinic-errors"]');
  const err = await staff.locator('[data-testid="clinic-errors"]').innerText();
  must(/Invalid JSON/.test(err), err);
  must(await clinicVersion() === v, 'version changed');
  // valid JSON but a broken file (duplicate service, close before open) is also blocked
  const good = ((await (await fetch(`${srv.url}/api/clinic`)).json()) as { clinic: { data: Record<string, any> } }).clinic.data;
  good.services.push({ name: 'Consultation', price: 'Rs 1' }); good.hours.saturday = '6:00 pm to 9:00 am';
  await staff.locator('#clinic-json').fill(JSON.stringify(good));
  await staff.click('#clinic-save');
  await staff.waitForFunction(() => /unique/.test(document.querySelector('[data-testid="clinic-errors"]')?.textContent || ''));
  const err2 = await staff.locator('[data-testid="clinic-errors"]').innerText();
  must(/closing time must be later/.test(err2), err2);
  must(await clinicVersion() === v, 'version changed');
  const api = await fetch(`${srv.url}/api/clinic`, { method: 'PUT', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ data: good, baseVersion: v }) });
  must(api.status === 400, `API accepted a broken file (${api.status})`);
  await staff.getByText('Discard JSON edits').click();
  return `"${err.split('\n')[1]?.slice(0, 60)}…"; server also returns 400`;
});

await check('6. Reset to original uses an inline two-step confirm (no confirm()/alert())', async () => {
  const v = await clinicVersion();
  await staff.click('[data-action="reset-clinic"]');
  must(await clinicVersion() === v, 'reset happened on the first click');
  await staff.click('[data-action="reset-confirm"]');
  await staff.waitForFunction((x) => document.querySelector('[data-testid="clinic-saved"]')?.textContent?.includes(`v${x + 1}`), v);
  must(nativeDialogs.length === 0, `native dialogs used: ${nativeDialogs.join(',')}`);
  const rr = await ask(chat, 'how much is root canal?'); must(rr.includes('6,500'), `original price not back: ${rr} | api: ${JSON.stringify(((await (await fetch(`${srv.url}/api/clinic`)).json()) as any).clinic.data.services[3])} v${await clinicVersion()}`);
  return `v${v} → v${v + 1}, original price back in the open chat tab`;
});

await check('Stage 1 selectors still present', async () => {
  for (const sel of ['#chat-input', '#chat-send']) must(await chat.locator(sel).count() === 1, sel);
  await staff.click('[data-tab="queue"]');
  const n = await staff.locator('#ticket-queue [data-ticket]').count();
  must(n > 0 && await staff.locator('#ticket-queue [data-ticket] #staff-reply').count() === n && await staff.locator('#ticket-queue [data-ticket] #staff-send').count() === n, 'per-ticket controls');
  return `${n} tickets, each with #staff-reply + #staff-send`;
});

await browser.close(); await srv.close();
const failed = results.filter((r) => !r.ok).length;
console.log(`\n${results.length - failed}/${results.length} checks PASS${failed ? ` — ${failed} FAIL` : ''}`);
process.exit(failed ? 1 : 0);
