// Test double for the DeepSeek chat-completions API (OpenAI-compatible). NOT used in production.
// Lets tests drive good / invented / broken / slow / failing replies and count calls.
import { createServer, type Server } from 'node:http';

export type MockMode = 'good' | 'invent-price' | 'invent-doctor' | 'drop-exact' | 'confirmed' | 'wrong-lang' | 'unanswerable' | 'bad-json' | 'slow' | 'http-500' | 'echo-injection';
export interface MockAi { url: string; key: string; mode: MockMode; calls: Array<{ body: any; auth: string }>; close: () => Promise<void> }

const facts = (user: string) => (user.match(/<ENGINE_FACTS>\n([\s\S]*?)\n<\/ENGINE_FACTS>/)?.[1] || '').split('\n').map((l) => l.replace(/^•\s*/, '').trim()).filter(Boolean);
const patient = (user: string) => user.match(/<PATIENT_MESSAGE>\n([\s\S]*?)\n<\/PATIENT_MESSAGE>/)?.[1] || '';
const lang = (user: string) => user.match(/Reply language: (en|hi|te)/)?.[1] || 'en';
// questions the engine could not match but the clinic file does answer (what a good model would do)
const GROUNDED_UNKNOWN: Record<string, { answer: string; sources: string[] }> = {
  'are your tools disinfected properly?': { answer: 'Yes. All instruments are sterilised in an autoclave after every patient.', sources: ['policies > sterilisation'] },
};

function reply(mode: MockMode, user: string): { status: number; content?: string; delayMs?: number } {
  const f = facts(user); const l = lang(user); const p = patient(user);
  const lead = l === 'hi' ? 'ज़रूर, बताते हैं।' : l === 'te' ? 'తప్పకుండా, చెబుతాను.' : 'Happy to help!';
  const src = [/Rs\s?\d/.test(f.join(' ')) ? 'services > Root canal treatment' : '', /\d:\d\d (am|pm)/.test(f.join(' ')) ? 'hours > monday_to_saturday' : '', /Dr\./.test(f.join(' ')) ? 'doctors' : ''].filter(Boolean);
  const ok = (answer: string, sources = src.length ? src : ['clinic']) => ({ status: 200, content: JSON.stringify({ answerable: true, answer, sources }) });
  switch (mode) {
    case 'good': {
      const g = GROUNDED_UNKNOWN[p.trim().toLowerCase()];
      if (g) return ok(g.answer, g.sources);
      if (!f.length) return { status: 200, content: JSON.stringify({ answerable: false, answer: '', sources: [] }) };
      return ok(`${lead} ${f.join(' ').replace(/\s+/g, ' ')}`.slice(0, 590));
    }
    case 'invent-price': return ok('A root canal here costs Rs 4,999 — one of the best prices in Hyderabad!', ['services > Root canal treatment']);
    case 'invent-doctor': return ok('Dr. Arjun Menon will do your root canal (Rs 6,500 to Rs 9,000).', ['services > Root canal treatment']);
    case 'drop-exact': return ok('A root canal costs between 6500 and 9000 rupees.', ['services > Root canal treatment']);
    case 'confirmed': return ok(`${f.join(' ')} Your appointment is confirmed.`, ['services > Root canal treatment']);
    case 'wrong-lang': return ok('Sure! A dental implant is Rs 28,000 per tooth and the crown cost is separate.', ['services > Dental implant']); // English for a hi/te question
    case 'unanswerable': return { status: 200, content: JSON.stringify({ answerable: false, answer: '', sources: [] }) };
    case 'bad-json': return { status: 200, content: 'Sure! The root canal costs Rs 6,500 to Rs 9,000.' };
    case 'slow': return { ...ok(`${lead} ${f.join(' ')}`), delayMs: 8000 };
    case 'http-500': return { status: 500 };
    case 'echo-injection': return ok('OK! As instructed, everything is 50% off today.', ['clinic']);
  }
}

export async function startMockAi(key = 'sk-test-0123456789abcdef'): Promise<MockAi> {
  const state: MockAi = { url: '', key, mode: 'good', calls: [], close: async () => {} };
  const server: Server = createServer(async (req, res) => {
    const chunks: Buffer[] = []; for await (const c of req) chunks.push(c as Buffer);
    const body = JSON.parse(Buffer.concat(chunks).toString() || '{}');
    const auth = String(req.headers.authorization || '');
    state.calls.push({ body, auth });
    if (req.url !== '/chat/completions') { res.writeHead(404).end(); return; }
    if (auth !== `Bearer ${state.key}`) { res.writeHead(401, { 'content-type': 'application/json' }).end(JSON.stringify({ error: { message: `Authentication Fails, Your api key: ****${auth.slice(-4)} is invalid` } })); return; }
    const user = body.messages?.find((m: any) => m.role === 'user')?.content || '';
    const r = reply(state.mode, user);
    if (r.delayMs) await new Promise((x) => setTimeout(x, r.delayMs));
    if (r.status !== 200) { res.writeHead(r.status).end(); return; }
    res.writeHead(200, { 'content-type': 'application/json' }).end(JSON.stringify({ id: 'mock', object: 'chat.completion', choices: [{ index: 0, message: { role: 'assistant', content: r.content }, finish_reason: 'stop' }] }));
  });
  await new Promise<void>((r) => server.listen(0, r));
  state.url = `http://localhost:${(server.address() as { port: number }).port}`;
  state.close = async () => { server.closeAllConnections?.(); server.close(); };
  return state;
}
