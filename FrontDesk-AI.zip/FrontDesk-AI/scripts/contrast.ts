// In-page WCAG contrast scan (text vs. real composited background, gradients = worst stop).
export const CONTRAST_JS = `(() => {
  const parse = (c) => { const m = c.match(/rgba?\\(([^)]+)\\)/); if (!m) return null; const p = m[1].split(/[ ,\\/]+/).filter(Boolean).map(Number); return { r: p[0], g: p[1], b: p[2], a: p.length > 3 ? p[3] : 1 }; };
  const over = (t, b) => ({ r: t.r * t.a + b.r * (1 - t.a), g: t.g * t.a + b.g * (1 - t.a), b: t.b * t.a + b.b * (1 - t.a), a: 1 });
  const lum = (c) => { const f = (v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }; return 0.2126 * f(c.r) + 0.7152 * f(c.g) + 0.0722 * f(c.b); };
  const ratio = (a, b) => { const x = lum(a), y = lum(b); return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05); };
  const bgCandidates = (el) => {
    const layers = []; let e = el;
    for (; e; e = e.parentElement) {
      const cs = getComputedStyle(e);
      if (cs.backgroundImage && cs.backgroundImage.includes('gradient')) { const stops = (cs.backgroundImage.match(/rgba?\\([^)]+\\)/g) || []).map(parse).filter(Boolean); if (stops.length) return stops.map((s) => layers.reduceRight((acc, l) => over(l, acc), { ...s, a: 1 })); }
      const bc = parse(cs.backgroundColor); if (bc && bc.a > 0) { layers.push(bc); if (bc.a >= 1) break; }
    }
    const base = layers.length && layers[layers.length - 1].a >= 1 ? layers.pop() : { r: 255, g: 255, b: 255, a: 1 };
    return [layers.reduceRight((acc, l) => over(l, acc), base)];
  };
  const out = [];
  const seen = new Set();
  for (const el of document.querySelectorAll('body *')) {
    if (el.closest('svg, [aria-hidden="true"], script, style, #demo-switch')) continue;
    const text = [...el.childNodes].filter((n) => n.nodeType === 3).map((n) => n.textContent).join('').trim();
    const isField = el.matches('input:not([type=checkbox]):not([type=date]):not([type=time]), textarea, select') && (el.value || '').trim();
    if (!text && !isField) continue;
    if (el.disabled || el.closest('[disabled]')) continue;
    const r = el.getBoundingClientRect(); const cs = getComputedStyle(el);
    if (!r.width || !r.height || cs.visibility === 'hidden' || cs.display === 'none') continue;
    if (/^[\\u{1F300}-\\u{1FAFF}\\u2600-\\u27BF\\s•·✓⚠️✅🚨]+$/u.test(text)) continue; // emoji-only icons
    const fg = parse(cs.color); if (!fg) continue;
    const worst = Math.min(...bgCandidates(el).map((bg) => ratio(over(fg, bg), bg)));
    const key = el.tagName + '.' + el.className + '|' + (text || el.value).slice(0, 30);
    if (worst < 4.5 && !seen.has(key)) { seen.add(key); out.push({ el: (el.id ? '#' + el.id : el.tagName.toLowerCase()) + (typeof el.className === 'string' && el.className ? '.' + el.className.trim().split(/\\s+/).join('.') : ''), text: (text || el.value).slice(0, 40), ratio: Math.round(worst * 100) / 100, color: cs.color }); }
  }
  return out;
})()`;
