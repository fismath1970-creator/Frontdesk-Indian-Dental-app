// Netlify Function: all /api/* routes. Storage = Netlify Blobs (strong consistency).
import { getStore } from '@netlify/blobs';
import { handleApi } from '../../src/server/router.ts';
import { BlobsKV } from '../../src/server/blobsKV.ts';
import { ORIGINAL_CLINIC } from '../../src/server/clinic.ts';
import { createClinicStore } from '../../src/clinic/store.ts';
import { createTicketService } from '../../src/tickets/service.ts';
import { askModel } from '../../src/ai/answer.ts';
import { readAiEnv } from '../../src/ai/provider.ts';
import { allow, clientIp } from '../../src/ai/ratelimit.ts';

export default async (req: Request) => {
  // getStore() is called fresh per request: Netlify issues a short-lived Blobs token per invocation.
  const kv = new BlobsKV(getStore({ name: 'frontdesk', consistency: 'strong' }) as never);
  const clinic = createClinicStore(kv, ORIGINAL_CLINIC);
  const ip = clientIp(req);
  const svc = createTicketService({
    kv,
    getClinic: () => clinic.get(), // read from the store on EVERY message
    addFaq: (entry, by) => clinic.addFaq(entry, by),
    // AI_API_KEY / AI_MODEL are read from the server environment on every call — never sent to the browser
    ai: async (input) => {
      const env = readAiEnv();
      if (!env.apiKey) return { kind: 'fallback', reason: 'no_key' };
      if (!allow(ip)) return { kind: 'fallback', reason: 'rate_limited' };
      return askModel(env, input);
    },
  });
  return handleApi(req, svc, { storage: 'netlify-blobs' }, clinic, () => readAiEnv());
};

export const config = { path: '/api/*' };
