// @vitest-environment jsdom
// Stage 3 — dashboard: ageing indicators, priority, sorting, booking/overdue filters, approve/reject.
import { afterEach, beforeEach, describe, expect, test } from 'vitest';
import { cleanup, fireEvent, render, waitFor } from '@testing-library/react';
import { App } from '../src/App.tsx';
import { backendOn, setBackendForTests, type Backend } from '../src/lib/backend.ts';
import { MemoryKV } from '../src/tickets/kv.ts';

const IST = (s: string) => new Date(`${s}+05:30`);
let clock = IST('2026-11-17T09:00:00').getTime();
function clockBackend(): Backend { return backendOn(new MemoryKV(), 'test', () => new Date(clock)); }
let be: Backend;
beforeEach(() => { localStorage.clear(); clock = IST('2026-11-17T09:00:00').getTime(); be = clockBackend(); setBackendForTests(be); window.history.replaceState({}, '', '/staff'); });
afterEach(() => { cleanup(); setBackendForTests(null); window.history.replaceState({}, '', '/'); });

const cards = () => [...document.querySelectorAll<HTMLElement>('#ticket-queue [data-ticket]')];
const card = (id: string) => document.querySelector<HTMLElement>(`[data-ticket="${id}"]`)!;
const select = (name: string) => document.querySelector<HTMLSelectElement>(`select[data-filter="${name}"]`)!;
async function seed() {
  const old = await be.chat('conv-old-00000001', 'Do you do Invisalign?', 'm-0000000000a1'); // 09:00
  clock += 30 * 60000;
  const book = await be.chat('conv-book-0000001', 'Book a root canal with Dr Meera on Saturday at 11am. I am Ravi Kumar, 98765 43210', 'm-0000000000a2'); // 09:30
  clock += 20 * 60000;
  const ans = await be.chat('conv-ans-00000001', 'How much is a root canal?', 'm-0000000000a3'); // 09:50
  clock += 5 * 60000;
  const em = await be.chat('conv-em-000000001', 'My face is swelling and I cannot breathe properly', 'm-0000000000a4'); // 09:55
  clock = IST('2026-11-17T11:30:00').getTime(); // Invisalign is now 150 working min old → overdue
  return { old, book, ans, em };
}
async function open(n: number) { render(<App />); await waitFor(() => expect(cards().length).toBe(n)); }

describe('ageing and priority indicators', () => {
  test('bands, minutes/hours waiting, created + last updated, priorities', async () => {
    const { old, book, ans, em } = await seed();
    await open(4);
    expect(card(old.ticketId!).dataset.ageBand).toBe('overdue');
    expect(card(old.ticketId!).dataset.priority).toBe('high');
    expect(card(old.ticketId!).textContent).toMatch(/Overdue/);
    expect(card(old.ticketId!).textContent).toMatch(/150 min \(2\.5 h\)/);
    expect(card(old.ticketId!).textContent).toMatch(/overdue by 30 min working time/);
    expect(card(book.ticketId!).dataset.ageBand).toBe('delayed'); // 120 min → but within target? (09:30→11:30 = 120 working)
    expect(card(ans.ticketId!).dataset.priority).toBe('low');
    expect(card(ans.ticketId!).dataset.ageBand).toBe('handled');
    expect(card(em.ticketId!).dataset.priority).toBe('critical');
    expect(card(em.ticketId!).textContent).toMatch(/not covered by the 2-hour callback promise/);
    for (const c of cards()) { expect(c.textContent).toMatch(/Created/); expect(c.textContent).toMatch(/Last updated/); expect(c.textContent).toMatch(/Waiting/); }
  });
  test('sorting: priority (default), oldest, newest — emergency always first', async () => {
    const { old, book, ans, em } = await seed();
    await open(4);
    expect(cards().map((c) => c.dataset.ticket)).toEqual([em.ticketId, old.ticketId, book.ticketId, ans.ticketId]);
    fireEvent.change(select('sort'), { target: { value: 'oldest' } });
    await waitFor(() => expect(cards().map((c) => c.dataset.ticket)).toEqual([em.ticketId, old.ticketId, book.ticketId, ans.ticketId]));
    fireEvent.change(select('sort'), { target: { value: 'newest' } });
    await waitFor(() => expect(cards().map((c) => c.dataset.ticket)).toEqual([em.ticketId, ans.ticketId, book.ticketId, old.ticketId]));
  });
  test('booking-request filter and overdue filter (+ stat cards)', async () => {
    const { old, book } = await seed();
    await open(4);
    const stat = (label: string) => [...document.querySelectorAll('.stat')].find((s) => s.textContent!.includes(label))!;
    expect(stat('Bookings awaiting decision').querySelector('.stat-value')!.textContent).toBe('1');
    expect(stat('Overdue callbacks').querySelector('.stat-value')!.textContent).toBe('1');
    fireEvent.change(select('type'), { target: { value: 'booking' } });
    await waitFor(() => expect(cards().map((c) => c.dataset.ticket)).toEqual([book.ticketId]));
    fireEvent.change(select('type'), { target: { value: 'all' } });
    fireEvent.change(select('ageing'), { target: { value: 'overdue' } });
    await waitFor(() => expect(cards().map((c) => c.dataset.ticket)).toEqual([old.ticketId]));
    fireEvent.change(select('ageing'), { target: { value: 'all' } });
    fireEvent.click(stat('Overdue callbacks'));
    await waitFor(() => expect(cards().map((c) => c.dataset.ticket)).toEqual([old.ticketId]));
  });
});

describe('booking panel: approve / reject', () => {
  test('shows request details and the four-state distinction; confirm sends confirmation to the patient', async () => {
    const { book } = await seed();
    await open(4);
    const c = card(book.ticketId!);
    const panel = c.querySelector<HTMLElement>('[data-booking-state]')!;
    expect(panel.dataset.bookingState).toBe('awaiting confirmation');
    expect(panel.textContent).toMatch(/Awaiting staff confirmation/);
    expect(panel.textContent).toMatch(/NOT confirmed/);
    expect(panel.textContent).toMatch(/Saturday, 21 Nov 2026/);
    expect(panel.textContent).toMatch(/11:00 am/);
    expect(panel.textContent).toMatch(/Root canal treatment/);
    expect(panel.textContent).toMatch(/Dr\. Meera Nair/);
    expect(c.dataset.status).toBe('needs human');
    fireEvent.click(c.querySelector('[data-action="confirm-booking"]')!);
    await waitFor(() => expect(card(book.ticketId!).querySelector<HTMLElement>('[data-booking-state]')!.dataset.bookingState).toBe('confirmed'));
    expect(card(book.ticketId!).textContent).toMatch(/Confirmed by staff/);
    expect(card(book.ticketId!).dataset.status).toBe('answered');
    const conv = await be.conversation('conv-book-0000001');
    expect(conv.at(-1)!.text).toMatch(/confirmed by our staff: Saturday, 21 Nov 2026 at 11:00 am with Dr\. Meera Nair/);
  });
  test('reject asks the patient to reschedule; the patient chat shows it with the right label', async () => {
    const { book } = await seed();
    await open(4);
    const c = card(book.ticketId!);
    fireEvent.change(c.querySelector('.booking-note')!, { target: { value: 'Dr. Meera is on leave that day.' } });
    fireEvent.click(c.querySelector('[data-action="reject-booking"]')!);
    await waitFor(() => expect(card(book.ticketId!).querySelector<HTMLElement>('[data-booking-state]')!.dataset.bookingState).toBe('rejected'));
    expect(card(book.ticketId!).textContent).toMatch(/Rejected — rescheduling required/);
    cleanup();
    localStorage.setItem('frontdesk.conversationId', 'conv-book-0000001');
    window.history.replaceState({}, '', '/');
    render(<App />);
    await waitFor(() => expect(document.querySelectorAll('.bot-msg').length).toBe(2));
    const last = [...document.querySelectorAll('.bot-msg')].at(-1)!;
    expect(last.textContent).toMatch(/can't confirm your requested time/);
    expect(last.textContent).toMatch(/Dr\. Meera is on leave/);
    expect(document.body.textContent).toMatch(/Rescheduling required/);
    expect(document.body.textContent).toMatch(/Appointment requested · awaiting staff confirmation/);
  });
  test('confirming without a date/time is blocked in the UI', async () => {
    const b = await be.chat('conv-vague-000001', 'I want to book an appointment', 'm-0000000000b1');
    await open(1);
    fireEvent.click(card(b.ticketId!).querySelector('[data-action="confirm-booking"]')!);
    await waitFor(() => expect(card(b.ticketId!).textContent).toMatch(/Set the confirmed date and time first/));
    expect(card(b.ticketId!).querySelector<HTMLElement>('[data-booking-state]')!.dataset.bookingState).toBe('requested');
    expect(card(b.ticketId!).textContent).toMatch(/Still missing: day, exact time, name, phone/);
  });
});
