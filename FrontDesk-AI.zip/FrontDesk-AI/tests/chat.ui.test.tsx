// @vitest-environment jsdom
// Drives the real <App/> through the exact competition selectors.
import { afterEach, describe, expect, test } from 'vitest';
import { act, cleanup, fireEvent, render, waitFor } from '@testing-library/react';
import { StrictMode } from 'react';
import { App } from '../src/App.tsx';
import samples from '../src/data/sample-questions.json';

afterEach(() => { cleanup(); window.history.replaceState({}, '', '/'); localStorage.clear(); });

const lastBot = () => { const all = document.querySelectorAll('.bot-msg'); return all[all.length - 1]?.textContent || ''; };

async function askViaUI(q: string, how: 'click' | 'enter' = 'click') {
  await waitFor(() => expect(document.querySelector('.patient[data-ready="true"]')).not.toBeNull());
  const input = document.querySelector<HTMLInputElement>('input#chat-input')!;
  const before = document.querySelectorAll('.bot-msg').length;
  fireEvent.change(input, { target: { value: q } });
  input.value = q;
  if (how === 'click') fireEvent.click(document.querySelector('button#chat-send')!);
  else fireEvent.submit(input.form!);
  await waitFor(() => expect(document.querySelectorAll('.bot-msg').length).toBe(before + 1));
  return lastBot();
}

describe('selectors', () => {
  test('input#chat-input and button#chat-send exist; no .bot-msg before a question', () => {
    render(<App />);
    expect(document.querySelector('input#chat-input')).not.toBeNull();
    expect(document.querySelector('button#chat-send')).not.toBeNull();
    expect(document.querySelectorAll('.bot-msg').length).toBe(0);
  });
});

describe('all 8 sample questions through the UI', () => {
  for (const s of samples as Array<{ q: string; must_include?: string[]; must_not_include?: string[] }>) {
    test(s.q, async () => {
      render(<App />);
      const text = await askViaUI(s.q);
      for (const i of s.must_include || []) expect(text).toContain(i);
      for (const x of s.must_not_include || []) expect(text.toLowerCase()).not.toContain(x.toLowerCase());
    });
  }
});

describe('interaction', () => {
  test('Enter key submits', async () => {
    render(<App />);
    expect(await askViaUI('How much is a root canal?', 'enter')).toContain('6,500');
  });
  test('last .bot-msg always answers the most recent question', async () => {
    render(<App />);
    await askViaUI('How much is a root canal?');
    const t = await askViaUI('What time do you open on Saturday?');
    expect(t).toContain('9:00 am'); expect(t).not.toContain('6,500');
  });
  test('emergency shows tap-to-call link to the clinic number', async () => {
    render(<App />);
    await askViaUI('My face is swelling and I cannot breathe properly');
    const link = document.querySelector('.bot-msg a[href^="tel:"]') as HTMLAnchorElement;
    expect(link.getAttribute('href')).toBe('tel:9800000123');
  });
  test('fallback label shown outside .bot-msg', async () => {
    render(<App />);
    const t = await askViaUI('Do you take Niva Bupa insurance?');
    expect(document.body.textContent).toContain('Answered from the clinic file');
    expect(t).not.toContain('Answered from the clinic file');
  });
});

describe('ask on page load (?q=)', () => {
  test('auto-submits exactly once, even under StrictMode', async () => {
    window.history.replaceState({}, '', '/?q=' + encodeURIComponent('What time do you open on Saturday?'));
    await act(async () => { render(<StrictMode><App /></StrictMode>); });
    await waitFor(() => expect(document.querySelectorAll('.bot-msg').length).toBe(1));
    await new Promise((r) => setTimeout(r, 50));
    expect(document.querySelectorAll('.bot-msg').length).toBe(1);
    expect(document.querySelectorAll('.patient-msg').length).toBe(1);
    expect(lastBot()).toContain('9:00 am');
    expect(lastBot()).toContain('8:00 pm');
  });
  test('/?q= with %3F and Invisalign escalates', async () => {
    window.history.replaceState({}, '', '/?q=Do%20you%20do%20Invisalign%3F');
    await act(async () => { render(<App />); });
    await waitFor(() => expect(document.querySelectorAll('.bot-msg').length).toBe(1));
    expect(lastBot()).toContain('2 working hours');
  });
});

describe('text extraction', () => {
  test('multi-line replies keep a separator in textContent', async () => {
    render(<App />);
    const t = await askViaUI('Which doctor sees children?');
    expect(t).not.toMatch(/only\.Children/);
    expect(t).toMatch(/Saturday only\.\s+Children/);
  });
});
