// Stage 3 — appointment requests, staff decisions, ticket ageing and priority.
import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { answerQuestion, getIndex } from '../src/engine/engine.ts';
import { resolveDate, resolveTime } from '../src/engine/datetime.ts';
import { addWorkingMinutes, buildCalendar, workingMinutesBetween } from '../src/engine/schedule.ts';
import { MemoryKV } from '../src/tickets/kv.ts';
import { createTicketService } from '../src/tickets/service.ts';
import { computeAgeing, computePriority, sortQueue } from '../src/tickets/sla.ts';
import type { ClinicData } from '../src/engine/types.ts';
import type { Ticket } from '../src/tickets/types.ts';

const load = (p: string) => JSON.parse(readFileSync(new URL(p, import.meta.url), 'utf8'));
const clinic: ClinicData = load('../src/data/clinic-data.json');
const hidden: ClinicData = load('./fixtures/hidden-clinic.json');
const IST = (s: string) => new Date(`${s}+05:30`); // wall-clock in Hyderabad
const NOW = IST('2026-11-17T11:30:00'); // Tuesday
const ask = (q: string, ctx = {}) => answerQuestion(q, clinic, { now: NOW, ...ctx });
const DOCTORS = ['Meera', 'Imran', 'Sneha'];
// "confirmed" may appear ONLY inside the disclaimer "not a confirmed appointment" / "staff will confirm"
const NO_STRAY_ESCALATION = /can't confirm the answer to that|part of your message/;
const claimsConfirmed = (s: string) => /confirmed/i.test(s.replace(/not a confirmed booking/gi, ''));
const INVENTED_AVAILABILITY = /\b(is|are) (free|available|open) (at|on|for)\b|\bslots? (is |are )?(free|available|open)\b|\bwe have (a )?(slot|opening)|\bsee you (on|at)\b|\byou('re| are) booked\b/i;

describe('date and time understanding (Asia/Kolkata)', () => {
  test('relative and explicit dates', () => {
    assert.equal(resolveDate('Saturday', NOW).ymd, '2026-11-21');
    assert.equal(resolveDate('tomorrow', NOW).ymd, '2026-11-18');
    assert.equal(resolveDate('today', NOW).ymd, '2026-11-17');
    assert.equal(resolveDate('next tuesday', NOW).ymd, '2026-11-24');
    assert.equal(resolveDate('tuesday', NOW).ymd, '2026-11-17');
    assert.equal(resolveDate('21 Nov', NOW).ymd, '2026-11-21');
    assert.equal(resolveDate('Dec 3rd', NOW).ymd, '2026-12-03');
    assert.equal(resolveDate('25/11/2026', NOW).ymd, '2026-11-25');
    assert.equal(resolveDate('1 Jan', NOW).ymd, '2027-01-01');
    assert.equal(resolveDate('16/11/2026', NOW).past, true);
    assert.equal(resolveDate('next week', NOW).vague, true);
  });
  test('times', () => {
    assert.equal(resolveTime('11am').hm, '11:00');
    assert.equal(resolveTime('4:30 pm').hm, '16:30');
    assert.equal(resolveTime('17:15').hm, '17:15');
    // Stage 5 rules: day parts are windows; a bare hour 1–7 means PM
    assert.deepEqual(resolveTime('morning').window, { part: 'morning', from: '09:00', to: '12:00' });
    assert.deepEqual(resolveTime('evening').window, { part: 'evening', from: '16:00', to: '20:00' });
    assert.equal(resolveTime('5').hm, '17:00'); assert.equal(resolveTime('7').hm, '19:00'); assert.equal(resolveTime('10').hm, '10:00');
  });
});

describe('appointment requests (engine)', () => {
  test('complete information → awaiting staff confirmation, nothing missing, never confirmed', () => {
    const r = ask('I would like to book a root canal with Dr Meera on Saturday at 11am. My name is Ravi Kumar, 98765 43210');
    const b = r.booking!;
    assert.equal(r.status, 'needs human'); assert.equal(r.ticketType, 'booking');
    assert.deepEqual([b.requestedDate, b.requestedTime, b.doctor, b.service, b.patientName, b.phone], ['2026-11-21', '11:00', 'Dr. Meera Nair', 'Root canal treatment', 'Ravi Kumar', '98765 43210']);
    assert.equal(b.state, 'awaiting confirmation'); assert.deepEqual(b.missing, []);
    assert.match(r.reply, /awaiting staff confirmation/); assert.match(r.reply, /not a confirmed booking/);
    assert.doesNotMatch(r.reply, /Please tell me/);
    assert.ok(!claimsConfirmed(r.reply)); assert.doesNotMatch(r.reply, INVENTED_AVAILABILITY);
    assert.doesNotMatch(r.reply, NO_STRAY_ESCALATION);
  });
  test('name + phone in a separate sentence do not trigger a stray "can\'t confirm" escalation', () => {
    for (const q of ['Book a root canal with Dr Imran on Monday at 1:45pm. I am Ravi Kumar, 98765 43210', 'Book a cleaning on Saturday at 11am. My name is Anu Reddy. 99000 11122']) {
      const r = ask(q);
      assert.doesNotMatch(r.reply, NO_STRAY_ESCALATION, q);
      assert.equal(r.unsupportedTopics.length, 0, q);
      assert.ok(r.booking!.phone, q);
    }
  });
  test('missing date → asks which day', () => {
    const r = ask('Please book a teeth cleaning at 5pm, I am Anu Reddy, 99000 11122');
    assert.equal(r.booking!.requestedTime, '17:00'); assert.equal(r.booking!.requestedDate, undefined);
    assert.deepEqual(r.booking!.missing, ['date']); assert.equal(r.booking!.state, 'requested');
    assert.match(r.reply, /What day suits you\?/);
  });
  test('missing time → asks what time', () => {
    const r = ask('I want an appointment for a filling on Friday');
    assert.equal(r.booking!.requestedDate, '2026-11-20'); assert.ok(r.booking!.missing!.includes('time'));
    assert.match(r.reply, /What time suits you\?/); assert.match(r.reply, /Please share your name and phone number/);
  });
  test('missing day and time → asks which day and time', () => {
    const r = ask('I want to book an appointment');
    assert.match(r.reply, /What day and time suits you/); assert.match(r.reply, /Which treatment is it for/);
  });
  test('day part ("Saturday morning") → stored as a 09:00–12:00 window (Stage 5)', () => {
    const r = ask('Can I book a cleaning on Saturday morning?');
    assert.deepEqual(r.booking!.requestedWindow, { part: 'morning', from: '09:00', to: '12:00' });
    assert.match(r.reply, /Sat 21 Nov, morning \(9:00 AM – 12:00 PM\)/); assert.doesNotMatch(r.reply, /What time suits you/);
  });
  test('preferred dentist recorded; listed-days conflict flagged from the clinic file', () => {
    const r = ask('Book me with Dr Imran on Monday at 10am for braces');
    assert.equal(r.booking!.doctor, 'Dr. Imran Qureshi');
    assert.match(r.reply, /Dr\. Imran Qureshi is not listed for Monday/);
    assert.ok(!claimsConfirmed(r.reply));
  });
  test('no preferred dentist → none invented', () => {
    const r = ask('I want to book a cleaning on Saturday at 10am');
    assert.equal(r.booking!.doctor, undefined);
    for (const d of DOCTORS) assert.ok(!r.reply.includes(d), `invented dentist ${d}`);
  });
  test('a patient whose name matches a dentist\'s name is NOT given that dentist', async () => {
    const r1 = ask('Book a cleaning on Saturday at 11am. I am Kiran Rao, 90000 12345');
    assert.equal(r1.booking!.doctor, undefined); assert.equal(r1.booking!.patientName, 'Kiran Rao');
    const r2 = ask('My name is Meera Iyer, please book a cleaning on Saturday at 11am, 90000 12346');
    assert.equal(r2.booking!.doctor, undefined);
    const pending = ask('I want to book a cleaning on Saturday at 11am').booking!;
    const r3 = ask('Kiran Rao 90000 12345', { pendingBooking: pending });
    assert.equal(r3.booking!.doctor, undefined); assert.equal(r3.booking!.patientName, 'Kiran Rao');
    for (const d of DOCTORS) assert.ok(!r3.reply.includes(d), `invented dentist ${d}`);
    // genuine preferences still work: first name, or a title with the surname
    assert.equal(ask('Book with Sneha on Saturday at 10am').booking!.doctor, 'Dr. Sneha Rao');
    assert.equal(ask('Book with Dr Rao on Saturday at 10am').booking!.doctor, 'Dr. Sneha Rao');
    assert.equal(ask('Book with doctor Nair on Friday at 10am').booking!.doctor, 'Dr. Meera Nair');
  });
  test('slot checks use LISTED hours, lunch break and public holidays', () => {
    assert.match(ask('Book a cleaning on Sunday at 11am').reply, /Sunday: 10:00 am to 2:00 pm, emergencies only/);
    assert.match(ask('Book a cleaning on 24 Nov at 11am').reply, /public holiday \(Kartika Purnima/);
    assert.match(ask('Book a cleaning on Saturday at 9pm').reply, /outside our listed hours/);
    assert.match(ask('Book a cleaning on Saturday at 1:45pm').reply, /lunch break/);
    assert.match(ask('Book a cleaning on 16/11/2026 at 11am').reply, /already passed/);
  });
  test('no invented appointment availability', () => {
    for (const q of ['Do you have any slots tomorrow?', 'Is Dr Meera free at 11am on Saturday?', 'What is the earliest available appointment?', 'Any openings this Saturday?']) {
      const r = ask(q);
      assert.equal(r.status, 'needs human', q);
      assert.match(r.reply, /can't see live appointment slots/, q);
      assert.doesNotMatch(r.reply, INVENTED_AVAILABILITY, q); assert.ok(!claimsConfirmed(r.reply), q);
    }
    // the doctor's LISTED days are still answered from the file
    assert.match(ask('Is Dr Imran available on Monday?').reply, /not listed for Monday/);
  });
});

const mk = (start = NOW, data = clinic) => {
  let clock = start.getTime();
  const kv = new MemoryKV();
  const svc = createTicketService({ kv, getClinic: () => ({ data, version: 1 }), now: () => new Date(clock) });
  return { svc, kv, advance: (min: number) => { clock += min * 60000; }, set: (d: Date) => { clock = d.getTime(); } };
};

describe('booking tickets and staff decisions', () => {
  test('details collected over several messages on ONE ticket; awaiting confirmation when complete', async () => {
    const { svc, advance } = mk();
    const a = await svc.handleChat({ message: 'I want to book an appointment' });
    advance(1); await svc.handleChat({ conversationId: a.conversationId, message: 'Saturday at 11am' });
    advance(1); await svc.handleChat({ conversationId: a.conversationId, message: 'Teeth cleaning please' });
    advance(1); await svc.handleChat({ conversationId: a.conversationId, message: 'It is for my mother, she is 70' });
    advance(1); const last = await svc.handleChat({ conversationId: a.conversationId, message: 'Lakshmi Rao 98480 22334' });
    const t = (await svc.getTicket(a.ticketId!))!;
    assert.equal((await svc.listTickets()).length, 1);
    assert.equal(t.status, 'needs human'); assert.match(t.id, /^BR-/);
    assert.deepEqual([t.booking!.requestedDate, t.booking!.requestedTime, t.booking!.service, t.patientName, t.phone], ['2026-11-21', '11:00', 'Teeth cleaning (scaling and polishing)', 'Lakshmi Rao', '98480 22334']);
    assert.deepEqual(t.booking!.notes, ['It is for my mother, she is 70']);
    assert.equal(t.booking!.state, 'awaiting confirmation');
    assert.match(last.messages[1].text, /awaiting staff confirmation/);
    for (const m of t.messages.filter((x) => x.sender === 'bot')) assert.ok(!claimsConfirmed(m.text), m.text);
  });
  test('staff APPROVE → confirmed by staff, shown in patient chat; status no longer needs human', async () => {
    const { svc, advance } = mk();
    const a = await svc.handleChat({ message: 'Book a root canal on Saturday at 11am. I am Ravi Kumar, 98765 43210' });
    advance(10);
    await assert.rejects(svc.decideBooking(a.ticketId, { decision: 'maybe' }), /confirm" or "reject/);
    const t = await svc.decideBooking(a.ticketId, { decision: 'confirm', staffName: 'Anita', note: 'Please arrive 10 minutes early.' });
    assert.equal(t.booking!.state, 'confirmed'); assert.equal(t.booking!.confirmedDate, '2026-11-21'); assert.equal(t.booking!.confirmedTime, '11:00');
    assert.equal(t.booking!.decidedBy, 'Anita'); assert.equal(t.status, 'answered'); assert.notEqual(t.status, 'closed');
    const conv = (await svc.getConversation(a.conversationId)).messages;
    const msg = conv.at(-1)!;
    assert.equal(msg.sender, 'staff'); assert.equal(msg.meta?.bookingDecision, 'confirmed');
    assert.match(msg.text, /confirmed by our staff: Saturday, 21 Nov 2026 at 11:00 am/); assert.match(msg.text, /arrive 10 minutes early/);
    assert.match(msg.text, /4 hours/); // appointment policy from the clinic file
  });
  test('staff can confirm a different date/time; confirm without a date or time is refused', async () => {
    const { svc } = mk();
    const a = await svc.handleChat({ message: 'I want to book an appointment' });
    await assert.rejects(svc.decideBooking(a.ticketId, { decision: 'confirm' }), /confirmed date/);
    const t = await svc.decideBooking(a.ticketId, { decision: 'confirm', date: '2026-11-19', time: '16:30' });
    assert.equal(t.booking!.confirmedDate, '2026-11-19');
    assert.match(t.messages.at(-1)!.text, /Thursday, 19 Nov 2026 at 4:30 pm/);
  });
  test('staff REJECT → rescheduling required; patient offers a new time on the same ticket → back to needs human', async () => {
    const { svc, advance } = mk();
    const a = await svc.handleChat({ message: 'Book a cleaning on Saturday at 11am. I am Ravi Kumar, 98765 43210' });
    advance(5);
    const t = await svc.decideBooking(a.ticketId, { decision: 'reject', note: 'Saturday is fully booked.' });
    assert.equal(t.booking!.state, 'rejected'); assert.equal(t.status, 'answered');
    assert.match(t.messages.at(-1)!.text, /can't confirm your requested time \(Saturday at 11am\)/);
    assert.match(t.messages.at(-1)!.text, /another day and time/);
    advance(5);
    const r = await svc.handleChat({ conversationId: a.conversationId, message: 'Monday at 4pm then' });
    assert.equal(r.ticketId, a.ticketId);
    const t2 = (await svc.getTicket(a.ticketId!))!;
    assert.equal(t2.booking!.state, 'awaiting confirmation'); assert.equal(t2.booking!.requestedDate, '2026-11-23');
    assert.equal(t2.status, 'needs human'); assert.equal(t2.booking!.decidedBy, undefined);
  });
  test('a plain staff reply does not settle a booking (stays needs human until approve/reject)', async () => {
    const { svc } = mk();
    const a = await svc.handleChat({ message: 'Book a cleaning on Saturday at 11am' });
    const t = await svc.staffReply(a.ticketId, { text: 'Thanks, checking the diary.' });
    assert.equal(t.status, 'needs human');
    await assert.rejects(svc.decideBooking((await svc.handleChat({ message: 'How much is a root canal?' })).ticketId, { decision: 'confirm' }), /not an appointment request/);
  });
});

describe('working-time calendar (clinic hours, lunch, Sundays, public holidays)', () => {
  const cal = buildCalendar(getIndex(clinic, 1));
  const due = (s: string) => addWorkingMinutes(cal, IST(s), 120).toISOString();
  test('ordinary weekday', () => assert.equal(due('2026-11-17T10:00:00'), IST('2026-11-17T12:00:00').toISOString()));
  test('lunch break (1:30–2:30 pm) is not working time', () => assert.equal(due('2026-11-17T13:00:00'), IST('2026-11-17T16:00:00').toISOString()));
  test('after closing on Saturday → skips emergencies-only Sunday → Monday', () => assert.equal(due('2026-11-21T19:30:00'), IST('2026-11-23T10:30:00').toISOString()));
  test('public holiday (24 Nov, Guru Nanak Jayanti) skipped', () => assert.equal(due('2026-11-23T19:00:00'), IST('2026-11-25T10:00:00').toISOString()));
  test('created at night counts from opening time', () => assert.equal(due('2026-11-17T22:00:00'), IST('2026-11-18T11:00:00').toISOString()));
  test('working minutes between two instants', () => {
    assert.equal(workingMinutesBetween(cal, IST('2026-11-17T12:00:00'), IST('2026-11-17T15:00:00')), 120);
    assert.equal(workingMinutesBetween(cal, IST('2026-11-21T19:00:00'), IST('2026-11-23T09:30:00')), 90);
  });
  test('works for a different clinic (hidden dataset hours)', () => {
    const hc = buildCalendar(getIndex(hidden, 1));
    assert.equal(addWorkingMinutes(hc, IST('2026-11-20T18:30:00'), 120).toISOString(), IST('2026-11-21T11:30:00').toISOString()); // Fri 7 pm close → Sat 10 am
    assert.equal(addWorkingMinutes(hc, IST('2026-11-21T15:30:00'), 120).toISOString(), IST('2026-11-23T11:30:00').toISOString()); // Sun closed
  });
  test('clinic file holiday list overrides the default', () => {
    const custom = buildCalendar(getIndex({ ...clinic, holidays: [{ date: '2026-11-18', name: 'Clinic anniversary' }] } as ClinicData, 99));
    assert.equal(addWorkingMinutes(custom, IST('2026-11-17T19:00:00'), 120).toISOString(), IST('2026-11-19T10:00:00').toISOString());
  });
});

describe('ticket ageing bands and priority', () => {
  test('New → Waiting → Delayed → Overdue on working time; overdue becomes HIGH priority', async () => {
    const { svc, set } = mk(IST('2026-11-17T09:00:00'));
    const a = await svc.handleChat({ message: 'Do you do Invisalign?' });
    const at = async (s: string) => { set(IST(s)); return (await svc.getTicket(a.ticketId!))!; };
    let t = await at('2026-11-17T09:10:00'); assert.equal(t.ageing!.band, 'new'); assert.equal(t.priority, 'normal'); assert.equal(t.ageing!.ageMinutes, 10);
    t = await at('2026-11-17T09:40:00'); assert.equal(t.ageing!.band, 'waiting');
    t = await at('2026-11-17T10:15:00'); assert.equal(t.ageing!.band, 'delayed'); assert.equal(t.priority, 'normal');
    t = await at('2026-11-17T10:35:00'); assert.equal(t.priority, 'high', 'approaching the deadline'); assert.equal(t.ageing!.dueInWorkingMinutes, 25);
    t = await at('2026-11-17T11:30:00'); assert.equal(t.ageing!.band, 'overdue'); assert.equal(t.priority, 'high');
    assert.equal(t.ageing!.callbackDueAt, IST('2026-11-17T11:00:00').toISOString()); assert.equal(t.ageing!.dueInWorkingMinutes, -30);
    assert.equal(t.ageing!.ageMinutes, 150);
    assert.equal(t.status, 'needs human'); // priority changed, status did not
  });
  test('waiting overnight is not counted as working time (not overdue at opening)', async () => {
    const { svc, set } = mk(IST('2026-11-17T19:50:00'));
    const a = await svc.handleChat({ message: 'Do you do veneers?' });
    set(IST('2026-11-18T09:05:00'));
    const t = (await svc.getTicket(a.ticketId!))!;
    assert.equal(t.ageing!.ageMinutes, 795); assert.equal(t.ageing!.workingMinutesWaiting, 15); assert.equal(t.ageing!.band, 'waiting');
  });
  test('staff reply stops the clock; a new patient message restarts it', async () => {
    const { svc, set } = mk(IST('2026-11-17T09:00:00'));
    const a = await svc.handleChat({ message: 'Do you do Invisalign?' });
    set(IST('2026-11-17T09:20:00')); await svc.staffReply(a.ticketId, { text: 'We will call you.' });
    set(IST('2026-11-17T12:00:00')); let t = (await svc.getTicket(a.ticketId!))!;
    assert.equal(t.ageing!.band, 'handled'); assert.equal(t.priority, 'low');
    await svc.handleChat({ conversationId: a.conversationId, message: 'Do you also do veneers?' }); // new ticket (new question)
    const b = await svc.handleChat({ conversationId: a.conversationId, message: 'Priya 91234 56789' }); // joins the veneers ticket
    set(IST('2026-11-17T12:20:00')); t = (await svc.getTicket(b.ticketId!))!;
    assert.equal(t.ageing!.band, 'waiting'); assert.equal(t.ageing!.workingMinutesWaiting, 20);
  });
  test('emergency: CRITICAL whatever the status, always top of the queue in every sort mode', async () => {
    const { svc, advance } = mk(IST('2026-11-17T09:00:00'));
    await svc.handleChat({ message: 'Do you do Invisalign?' });
    advance(200);
    await svc.handleChat({ message: 'How much is a root canal?' });
    advance(5);
    const e = await svc.handleChat({ message: 'There is heavy bleeding that will not stop' });
    advance(5);
    for (const mode of ['priority', 'oldest', 'newest'] as const) assert.equal((await svc.listTickets(mode))[0].id, e.ticketId, mode);
    const t = (await svc.getTicket(e.ticketId!))!;
    assert.equal(t.priority, 'critical'); assert.equal(t.ageing!.band, 'emergency'); assert.equal(t.ageing!.callbackDueAt, undefined);
    await svc.staffReply(e.ticketId, { text: 'Calling now' });
    assert.equal((await svc.getTicket(e.ticketId!))!.priority, 'critical');
    await svc.setStatus(e.ticketId, { status: 'closed' });
    assert.equal((await svc.getTicket(e.ticketId!))!.priority, 'critical'); // independent of status
  });
  test('priority levels: answered = low, needs human = normal, overdue = high, tomorrow booking = high', async () => {
    const { svc, set } = mk(IST('2026-11-17T09:00:00'));
    const ans = await svc.handleChat({ message: 'How much is a root canal?' });
    const hum = await svc.handleChat({ message: 'Do you do veneers?' });
    const far = await svc.handleChat({ message: 'Book a cleaning on Saturday at 11am' });
    const soon = await svc.handleChat({ message: 'Book a cleaning tomorrow at 11am' });
    set(IST('2026-11-17T09:30:00'));
    const p = async (id?: string) => (await svc.getTicket(id!))!.priority;
    assert.equal(await p(ans.ticketId), 'low'); assert.equal(await p(hum.ticketId), 'normal');
    assert.equal(await p(far.ticketId), 'normal'); assert.equal(await p(soon.ticketId), 'high');
    set(IST('2026-11-17T12:00:00'));
    assert.equal(await p(hum.ticketId), 'high'); // overdue
    const q = await svc.listTickets('priority');
    assert.deepEqual(q.map((t) => t.priority), ['high', 'high', 'high', 'low']);
    const oldest = await svc.listTickets('oldest');
    assert.equal(oldest[0].id, ans.ticketId);
  });
  test('pure function: ageing and priority are computed, not stored', () => {
    const cal = buildCalendar(getIndex(clinic, 1));
    const t = { createdAt: IST('2026-11-17T09:00:00').toISOString(), status: 'needs human', type: 'unsupported', messages: [], booking: undefined } as unknown as Ticket;
    const a = computeAgeing(t, cal, IST('2026-11-17T12:00:00'));
    assert.equal(a.band, 'overdue'); assert.equal(computePriority(t, a, IST('2026-11-17T12:00:00')), 'high');
    assert.equal(sortQueue([{ ...t, priority: 'low', updatedAt: '' }] as Ticket[]).length, 1);
  });
});
