// Stage 2 — real Chromium (playwright-core) against the production build, the real
// Netlify function and real @netlify/blobs client (BlobsServer emulator).
import { test, describe, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { chromium, type Browser, type Page } from 'playwright-core';
import { startLocalNetlify } from '../scripts/local-server.ts';

const samples = JSON.parse(readFileSync(new URL('../src/data/sample-questions.json', import.meta.url), 'utf8'));
let base = ''; let close: () => Promise<void>; let browser: Browser;
before(async () => { const s = await startLocalNetlify(); base = s.url; close = s.close; browser = await chromium.launch(); });
after(async () => { await browser.close(); await close(); });

const fresh = async (width = 390) => (await browser.newContext({ viewport: { width, height: 800 } })).newPage();
const lastBot = (p: Page) => p.locator('.bot-msg').last().innerText();
async function askOnLoad(p: Page, q: string) {
  await p.goto(`${base}/?q=${encodeURIComponent(q)}`);
  await p.waitForSelector('.bot-msg');
  return lastBot(p);
}
async function typeAndSend(p: Page, q: string, enter = false) {
  const n = await p.locator('.bot-msg').count();
  await p.fill('#chat-input', q);
  if (enter) await p.press('#chat-input', 'Enter'); else await p.click('#chat-send');
  await p.waitForFunction((k) => document.querySelectorAll('.bot-msg').length > k, n);
  return lastBot(p);
}
const ticketByText = (p: Page, text: string) => p.locator('[data-ticket]', { hasText: text });

describe('real browser — patient', () => {
  for (const s of samples) test(`?q= sample: ${s.q}`, async () => {
    const p = await fresh();
    const t = await askOnLoad(p, s.q);
    for (const i of s.must_include || []) assert.ok(t.includes(i), `missing "${i}" in ${t}`);
    for (const x of s.must_not_include || []) assert.ok(!t.toLowerCase().includes(x.toLowerCase()));
    assert.equal(await p.locator('.patient-msg').count(), 1, 'asked exactly once');
    assert.ok(!p.url().includes('q='), 'q removed so a refresh does not re-ask');
    await p.context().close();
  });
  test('button click and Enter key both send', async () => {
    const p = await fresh();
    await p.goto(base + '/');
    assert.match(await typeAndSend(p, 'How much is a root canal?'), /6,500/);
    assert.match(await typeAndSend(p, 'Do you take Niva Bupa insurance?', true), /cashless/);
    await p.context().close();
  });
});

describe('real browser — tickets and staff', () => {
  test('sample tickets have the expected statuses on /staff', async () => {
    const s = await fresh(1280);
    await s.goto(base + '/staff');
    await s.waitForSelector('#ticket-queue [data-ticket]');
    for (const q of samples.filter((x: any) => x.status)) {
      const card = ticketByText(s, q.q).first();
      assert.equal(await card.getAttribute('data-status'), q.status, q.q);
    }
    const statuses = await s.$$eval('[data-ticket]', (els) => els.map((e) => e.getAttribute('data-status')));
    assert.ok(statuses.every((x) => ['answered', 'needs human', 'urgent', 'closed'].includes(x!)));
    assert.equal(statuses[0], 'urgent');
    await s.context().close();
  });

  test('staff reply reaches the open patient chat; close persists; multiple patients isolated', async () => {
    const patient = await fresh();
    await patient.goto(base + '/');
    await typeAndSend(patient, 'Do you offer dental veneers?');
    const other = await fresh();
    await other.goto(base + '/');
    await typeAndSend(other, 'Do you make dentures?');

    const staff = await fresh(1280);
    await staff.goto(base + '/staff');
    const card = ticketByText(staff, 'Do you offer dental veneers?');
    await card.waitFor();
    assert.equal(await card.getAttribute('data-status'), 'needs human');
    await card.locator('#staff-reply').fill('Hello! Dr. Meera can assess you for veneers — we will call you today.');
    await card.locator('#staff-send').click();
    await staff.waitForFunction(() => document.querySelector('[data-ticket] .fb-ok') !== null);
    assert.equal(await card.getAttribute('data-status'), 'answered');

    // the still-open patient page receives it via polling (no new conversation)
    await patient.waitForFunction(() => [...document.querySelectorAll('.bot-msg')].some((e) => e.textContent!.includes('Dr. Meera can assess you for veneers')), null, { timeout: 12000 });
    assert.match(await lastBot(patient), /Dr\. Meera can assess you/);
    assert.equal(await patient.locator('.patient-msg').count(), 1);
    // the other patient never sees it
    await other.waitForTimeout(4500);
    assert.ok(!(await other.locator('body').innerText()).includes('Dr. Meera can assess you'));

    // close → persists across staff reload
    await card.getByText('Close ticket').click();
    await staff.waitForFunction(() => [...document.querySelectorAll('[data-ticket]')].some((e) => e.textContent!.includes('dental veneers') && e.getAttribute('data-status') === 'closed'));
    await staff.reload();
    await ticketByText(staff, 'Do you offer dental veneers?').waitFor();
    assert.equal(await ticketByText(staff, 'Do you offer dental veneers?').getAttribute('data-status'), 'closed');

    // patient reload → full history restored
    await patient.reload();
    await patient.waitForSelector('.bot-msg.staff-msg');
    assert.equal(await patient.locator('.patient-msg').count(), 1);
    assert.match(await lastBot(patient), /Dr\. Meera can assess you/);
    for (const p of [patient, other, staff]) await p.context().close();
  });

  test('booking request + follow-up details land on ONE ticket, shown as not confirmed', async () => {
    const p = await fresh();
    await p.goto(base + '/');
    assert.match(await typeAndSend(p, 'I want to book an appointment'), /not a confirmed booking/);
    await typeAndSend(p, 'Saturday at 11am');
    await typeAndSend(p, 'Meena Iyer 99000 11122');
    const s = await fresh(1280);
    await s.goto(base + '/staff');
    const card = ticketByText(s, 'Meena Iyer');
    await card.waitFor();
    assert.equal(await card.count(), 1);
    const txt = await card.innerText();
    assert.match(txt, /NOT confirmed/); assert.match(txt, /Saturday/); assert.match(txt, /11am/); assert.match(txt, /99000 11122/);
    assert.equal(await card.getAttribute('data-status'), 'needs human');
    await p.context().close(); await s.context().close();
  });

  test('Stage 3: booking approve in /staff → "confirmed by staff" in the open patient chat; ageing + priority shown', async () => {
    const p = await fresh();
    await p.goto(base + '/');
    const first = await typeAndSend(p, 'Book a root canal with Dr Meera on Saturday at 11am. My name is Kiran Rao, 90000 12345');
    assert.match(first, /awaiting staff confirmation/); assert.match(first, /not a confirmed booking/);
    const s = await fresh(1280);
    await s.goto(base + '/staff');
    const card = ticketByText(s, 'Kiran Rao');
    await card.waitFor();
    assert.equal(await card.getAttribute('data-status'), 'needs human');
    assert.equal(await card.getAttribute('data-age-band'), 'new');
    assert.ok(['normal', 'high'].includes((await card.getAttribute('data-priority'))!));
    assert.equal(await card.locator('[data-booking-state]').getAttribute('data-booking-state'), 'awaiting confirmation');
    await s.selectOption('select[data-filter="type"]', 'booking');
    assert.ok(await s.locator('[data-ticket]').count() >= 1);
    assert.equal(await s.locator('[data-ticket]:not([data-type="booking"])').count(), 0);
    await card.locator('[data-action="confirm-booking"]').click();
    await s.waitForFunction(() => document.querySelector('[data-booking-state="confirmed"]') !== null);
    await p.waitForFunction(() => [...document.querySelectorAll('.bot-msg')].some((e) => e.textContent!.includes('confirmed by our staff')), null, { timeout: 12000 });
    assert.match(await lastBot(p), /confirmed by our staff: Saturday, 21 Nov 2026 at 11:00 am with Dr\. Meera Nair/);
    assert.match(await p.locator('body').innerText(), /Confirmed by staff/);
    await p.context().close(); await s.context().close();
  });

  test('375px: staff controls usable, no horizontal scroll (patient + staff)', async () => {
    const s = await fresh(375);
    for (const path of ['/staff', '/']) {
      await s.goto(base + path);
      await s.waitForSelector(path === '/' ? '#chat-input' : '[data-ticket]');
      const r = await s.evaluate(() => ({ sw: document.documentElement.scrollWidth, w: innerWidth }));
      assert.ok(r.sw <= r.w, `${path} horizontal scroll ${r.sw} > ${r.w}`);
    }
    await s.goto(base + '/staff');
    await s.waitForSelector('[data-ticket]');
    const box = await s.locator('[data-ticket] #staff-send').first().boundingBox();
    assert.ok(box && box.height >= 44 && box.x + box.width <= 375);
    const ta = await s.locator('[data-ticket] #staff-reply').first().boundingBox();
    assert.ok(ta && ta.width > 250 && ta.x + ta.width <= 375);
    await s.context().close();
  });
});
