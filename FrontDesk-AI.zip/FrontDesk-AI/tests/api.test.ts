// Stage 2 — HTTP API through the REAL Netlify function file (netlify/functions/api.mts)
// using the REAL @netlify/blobs client against the official BlobsServer emulator.
import { test, describe, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { startLocalNetlify } from '../scripts/local-server.ts';
import { readFileSync } from 'node:fs';

let base = ''; let close: () => Promise<void>;
before(async () => { const s = await startLocalNetlify(); base = s.url; close = s.close; });
after(async () => { await close(); });

const post = async (path: string, body: unknown) => { const r = await fetch(base + path, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) }); return { status: r.status, json: await r.json() as any }; };
const get = async (path: string) => { const r = await fetch(base + path); return { status: r.status, json: await r.json().catch(() => null) as any, text: '' }; };

describe('Netlify function + Netlify Blobs', () => {
  test('health', async () => { const r = await get('/api/health'); assert.deepEqual(r.json, { ok: true, service: 'frontdesk', storage: 'netlify-blobs' }); });

  test('four statuses end-to-end over HTTP', async () => {
    const a = await post('/api/chat', { message: 'What time do you open on Saturday?' });
    const h = await post('/api/chat', { message: 'Do you do Invisalign?' });
    const u = await post('/api/chat', { message: 'My face is swelling and I cannot breathe properly' });
    assert.equal(a.json.status, 'answered'); assert.equal(h.json.status, 'needs human'); assert.equal(u.json.status, 'urgent');
    const c = await post(`/api/tickets/${a.json.ticketId}/status`, { status: 'closed', staffName: 'Anita' });
    assert.equal(c.json.ticket.status, 'closed');
    const all = (await get('/api/tickets')).json.tickets;
    const byId = Object.fromEntries(all.map((t: any) => [t.id, t.status]));
    assert.equal(byId[a.json.ticketId], 'closed'); assert.equal(byId[h.json.ticketId], 'needs human'); assert.equal(byId[u.json.ticketId], 'urgent');
    assert.equal(all[0].status, 'urgent');
  });

  test('staff reply shows only in the right conversation', async () => {
    const p1 = await post('/api/chat', { message: 'Do you do veneers?' });
    const p2 = await post('/api/chat', { message: 'Do you do dentures?' });
    const r = await post(`/api/tickets/${p1.json.ticketId}/reply`, { text: 'Veneers: please visit for a consultation.', staffName: 'Anita' });
    assert.equal(r.status, 200); assert.equal(r.json.ticket.status, 'answered');
    const c1 = (await get(`/api/conversation?id=${p1.json.conversationId}`)).json.messages;
    const c2 = (await get(`/api/conversation?id=${p2.json.conversationId}`)).json.messages;
    assert.equal(c1.at(-1).sender, 'staff'); assert.match(c1.at(-1).text, /Veneers/);
    assert.ok(!c2.some((m: any) => m.sender === 'staff'));
  });

  test('booking follow-up joins the same ticket over HTTP', async () => {
    const a = await post('/api/chat', { message: 'I want to book an appointment' });
    const b = await post('/api/chat', { conversationId: a.json.conversationId, message: 'Saturday at 11am, Ravi 98765 43210' });
    assert.equal(b.json.ticketId, a.json.ticketId);
    const t = (await get(`/api/tickets/${a.json.ticketId}`)).json.ticket;
    assert.equal(t.booking.dateText, 'Saturday'); assert.equal(t.booking.timeText, '11am'); assert.equal(t.phone, '98765 43210');
  });

  test('concurrent writes with real Blobs ETags lose nothing', async () => {
    const a = await post('/api/chat', { message: 'Do you do wisdom tooth extraction?' });
    const rs = await Promise.all(Array.from({ length: 6 }, (_, i) => post(`/api/tickets/${a.json.ticketId}/reply`, { text: `parallel ${i}` })));
    assert.ok(rs.every((r) => r.status === 200), JSON.stringify(rs.map((r) => r.status)));
    const t = (await get(`/api/tickets/${a.json.ticketId}`)).json.ticket;
    assert.equal(t.messages.filter((m: any) => m.sender === 'staff').length, 6);
  });

  test('stress: 20 parallel staff replies + patient follow-up on one ticket', async () => {
    const a = await post('/api/chat', { message: 'I want to book an appointment' });
    const rs = await Promise.all([
      ...Array.from({ length: 20 }, (_, i) => post(`/api/tickets/${a.json.ticketId}/reply`, { text: `stress ${i}` })),
      post('/api/chat', { conversationId: a.json.conversationId, message: 'Saturday at 11am' }),
    ]);
    assert.ok(rs.every((r) => r.status === 200), JSON.stringify(rs.map((r) => r.status)));
    const t = (await get(`/api/tickets/${a.json.ticketId}`)).json.ticket;
    assert.equal(t.messages.filter((m: any) => m.sender === 'staff').length, 20);
    assert.equal(t.messages.filter((m: any) => m.sender === 'patient').length, 2);
    assert.equal(t.booking.dateText, 'Saturday'); assert.equal(t.booking.timeText, '11am'); assert.ok(['answered', 'needs human'].includes(t.status));
    const conv = (await get(`/api/conversation?id=${a.json.conversationId}`)).json.messages;
    assert.equal(conv.filter((m: any) => m.sender === 'staff').length, 20);
  });

  test('booking decision over HTTP + ageing/priority in the payload', async () => {
    const a = await post('/api/chat', { message: 'Book a cleaning on Saturday at 11am. I am Ravi Kumar, 98765 43210' });
    const t0 = (await get(`/api/tickets/${a.json.ticketId}`)).json.ticket;
    assert.equal(t0.booking.state, 'awaiting confirmation'); assert.equal(t0.status, 'needs human');
    assert.ok(['new', 'waiting', 'delayed', 'overdue'].includes(t0.ageing.band)); assert.ok(typeof t0.ageing.ageMinutes === 'number');
    assert.equal((await post(`/api/tickets/${a.json.ticketId}/booking`, { decision: 'nope' })).status, 400);
    const r = await post(`/api/tickets/${a.json.ticketId}/booking`, { decision: 'confirm', staffName: 'Anita' });
    assert.equal(r.status, 200); assert.equal(r.json.ticket.booking.state, 'confirmed');
    const conv = (await get(`/api/conversation?id=${a.json.conversationId}`)).json.messages;
    assert.match(conv.at(-1).text, /confirmed by our staff/);
    const h = await post('/api/chat', { message: 'How much is a root canal?' });
    assert.equal((await post(`/api/tickets/${h.json.ticketId}/booking`, { decision: 'confirm' })).status, 400);
    const sorted = (await get('/api/tickets?sort=oldest')).json.tickets;
    assert.ok(Array.isArray(sorted) && sorted.length > 0);
  });

  test('clinic file API: get, versioned save, conflict 409, invalid 400, hidden-data import, reset', async () => {
    const put = async (b: unknown) => { const r = await fetch(base + '/api/clinic', { method: 'PUT', headers: { 'content-type': 'application/json' }, body: JSON.stringify(b) }); return { status: r.status, json: await r.json() as any }; };
    const c0 = (await get('/api/clinic')).json.clinic;
    assert.equal(c0.data.clinic.name, 'Bright Roots Dental');
    assert.equal((await put({ data: { clinic: { name: 'x' } }, baseVersion: c0.version })).status, 400);
    const hidden = JSON.parse(readFileSync(new URL('./fixtures/hidden-clinic.json', import.meta.url), 'utf8'));
    const ok = await put({ data: hidden, baseVersion: c0.version, staffName: 'Tester' });
    assert.equal(ok.status, 200); assert.equal(ok.json.clinic.version, c0.version + 1);
    assert.equal((await put({ data: hidden, baseVersion: c0.version })).status, 409);
    const r = await post('/api/chat', { message: 'How much is a root canal?' });
    assert.match(r.json.messages[1].text, /7,200/); assert.doesNotMatch(r.json.messages[1].text, /6,500/);
    const e = await post('/api/chat', { message: 'My face is swelling and I cannot breathe properly' });
    assert.ok(e.json.messages[1].text.slice(0, 60).includes('91234 56789'));
    assert.equal((await post('/api/clinic/reset', {})).status, 400); // needs explicit confirm
    const rs = await post('/api/clinic/reset', { confirm: true });
    assert.equal(rs.json.clinic.version, c0.version + 2); assert.equal(rs.json.clinic.data.clinic.name, 'Bright Roots Dental');
    assert.match((await post('/api/chat', { message: 'How much is a root canal?' })).json.messages[1].text, /6,500/);
  });

  test('staff reply with saveFaq over HTTP', async () => {
    const q = await post('/api/chat', { message: 'Do you offer tooth jewellery?' });
    assert.equal(q.json.status, 'needs human');
    const r = await post(`/api/tickets/${q.json.ticketId}/reply`, { text: 'Yes, tooth gems are fitted on Fridays.', staffName: 'Anita', saveFaq: true });
    assert.equal(r.status, 200); assert.ok(r.json.ticket.savedFaqVersion > 1);
    const n = await post('/api/chat', { message: 'Do you offer tooth jewellery?' });
    assert.equal(n.json.messages[1].text, 'Yes, tooth gems are fitted on Fridays.'); assert.equal(n.json.messages[1].meta.source, 'staff-faq');
    await post('/api/clinic/reset', { confirm: true });
  });

  test('bad input → clean 4xx JSON, no stack traces', async () => {
    assert.equal((await post('/api/chat', { message: '' })).status, 400);
    assert.equal((await post('/api/tickets/BR-000000-ZZZZZZ/reply', { text: 'x' })).status, 404);
    const r = await fetch(base + '/api/chat', { method: 'POST', body: 'not json' }); assert.equal(r.status, 400);
    const txt = await (await fetch(base + '/api/nope')).text(); assert.doesNotMatch(txt, /at .*\.ts:\d+/);
  });

  test('SPA routes served (/staff, /?q=)', async () => {
    for (const p of ['/staff', '/?q=What%20time%20do%20you%20open%20on%20Saturday%3F', '/']) {
      const r = await fetch(base + p); assert.equal(r.status, 200); assert.match(await r.text(), /<div id="root">/);
    }
  });
});
