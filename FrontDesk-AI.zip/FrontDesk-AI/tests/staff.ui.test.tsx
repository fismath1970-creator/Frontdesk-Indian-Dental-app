// @vitest-environment jsdom
// Stage 2 — staff dashboard + patient/staff loop through the real React UI (local demo backend).
import { afterEach, beforeEach, describe, expect, test } from 'vitest';
import { act, cleanup, fireEvent, render, waitFor, within } from '@testing-library/react';
import { App } from '../src/App.tsx';
import { localBackend, setBackendForTests } from '../src/lib/backend.ts';

const ALLOWED = ['answered', 'needs human', 'urgent', 'closed'];
beforeEach(() => { localStorage.clear(); setBackendForTests(null); });
afterEach(() => { cleanup(); window.history.replaceState({}, '', '/'); });

const go = (path: string) => window.history.replaceState({}, '', path);
const be = () => localBackend();
async function seed() {
  const b = be();
  const a = await b.chat('conv-answered-0001', 'How much is a root canal?', 'm-000000000001');
  const h = await b.chat('conv-human-000001', 'Do you do Invisalign? I am Ravi Kumar, 98765 43210', 'm-000000000002');
  const u = await b.chat('conv-urgent-00001', 'My face is swelling and I cannot breathe properly', 'm-000000000003');
  const k = await b.chat('conv-booking-0001', 'I want to book an appointment on Saturday at 11am with Dr Sneha', 'm-000000000004');
  return { a, h, u, k };
}
const cards = () => [...document.querySelectorAll<HTMLElement>('#ticket-queue [data-ticket]')];
const cardFor = (id: string) => document.querySelector<HTMLElement>(`[data-ticket="${id}"]`)!;
async function openStaff(n: number) {
  go('/staff');
  render(<App />);
  await waitFor(() => expect(cards().length).toBe(n));
}

describe('selectors and structure', () => {
  test('#ticket-queue, [data-ticket], valid data-status, one #staff-reply + #staff-send per ticket', async () => {
    await seed();
    await openStaff(4);
    for (const c of cards()) {
      expect(ALLOWED).toContain(c.getAttribute('data-status'));
      expect(c.querySelectorAll('textarea#staff-reply').length).toBe(1);
      expect(c.querySelectorAll('button#staff-send').length).toBe(1);
    }
    expect(cards()[0].getAttribute('data-status')).toBe('urgent'); // urgent pinned first
    expect(document.querySelector('.urgent-alert')?.textContent).toContain('98000 00123');
    expect(document.querySelector('#chat-input')).toBeNull(); // staff page is not the patient page
  });
  test('each status renders with its exact attribute value, booking shows NOT confirmed', async () => {
    const { a, h, u, k } = await seed();
    await be().setStatus(a.ticketId!, 'closed', 'Anita');
    await openStaff(4);
    expect(cardFor(a.ticketId!).dataset.status).toBe('closed');
    expect(cardFor(h.ticketId!).dataset.status).toBe('needs human');
    expect(cardFor(u.ticketId!).dataset.status).toBe('urgent');
    expect(cardFor(k.ticketId!).textContent).toMatch(/NOT confirmed/);
    expect(cardFor(k.ticketId!).textContent).toMatch(/Saturday/);
  });
});

describe('staff actions', () => {
  test('reply typed in the 2nd ticket goes to that ticket only; needs human → answered, not closed', async () => {
    const { h, k } = await seed();
    await openStaff(4);
    const card = cardFor(h.ticketId!);
    const ta = card.querySelector<HTMLTextAreaElement>('#staff-reply')!;
    fireEvent.input(ta, { target: { value: 'Hi Ravi, Dr. Imran will call you about aligners today.' } });
    fireEvent.click(card.querySelector('#staff-send')!);
    await waitFor(() => expect(cardFor(h.ticketId!).dataset.status).toBe('answered'));
    const tickets = await be().tickets();
    const th = tickets.find((t) => t.id === h.ticketId)!;
    const tk = tickets.find((t) => t.id === k.ticketId)!;
    expect(th.messages.at(-1)!.sender).toBe('staff');
    expect(th.messages.at(-1)!.text).toContain('Dr. Imran will call you');
    expect(tk.messages.some((m) => m.sender === 'staff')).toBe(false);
    expect(within(cardFor(h.ticketId!)).getByText(/Reply sent/)).toBeTruthy();
  });
  test('empty reply is not sent', async () => {
    const { h } = await seed();
    await openStaff(4);
    fireEvent.click(cardFor(h.ticketId!).querySelector('#staff-send')!);
    await waitFor(() => expect(cardFor(h.ticketId!).textContent).toContain('Type a reply first'));
    expect((await be().tickets()).find((t) => t.id === h.ticketId)!.messages.some((m) => m.sender === 'staff')).toBe(false);
  });
  test('close and reopen a ticket', async () => {
    const { h } = await seed();
    await openStaff(4);
    fireEvent.click(within(cardFor(h.ticketId!)).getByText('Close ticket'));
    await waitFor(() => expect(cardFor(h.ticketId!).dataset.status).toBe('closed'));
    fireEvent.click(within(cardFor(h.ticketId!)).getByText('Reopen ticket'));
    await waitFor(() => expect(cardFor(h.ticketId!).dataset.status).toBe('needs human'));
  });
});

describe('dashboard counts, search and filters', () => {
  test('stat cards', async () => {
    const { a } = await seed();
    await be().setStatus(a.ticketId!, 'closed', 'x');
    await openStaff(4);
    const val = (label: string) => [...document.querySelectorAll('.stat')].find((s) => s.textContent!.includes(label))!.querySelector('.stat-value')!.textContent;
    expect(val('Total enquiries')).toBe('4'); expect(val('Urgent')).toBe('1'); expect(val('Needs human')).toBe('2');
    expect(val('Answered')).toBe('0'); expect(val('Closed')).toBe('1'); expect(val('New tickets')).toBe('3');
  });
  test('search by phone and by name; status and priority filters', async () => {
    const { h, u } = await seed();
    await openStaff(4);
    const search = document.querySelector<HTMLInputElement>('input[type="search"]')!;
    fireEvent.change(search, { target: { value: '98765 43210' } });
    await waitFor(() => expect(cards().map((c) => c.dataset.ticket)).toEqual([h.ticketId]));
    fireEvent.change(search, { target: { value: 'ravi' } });
    await waitFor(() => expect(cards().map((c) => c.dataset.ticket)).toEqual([h.ticketId]));
    fireEvent.change(search, { target: { value: '' } });
    const [statusSel, prioSel] = [...document.querySelectorAll('select')];
    fireEvent.change(statusSel, { target: { value: 'urgent' } });
    await waitFor(() => expect(cards().map((c) => c.dataset.ticket)).toEqual([u.ticketId]));
    fireEvent.change(statusSel, { target: { value: 'all' } });
    fireEvent.change(prioSel, { target: { value: 'critical' } }); // Stage 3 priorities: emergency = critical
    await waitFor(() => expect(cards().map((c) => c.dataset.ticket)).toEqual([u.ticketId]));
  });
});

describe('patient ⇄ staff loop', () => {
  test('patient asks → staff replies → reply appears in the open patient chat (no new conversation)', async () => {
    render(<App />);
    await waitFor(() => expect(document.querySelector('.patient[data-ready="true"]')).not.toBeNull());
    const input = document.querySelector<HTMLInputElement>('#chat-input')!;
    input.value = 'Do you do Invisalign?';
    fireEvent.click(document.querySelector('#chat-send')!);
    await waitFor(() => expect(document.querySelectorAll('.bot-msg').length).toBe(1));
    const convId = localStorage.getItem('frontdesk.conversationId')!;
    const ticket = (await be().tickets()).find((t) => t.conversationId === convId)!;
    expect(ticket.status).toBe('needs human');
    await be().reply(ticket.id, 'STAFF: yes, Dr. Imran offers clear aligner consultations.', 'Anita');
    await act(async () => { window.dispatchEvent(new Event('focus')); }); // same as the 4 s poll, immediately
    await waitFor(() => expect(document.querySelectorAll('.bot-msg').length).toBe(2));
    const last = [...document.querySelectorAll('.bot-msg')].at(-1)!;
    expect(last.textContent).toContain('STAFF: yes, Dr. Imran');
    expect(last.classList.contains('staff-msg')).toBe(true);
    expect(document.querySelectorAll('.patient-msg').length).toBe(1); // earlier history preserved, nothing duplicated
    expect(localStorage.getItem('frontdesk.conversationId')).toBe(convId);
  });
  test('reload restores the full conversation including the staff reply', async () => {
    const b = be();
    localStorage.setItem('frontdesk.conversationId', 'conv-reload-00001');
    const r = await b.chat('conv-reload-00001', 'Do you do veneers?', 'm-000000000010');
    await b.reply(r.ticketId!, 'Please come for a consultation.', 'Anita');
    render(<App />);
    await waitFor(() => expect(document.querySelectorAll('.bot-msg').length).toBe(2));
    expect(document.querySelector('.patient-msg')!.textContent).toBe('Do you do veneers?');
    expect([...document.querySelectorAll('.bot-msg')].at(-1)!.textContent).toContain('Please come for a consultation.');
  });
  test('another patient never sees the reply', async () => {
    const b = be();
    const other = await b.chat('conv-other-000001', 'Do you do dentures?', 'm-000000000020');
    await b.reply(other.ticketId!, 'SECRET-FOR-OTHER', 'Anita');
    localStorage.setItem('frontdesk.conversationId', 'conv-mine-0000001');
    render(<App />);
    await waitFor(() => expect(document.querySelector('.patient[data-ready="true"]')).not.toBeNull());
    expect(document.body.textContent).not.toContain('SECRET-FOR-OTHER');
  });
});
