// Stage 2 — ticket service tests (real engine + real service, in-memory KV).
import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { MemoryKV } from '../src/tickets/kv.ts';
import { createTicketService } from '../src/tickets/service.ts';
import type { ClinicData } from '../src/engine/types.ts';

const clinic: ClinicData = JSON.parse(readFileSync(new URL('../src/data/clinic-data.json', import.meta.url), 'utf8'));
const STATUSES = ['answered', 'needs human', 'urgent', 'closed'];
let clock = Date.parse('2026-11-17T06:00:00Z');
const make = (kv = new MemoryKV()) => ({ kv, svc: createTicketService({ kv, getClinic: () => ({ data: clinic, version: 1 }), now: () => new Date((clock += 1000)) }) });

describe('ticket creation and status', () => {
  test('answered question → answered ticket with all required fields', async () => {
    const { svc } = make();
    const r = await svc.handleChat({ message: 'How much is a root canal?' });
    const t = (await svc.getTicket(r.ticketId!))!;
    assert.equal(t.status, 'answered'); assert.equal(t.priority, 'low' /* Stage 3: routine answered = Low */); assert.equal(t.category, 'prices');
    assert.equal(t.question, 'How much is a root canal?');
    assert.equal(t.messages.length, 2); assert.equal(t.messages[1].sender, 'bot'); assert.match(t.messages[1].text, /6,500/);
    for (const k of ['id', 'conversationId', 'createdAt', 'updatedAt', 'lastBotReply']) assert.ok((t as never)[k], `missing ${k}`);
    assert.match(t.id, /^BR-\d{6}-[A-Z2-9]{6}$/);
  });
  test('unknown question → needs human', async () => {
    const { svc } = make();
    const r = await svc.handleChat({ message: 'Do you do Invisalign?' });
    assert.equal(r.status, 'needs human'); assert.equal((await svc.getTicket(r.ticketId!))!.category, 'unsupported');
    assert.match(r.messages[1].text, /2 working hours/); assert.match(r.messages[1].text, /name and phone number/);
  });
  test('emergency → urgent + critical, emergency number first', async () => {
    const { svc } = make();
    const r = await svc.handleChat({ message: 'My face is swelling and I cannot breathe properly' });
    const t = (await svc.getTicket(r.ticketId!))!;
    assert.equal(t.status, 'urgent'); assert.equal(t.priority, 'critical'); assert.equal(t.category, 'emergency');
    assert.ok(r.messages[1].text.slice(0, 60).includes('98000 00123'));
  });
  test('booking request → booking ticket, never confirmed', async () => {
    const { svc } = make();
    const r = await svc.handleChat({ message: 'I want to book an appointment on Saturday at 11am with Dr Sneha' });
    const t = (await svc.getTicket(r.ticketId!))!;
    assert.equal(t.type, 'booking'); assert.equal(t.category, 'booking'); assert.equal(t.status, 'needs human'); assert.equal(t.priority, 'normal' /* Stage 3: bookings = Normal unless time-sensitive/overdue */);
    assert.deepEqual([t.booking?.dateText, t.booking?.timeText, t.booking?.doctor], ['Saturday', '11am', 'Dr. Sneha Rao']);
    assert.match(r.messages[1].text, /not a confirmed booking/); assert.doesNotMatch(r.messages[1].text, /appointment is confirmed|you are booked/i);
  });
  test('every status value is one of the four allowed strings', async () => {
    const { svc } = make();
    for (const q of ['Hi there, how much is cleaning?', 'Where are you located?', 'Do you do veneers?', 'heavy bleeding that will not stop', 'book an appointment tomorrow 5pm']) await svc.handleChat({ message: q });
    const ts = await svc.listTickets();
    await svc.setStatus(ts.find((t) => t.status === 'answered')!.id, { status: 'closed' });
    for (const t of await svc.listTickets()) assert.ok(STATUSES.includes(t.status), t.status);
    assert.deepEqual(new Set((await svc.listTickets()).map((t) => t.status)), new Set(STATUSES));
  });
});

describe('follow-ups join the same enquiry (no duplicates)', () => {
  test('booking details given later are added to the booking ticket', async () => {
    const { svc } = make();
    const a = await svc.handleChat({ message: 'I want to book an appointment' });
    const b = await svc.handleChat({ conversationId: a.conversationId, message: 'Saturday at 11am' });
    const c = await svc.handleChat({ conversationId: a.conversationId, message: 'My name is Ravi Kumar, 98765 43210' });
    assert.equal(b.ticketId, a.ticketId); assert.equal(c.ticketId, a.ticketId);
    const t = (await svc.getTicket(a.ticketId!))!;
    assert.equal(t.messages.length, 6); assert.equal(t.patientName, 'Ravi Kumar'); assert.equal(t.phone, '98765 43210');
    assert.equal(t.booking?.dateText, 'Saturday'); assert.equal(t.booking?.timeText, '11am'); assert.equal(t.booking?.needsClarification, false);
    assert.equal((await svc.listTickets()).length, 1);
  });
  test('contact details after an unknown question join that ticket and keep needs human', async () => {
    const { svc } = make();
    const a = await svc.handleChat({ message: 'Do you do Invisalign?' });
    const b = await svc.handleChat({ conversationId: a.conversationId, message: 'Priya Sharma 91234 56789' });
    assert.equal(b.ticketId, a.ticketId);
    const t = (await svc.getTicket(a.ticketId!))!;
    assert.equal(t.status, 'needs human'); assert.equal(t.patientName, 'Priya Sharma'); assert.equal(t.phone, '91234 56789');
  });
  test('"yes" after a symptom reply turns that ticket into a booking request', async () => {
    const { svc } = make();
    const a = await svc.handleChat({ message: 'My tooth hurts a lot, should I take a painkiller?' });
    const b = await svc.handleChat({ conversationId: a.conversationId, message: 'yes please' });
    assert.equal(b.ticketId, a.ticketId);
    const t = (await svc.getTicket(a.ticketId!))!;
    assert.equal(t.type, 'booking'); assert.equal(t.status, 'needs human');
  });
  test('a new question creates a new ticket; contact carries over', async () => {
    const { svc } = make();
    const a = await svc.handleChat({ message: 'Do you do Invisalign? I am Anil, 99887 66554' });
    const b = await svc.handleChat({ conversationId: a.conversationId, message: 'How much is teeth whitening?' });
    assert.notEqual(b.ticketId, a.ticketId);
    assert.equal((await svc.getTicket(b.ticketId!))!.phone, '99887 66554');
  });
  test('an emergency always opens its own urgent ticket', async () => {
    const { svc } = make();
    const a = await svc.handleChat({ message: 'I want to book an appointment' });
    const b = await svc.handleChat({ conversationId: a.conversationId, message: 'my face is swollen and I can not breathe' });
    assert.notEqual(b.ticketId, a.ticketId); assert.equal(b.status, 'urgent');
  });
  test('greeting with no enquiry is kept in the conversation but makes no ticket', async () => {
    const { svc } = make();
    const a = await svc.handleChat({ message: 'hello' });
    assert.equal(a.ticketId, undefined); assert.equal((await svc.listTickets()).length, 0);
    assert.equal((await svc.getConversation(a.conversationId)).messages.length, 2);
  });
  test('a message after the ticket is closed starts a new ticket', async () => {
    const { svc } = make();
    const a = await svc.handleChat({ message: 'Do you do Invisalign?' });
    await svc.setStatus(a.ticketId, { status: 'closed' });
    const b = await svc.handleChat({ conversationId: a.conversationId, message: 'Rahul 98765 11111' });
    assert.notEqual(b.ticketId, a.ticketId);
  });
  test('retrying the same client message id does not duplicate', async () => {
    const { svc } = make();
    const a = await svc.handleChat({ message: 'How much is a root canal?', clientMessageId: 'msg-0001-abcdef' });
    const b = await svc.handleChat({ conversationId: a.conversationId, message: 'How much is a root canal?', clientMessageId: 'msg-0001-abcdef' });
    assert.equal(b.ticketId, a.ticketId); assert.equal((await svc.listTickets()).length, 1);
    assert.equal((await svc.getConversation(a.conversationId)).messages.length, 2);
  });
});

describe('staff replies reach the right patient', () => {
  test('reply is saved, shown in that conversation, timestamps update, needs human → answered (not closed)', async () => {
    const { svc } = make();
    const a = await svc.handleChat({ message: 'Do you do Invisalign?' });
    const before = (await svc.getTicket(a.ticketId!))!;
    const t = await svc.staffReply(a.ticketId, { text: 'Yes — Dr. Imran can discuss clear aligner options. We will call you today.', staffName: 'Anita' });
    assert.equal(t.status, 'answered'); assert.notEqual(t.status, 'closed');
    assert.ok(t.updatedAt > before.updatedAt); assert.equal(t.assignedTo, 'Anita'); assert.ok(t.firstStaffReplyAt);
    const conv = await svc.getConversation(a.conversationId);
    const last = conv.messages[conv.messages.length - 1];
    assert.equal(last.sender, 'staff'); assert.equal(last.staffName, 'Anita'); assert.match(last.text, /Dr\. Imran/);
    assert.equal(conv.messages[0].text, 'Do you do Invisalign?'); // earlier history preserved
  });
  test('replies never leak into another patient’s conversation', async () => {
    const { svc } = make();
    const p1 = await svc.handleChat({ message: 'Do you do Invisalign?' });
    const p2 = await svc.handleChat({ message: 'Do you do veneers?' });
    await svc.staffReply(p2.ticketId, { text: 'REPLY-FOR-P2-ONLY' });
    const c1 = await svc.getConversation(p1.conversationId);
    const c2 = await svc.getConversation(p2.conversationId);
    assert.ok(!c1.messages.some((m) => m.text.includes('REPLY-FOR-P2-ONLY')));
    assert.ok(c2.messages.some((m) => m.text.includes('REPLY-FOR-P2-ONLY')));
  });
  test('urgent stays urgent after a staff reply until closed; close and reopen work', async () => {
    const { svc } = make();
    const a = await svc.handleChat({ message: 'Heavy bleeding that will not stop' });
    assert.equal((await svc.staffReply(a.ticketId, { text: 'Calling you now.' })).status, 'urgent');
    const closed = await svc.setStatus(a.ticketId, { status: 'closed', staffName: 'Dr. Meera' });
    assert.equal(closed.status, 'closed'); assert.equal(closed.closedBy, 'Dr. Meera'); assert.ok(closed.closedAt);
    assert.equal((await svc.setStatus(a.ticketId, { status: 'open' })).status, 'urgent');
  });
  test('multiple tickets: each reply lands on its own ticket', async () => {
    const { svc } = make();
    const rs = await Promise.all(['Do you do Invisalign?', 'Do you do veneers?', 'Do you do dentures?'].map((message) => svc.handleChat({ message })));
    await Promise.all(rs.map((r, i) => svc.staffReply(r.ticketId, { text: `reply #${i}` })));
    for (const [i, r] of rs.entries()) {
      const t = (await svc.getTicket(r.ticketId!))!;
      assert.deepEqual(t.messages.filter((m) => m.sender === 'staff').map((m) => m.text), [`reply #${i}`]);
    }
  });
  test('concurrent staff replies + patient follow-up on one ticket: nothing lost', async () => {
    const { svc } = make();
    const a = await svc.handleChat({ message: 'I want to book an appointment' });
    await Promise.all([
      ...Array.from({ length: 8 }, (_, i) => svc.staffReply(a.ticketId, { text: `staff ${i}` })),
      svc.handleChat({ conversationId: a.conversationId, message: 'Saturday at 11am' }),
    ]);
    const t = (await svc.getTicket(a.ticketId!))!;
    assert.equal(t.messages.filter((m) => m.sender === 'staff').length, 8);
    assert.equal(t.booking?.dateText, 'Saturday');
  });
  test('validation: empty / oversized / bad ids rejected', async () => {
    const { svc } = make();
    await assert.rejects(svc.handleChat({ message: '   ' }), /empty/);
    await assert.rejects(svc.handleChat({ message: 'x'.repeat(1001) }), /too long/);
    await assert.rejects(svc.staffReply('../etc/passwd', { text: 'x' }), /Invalid/);
    await assert.rejects(svc.staffReply('BR-000000-NOPE00', { text: 'x' }), /not found/);
    await assert.rejects(svc.setStatus('BR-000000-NOPE00', { status: 'deleted' }), /Status must be/);
  });
});

describe('persistence', () => {
  test('a fresh service instance on the same store sees all tickets and replies', async () => {
    const kv = new MemoryKV();
    const a = make(kv).svc;
    const r = await a.handleChat({ message: 'Do you do Invisalign?' });
    await a.staffReply(r.ticketId, { text: 'We will call you.' });
    const b = make(kv).svc; // e.g. a new function invocation / page reload
    assert.equal((await b.listTickets()).length, 1);
    assert.ok((await b.getConversation(r.conversationId)).messages.some((m) => m.text === 'We will call you.'));
  });
  test('queue order: urgent first, then needs human, answered, closed', async () => {
    const { svc } = make();
    const ans = await svc.handleChat({ message: 'How much is a root canal?' });
    const hum = await svc.handleChat({ message: 'Do you do Invisalign?' });
    const cls = await svc.handleChat({ message: 'Do you do veneers?' });
    await svc.setStatus(cls.ticketId, { status: 'closed' });
    const urg = await svc.handleChat({ message: 'I cannot breathe' });
    assert.deepEqual((await svc.listTickets()).map((t) => t.id), [urg.ticketId, hum.ticketId, ans.ticketId, cls.ticketId]);
  });
});
